package com.bhushan.dailyprompts

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import android.util.Base64

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("daily_prompts", MODE_PRIVATE) }
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var geminiKey: EditText
    private lateinit var openAiKey: EditText
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var prompt: TextView
    private var selectedImageBase64: String? = null
    private var selectedMime = "image/jpeg"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFFF7F5FF.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 20)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(label("Daily Prompts", 28, 0xFF21153F.toInt()))
        content.addView(label("Daily AI prompt • Gemini + OpenAI fallback", 14, 0xFF655A78.toInt()))
        content.addView(spacer(16))
        content.addView(cardHeader("Today's prompt"))
        prompt = label(todayPrompt(), 17, 0xFF2B2440.toInt())
        content.addView(prompt)
        val newPrompt = button("Get today's prompt")
        newPrompt.setOnClickListener { prompt.text = todayPrompt() }
        content.addView(newPrompt)
        content.addView(spacer(20))

        content.addView(cardHeader("AI Keys & Providers"))
        content.addView(label("Gemini API Key", 14, 0xFF30264B.toInt()))
        geminiKey = edit("Paste Gemini key", true)
        geminiKey.setText(prefs.getString("gemini_key", ""))
        content.addView(geminiKey)
        content.addView(label("OpenAI / ChatGPT API Key", 14, 0xFF30264B.toInt()))
        openAiKey = edit("Paste OpenAI key", true)
        openAiKey.setText(prefs.getString("openai_key", ""))
        content.addView(openAiKey)
        val save = button("Update & Save Keys")
        save.setOnClickListener {
            prefs.edit()
                .putString("gemini_key", geminiKey.text.toString().trim())
                .putString("openai_key", openAiKey.text.toString().trim())
                .apply()
            status.text = "Keys saved on this device. Keep them private."
        }
        content.addView(save)
        content.addView(spacer(10))

        content.addView(cardHeader("Image analysis"))
        content.addView(label("Choose a picture, then analyze it. If Gemini returns quota/rate-limit error (429), the app tries OpenAI automatically.", 14, 0xFF655A78.toInt()))
        val choose = button("Choose image")
        choose.setOnClickListener {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            startActivityForResult(i, 202)
        }
        content.addView(choose)
        val analyze = button("Analyze image (automatic fallback)")
        analyze.setOnClickListener { analyzeImage() }
        content.addView(analyze)

        status = label("Ready. Add API keys and save them.", 14, 0xFF227442.toInt())
        content.addView(status)
        result = label("", 16, 0xFF21153F.toInt())
        content.addView(result)
        content.addView(spacer(12))
        content.addView(label("Security note: this starter app stores keys locally for personal testing. For a public app, move API calls to a secure backend so keys are not extractable from the APK.", 12, 0xFF7C3D35.toInt()))

        setContentView(root)
    }

    private fun analyzeImage() {
        val image = selectedImageBase64
        if (image == null) {
            status.text = "Please choose an image first."
            return
        }
        val gKey = geminiKey.text.toString().trim().ifEmpty { prefs.getString("gemini_key", "") ?: "" }
        val oKey = openAiKey.text.toString().trim().ifEmpty { prefs.getString("openai_key", "") ?: "" }
        prefs.edit().putString("gemini_key", gKey).putString("openai_key", oKey).apply()
        status.text = "Analyzing image…"
        result.text = ""
        executor.execute {
            try {
                var answer: String? = null
                var geminiError = ""
                if (gKey.isNotBlank()) {
                    try {
                        answer = callGemini(gKey, image, selectedMime)
                    } catch (e: ApiException) {
                        geminiError = "Gemini error ${e.code}: ${e.message}"
                        if (e.code != 429 && e.code != 408 && e.code != 500 && e.code != 503) throw e
                    }
                } else {
                    geminiError = "Gemini key not set."
                }
                var used = "Gemini"
                if (answer == null) {
                    if (oKey.isBlank()) throw Exception("$geminiError Add an OpenAI API key to enable fallback.")
                    answer = callOpenAI(oKey, image, selectedMime)
                    used = "OpenAI fallback"
                }
                runOnUiThread {
                    status.text = "Success — $used"
                    result.text = answer
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Analysis failed"
                    result.text = e.message ?: "Unknown error"
                }
            }
        }
    }

    private class ApiException(val code: Int, message: String) : Exception(message)

    private fun callGemini(key: String, image: String, mime: String): String {
        val body = JSONObject().put("contents", JSONArray().put(
            JSONObject().put("parts", JSONArray()
                .put(JSONObject().put("text", "Analyze this image. Describe the visible content and provide useful details."))
                .put(JSONObject().put("inline_data", JSONObject().put("mime_type", mime).put("data", image)))
            )
        )).toString()
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${key}"
        val response = request(url, "POST", body, null)
        val json = JSONObject(response.body)
        return json.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
            ?.takeIf { it.isNotBlank() } ?: throw Exception("Gemini returned no text.")
    }

    private fun callOpenAI(key: String, image: String, mime: String): String {
        val dataUrl = "data:$mime;base64,$image"
        val content = JSONArray()
            .put(JSONObject().put("type", "text").put("text", "Analyze this image. Describe visible content and provide useful details."))
            .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", dataUrl)))
        val messages = JSONArray().put(JSONObject()
            .put("role", "user")
            .put("content", content))
        val body = JSONObject()
            .put("model", "gpt-4o-mini")
            .put("messages", messages)
            .put("max_tokens", 700)
            .toString()
        val response = request("https://api.openai.com/v1/chat/completions", "POST", body, key)
        val json = JSONObject(response.body)
        return json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
            ?.takeIf { it.isNotBlank() } ?: throw Exception("OpenAI returned no text.")
    }

    private data class HttpResult(val code: Int, val body: String)
    private fun request(urlText: String, method: String, body: String, bearer: String?): HttpResult {
        val conn = (URL(urlText).openConnection() as HttpURLConnection)
        conn.requestMethod = method
        conn.connectTimeout = 25000
        conn.readTimeout = 45000
        conn.setRequestProperty("Content-Type", "application/json")
        if (bearer != null) conn.setRequestProperty("Authorization", "Bearer $bearer")
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        conn.disconnect()
        if (code !in 200..299) {
            val msg = try { JSONObject(text).optJSONObject("error")?.optString("message") ?: text } catch (_: Exception) { text }
            throw ApiException(code, msg)
        }
        return HttpResult(code, text)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 202 && resultCode == RESULT_OK && data?.data != null) {
            try {
                val uri = data.data!!
                contentResolver.openInputStream(uri).use { input ->
                    val bytes = input?.readBytes() ?: throw Exception("Could not read image.")
                    if (bytes.size > 8 * 1024 * 1024) throw Exception("Please choose an image smaller than 8 MB.")
                    selectedImageBase64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    selectedMime = contentResolver.getType(uri) ?: "image/jpeg"
                    status.text = "Image selected (${bytes.size / 1024} KB). Ready to analyze."
                }
            } catch (e: Exception) {
                status.text = e.message ?: "Could not load image."
            }
        }
    }

    private fun todayPrompt(): String {
        val day = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date()).toInt()
        val prompts = listOf(
            "Cinematic anime boy standing under neon rain, reflective streets, violet and teal lighting, detailed atmosphere.",
            "A peaceful fantasy library floating among clouds at sunrise, warm golden light, intricate architecture.",
            "Photorealistic macro of a dew-covered flower in a misty garden, soft natural light, shallow depth of field.",
            "A futuristic city built into a giant forest, glowing walkways, cinematic wide-angle composition.",
            "Romantic anime scene beside a quiet lakeside at blue hour, soft lanterns and delicate reflections.",
            "A majestic white dragon resting on an ancient mountain temple, volumetric clouds, epic fantasy art.",
            "Minimalist architecture in desert dunes at sunset, warm shadows, premium editorial photography.",
            "A cozy rainy-day café window with books, tea, bokeh streetlights, warm cinematic color grading.",
            "A luminous galaxy above a snowy mountain lake, vivid cobalt and magenta nebula, ultra-detailed.",
            "An elegant botanical greenhouse at dawn, sunbeams through glass, lush greenery, realistic textures."
        )
        return "Prompt of the day\n\n" + prompts[Math.floorMod(day, prompts.size)]
    }

    private fun label(text: String, size: Int, color: Int) = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        setPadding(4, 8, 4, 8)
    }

    private fun cardHeader(text: String) = TextView(this).apply {
        this.text = text
        textSize = 19f
        setTextColor(0xFF5425A8.toInt())
        setPadding(4, 12, 4, 8)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun edit(hintText: String, secret: Boolean) = EditText(this).apply {
        hint = hintText
        textSize = 15f
        setSingleLine(true)
        if (secret) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        setPadding(14, 12, 14, 12)
        setBackgroundColor(0xFFFFFFFF.toInt())
    }

    private fun button(text: String) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(0xFF5425A8.toInt())
    }

    private fun spacer(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, height)
    }
}
