package com.aistudio.dailyprompts.pkmnz.data.remote.ai

/**
 * Standardized AI Prompt Request preserving all context across providers.
 */
data class AIPromptRequest(
    val topic: String,
    val targetAi: String = "General",
    val category: String = "General",
    val style: String = "Balanced",
    val dislikedTypes: List<String> = emptyList(),
    val systemPrompt: String? = null,
    val temperature: Double = 0.7,
    val maxTokens: Int = 1000,
    val imageBase64: String? = null,
    val imageMimeType: String? = "image/jpeg"
)

/**
 * Standardized result returned by all AI providers.
 */
sealed class AIProviderResult {
    data class Success(val text: String, val providerName: String) : AIProviderResult()
    data class Failure(val error: AIProviderError) : AIProviderResult()
}

/**
 * Distinct error hierarchy to differentiate quota/rate-limit errors (which trigger failover)
 * from unrelated configuration or syntax errors (which must NOT trigger failover).
 */
sealed class AIProviderError(
    open val provider: String,
    override val message: String,
    override val cause: Throwable? = null
) : Exception(message, cause) {

    // --- Quota & Rate Limit Errors (Qualify for instant failover) ---
    class QuotaExhausted(override val provider: String, message: String) : AIProviderError(provider, message)
    class RateLimited(override val provider: String, message: String) : AIProviderError(provider, message)

    // --- Unrelated Errors (Must NOT trigger failover) ---
    class InvalidApiKey(override val provider: String, message: String = "API key is invalid or unauthorized.") : AIProviderError(provider, message)
    class KeyMissing(override val provider: String, message: String = "API key is not configured.") : AIProviderError(provider, message)
    class InvalidRequest(override val provider: String, message: String) : AIProviderError(provider, message)
    class PolicyRefusal(override val provider: String, message: String = "Prompt refused due to policy.") : AIProviderError(provider, message)
    class NetworkError(override val provider: String, message: String) : AIProviderError(provider, message)
    class ServerError(override val provider: String, val code: Int, message: String) : AIProviderError(provider, message)
    class GeneralError(override val provider: String, message: String) : AIProviderError(provider, message)

    /**
     * Identifies whether this error is a quota, usage limit, credit limit, or rate limit error
     * that permits automatic backup failover.
     */
    fun isQuotaOrRateLimit(): Boolean = this is QuotaExhausted || this is RateLimited
}

/**
 * Common abstraction for all AI providers (Gemini, OpenAI, etc.).
 */
interface AIProvider {
    val name: String
    suspend fun generatePrompt(request: AIPromptRequest): AIProviderResult
}
