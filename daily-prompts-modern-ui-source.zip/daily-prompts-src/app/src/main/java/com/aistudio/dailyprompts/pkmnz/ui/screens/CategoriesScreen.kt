package com.aistudio.dailyprompts.pkmnz.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.dailyprompts.pkmnz.data.model.PromptCategory
import com.aistudio.dailyprompts.pkmnz.ui.components.CategoryArtThumbnail
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmBackground
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardBorderSubtle
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardSurface
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextSecondary
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.AppTab
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.PromptViewModel
import com.aistudio.dailyprompts.pkmnz.ui.i18n.AppStrings
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppLanguage
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppStrings

data class CategoryGridItem(
    val category: PromptCategory,
    val name: String,
    val promptCount: String
)

@Composable
fun CategoriesScreen(
    viewModel: PromptViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val strings = LocalAppStrings.current
    val currentLanguage = LocalAppLanguage.current

    val categoriesList = remember {
        listOf(
            CategoryGridItem(PromptCategory.GIRL, "Girl & Aesthetics", "70+ Prompts"),
            CategoryGridItem(PromptCategory.BOY, "Boy & Male Style", "60+ Prompts"),
            CategoryGridItem(PromptCategory.AI_ART, "AI Art & Image", "90+ Prompts"),
            CategoryGridItem(PromptCategory.NATURE, "Nature & Landscapes", "80+ Prompts"),
            CategoryGridItem(PromptCategory.MOTIVATION, "Motivation", "120+ Prompts"),
            CategoryGridItem(PromptCategory.SELF_CARE, "Self Care", "95+ Prompts"),
            CategoryGridItem(PromptCategory.PRODUCTIVITY, "Productivity", "100+ Prompts"),
            CategoryGridItem(PromptCategory.CREATIVITY, "Creativity", "80+ Prompts"),
            CategoryGridItem(PromptCategory.RELATIONSHIPS, "Relationships", "75+ Prompts"),
            CategoryGridItem(PromptCategory.MINDFULNESS, "Mindfulness", "90+ Prompts"),
            CategoryGridItem(PromptCategory.HEALTH, "Health", "70+ Prompts"),
            CategoryGridItem(PromptCategory.LIFESTYLE, "Lifestyle", "85+ Prompts")
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WarmBackground)
            .navigationBarsPadding()
            .testTag("categories_screen")
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onBack()
                },
                modifier = Modifier.testTag("categories_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = strings.back,
                    tint = WarmTextPrimary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Column(modifier = Modifier.padding(start = 8.dp)) {
                Text(
                    text = strings.categoriesTitle,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        color = WarmTextPrimary
                    )
                )
                Text(
                    text = strings.categoriesSubtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 13.sp,
                        color = WarmTextSecondary
                    )
                )
            }
        }

        // 2-Column Grid of Category Cards
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(categoriesList) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(elevation = 3.dp, shape = RoundedCornerShape(20.dp), ambientColor = Color(0x14000000))
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            viewModel.setCategory(item.category)
                            viewModel.setTab(AppTab.EXPLORE)
                        }
                        .testTag("category_card_${item.name}"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = WarmCardSurface),
                    border = BorderStroke(1.dp, WarmCardBorderSubtle)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp)
                    ) {
                        // Image Thumbnail
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(115.dp)
                                .clip(RoundedCornerShape(16.dp))
                        ) {
                            CategoryArtThumbnail(category = item.name)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Category Name
                        Text(
                            text = AppStrings.translate(item.name, currentLanguage),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = WarmTextPrimary
                            )
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        // Number of Prompts
                        Text(
                            text = item.promptCount,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 12.sp,
                                color = WarmTextSecondary
                            )
                        )
                    }
                }
            }
        }
    }
}
