package com.aistudio.dailyprompts.pkmnz.data.model

data class UserProfile(
    val name: String = DEFAULT_NAME,
    val bio: String = DEFAULT_BIO,
    val email: String = DEFAULT_EMAIL,
    val avatarType: String = AVATAR_DEFAULT,
    val customAvatarPath: String? = null
) {
    companion object {
        const val DEFAULT_NAME = "Daily Prompts"
        const val DEFAULT_BIO = "A better you, every day ❤️"
        const val DEFAULT_EMAIL = "daily.prompts@mindful.me"

        const val AVATAR_DEFAULT = "DEFAULT"
        const val AVATAR_LOTUS = "LOTUS"
        const val AVATAR_SUNSET = "SUNSET"
        const val AVATAR_MINT = "MINT"
        const val AVATAR_ROSE = "ROSE"
        const val AVATAR_CUSTOM = "CUSTOM"
    }
}
