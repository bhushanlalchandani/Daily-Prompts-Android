package com.aistudio.dailyprompts.pkmnz.data.generator

import com.aistudio.dailyprompts.pkmnz.data.local.PromptEntity
import com.aistudio.dailyprompts.pkmnz.data.model.AiTool
import com.aistudio.dailyprompts.pkmnz.data.model.PromptCategory
import java.util.Calendar

object SmartPromptEngine {

    val SEED_PROMPTS = listOf(
        // ==========================================
        // 🌟 FEATURED & WELLNESS DAILY PROMPTS
        // ==========================================
        PromptEntity(
            title = "Small Step Toward a Happier You",
            promptText = "What's one small step you can take today toward a happier you?",
            category = PromptCategory.MOTIVATION.displayName,
            aiTool = AiTool.GENERAL.displayName,
            tags = "Motivation, Wellness, Mindfulness, Self Care, Daily",
            isDaily = true
        ),
        PromptEntity(
            title = "Unconditional Courage",
            promptText = "What would you do if you knew you couldn't fail?",
            category = PromptCategory.MOTIVATION.displayName,
            aiTool = AiTool.GENERAL.displayName,
            tags = "Motivation, Growth, Inspiration",
            isDaily = true
        ),
        PromptEntity(
            title = "Gentle Self-Compassion",
            promptText = "How can you be kinder to yourself today?",
            category = PromptCategory.SELF_CARE.displayName,
            aiTool = AiTool.GENERAL.displayName,
            tags = "Self Care, Kindness, Mental Health",
            isDaily = true
        ),
        PromptEntity(
            title = "Daily Gratitude Reflection",
            promptText = "List 3 things you're deeply grateful for in this exact moment.",
            category = PromptCategory.SELF_CARE.displayName,
            aiTool = AiTool.GENERAL.displayName,
            tags = "Self Care, Gratitude, Peace",
            isDaily = true
        ),
        PromptEntity(
            title = "The Essential Focus Priority",
            promptText = "What is one high-impact priority that will make everything else easier today?",
            category = PromptCategory.PRODUCTIVITY.displayName,
            aiTool = AiTool.GENERAL.displayName,
            tags = "Productivity, Focus, Deep Work",
            isDaily = true
        ),
        PromptEntity(
            title = "Creative Freedom & Spark",
            promptText = "If you had uninterrupted focus for 2 hours today, what would you create?",
            category = PromptCategory.CREATIVITY.displayName,
            aiTool = AiTool.GENERAL.displayName,
            tags = "Creativity, Art, Imagination",
            isDaily = true
        ),
        PromptEntity(
            title = "Meaningful Connection",
            promptText = "How can you show genuine appreciation to someone you care about today?",
            category = PromptCategory.RELATIONSHIPS.displayName,
            aiTool = AiTool.GENERAL.displayName,
            tags = "Relationships, Love, Empathy",
            isDaily = true
        ),
        PromptEntity(
            title = "Finding Inner Peace",
            promptText = "Close your eyes, take 3 deep breaths: What brings you peace right now?",
            category = PromptCategory.MINDFULNESS.displayName,
            aiTool = AiTool.GENERAL.displayName,
            tags = "Mindfulness, Zen, Breath, Calm",
            isDaily = true
        ),
        PromptEntity(
            title = "Nourishing Your Body",
            promptText = "What is one small, uplifting healthy choice you can make for your body today?",
            category = PromptCategory.HEALTH.displayName,
            aiTool = AiTool.GENERAL.displayName,
            tags = "Health, Energy, Vitality",
            isDaily = true
        ),
        PromptEntity(
            title = "Peaceful Evening Ritual",
            promptText = "What is one simple ritual that would make your evening feel peaceful and restorative?",
            category = PromptCategory.LIFESTYLE.displayName,
            aiTool = AiTool.GENERAL.displayName,
            tags = "Lifestyle, Cozy, Evening, Rest",
            isDaily = true
        ),

        // ==========================================
        // 👦 BOY & MALE STYLE PROMPTS
        // ==========================================
        PromptEntity(
            title = "Cinematic Golden Hour Street Style Boy",
            promptText = "A cinematic medium shot of a stylish 22-year-old young man with natural messy textured taper fade hair, wearing an oversized vintage dark brown leather bomber jacket over a black turtleneck, walking through autumn London streets during golden hour sunset, warm rim lighting hitting jawline, natural skin pores, realistic depth of field, shot on 85mm f/1.4 lens, 35mm film aesthetic, photorealistic 8k --ar 9:16 --style raw --v 6.0",
            category = PromptCategory.BOY.displayName,
            aiTool = AiTool.MIDJOURNEY.displayName,
            tags = "Boy, Portrait, Street Style, Golden Hour, Aesthetic",
            isDaily = true
        ),
        PromptEntity(
            title = "Cyberpunk Boy in Heavy Rain with Headphones",
            promptText = "Close-up cinematic portrait of an edgy young boy with wet messy dark parted hair, wearing glowing turquoise and cyan RGB over-ear wireless gaming headphones, frosted translucent techwear raincoat, standing under intense Tokyo neon lights during heavy rain, neon reflections in water droplets rolling down cheeks, volumetric haze, Arri Alexa Mini LF, hyper-realistic --ar 16:9 --v 6.0",
            category = PromptCategory.BOY.displayName,
            aiTool = AiTool.MIDJOURNEY.displayName,
            tags = "Boy, Cyberpunk, Neon, Rain, Headphones",
            isDaily = true
        ),
        PromptEntity(
            title = "Royal Velvet Sherwani Ethnic Boy Portrait",
            promptText = "Regal studio portrait of a handsome young Indian man with sharp groomed beard and wavy hair, dressed in a bespoke midnight blue velvet royal sherwani with intricate antique gold zardozi hand embroidery, wearing a subtle pearl necklace, soft ambient warm diya lighting casting gentle glow, grand palace courtyard backdrop, shot on Hasselblad H6D-100c, 8k --ar 4:5 --style raw",
            category = PromptCategory.BOY.displayName,
            aiTool = AiTool.FLUX.displayName,
            tags = "Boy, Royal, Ethnic, Sherwani, Traditional",
            isDaily = false
        ),
        PromptEntity(
            title = "Cozy Parisian Coffee Shop Reader Boy",
            promptText = "Candid lifestyle photography of a handsome boy wearing an oversized cream knitted wool sweater, sitting by the rain-streaked window of an old vintage Parisian cafe, intently reading an antique hardcover book, steaming porcelain cup of espresso on rustic dark wood table, soft warm bokeh of cafe lamps, moody introspective atmosphere, Kodak Portra 400 grain --ar 4:5",
            category = PromptCategory.BOY.displayName,
            aiTool = AiTool.MIDJOURNEY.displayName,
            tags = "Boy, Cozy, Book, Aesthetic, Cafe",
            isDaily = false
        ),
        PromptEntity(
            title = "High-Intensity Fitness Athletic Action Boy",
            promptText = "Dynamic fitness editorial photography of an athletic young man in an industrial gym performing heavy kettlebell swings, sweat glistening on defined shoulders and arms, high-contrast rim lighting cutting through atmospheric chalk dust in the air, intense focused gaze, dramatic shadows, shot on Sony A7R V with 50mm f/1.2 G-Master lens --ar 9:16",
            category = PromptCategory.BOY.displayName,
            aiTool = AiTool.FLUX.displayName,
            tags = "Boy, Fitness, Gym, Athletic, High Contrast",
            isDaily = false
        ),
        PromptEntity(
            title = "Anime Boy Under Swirling Starry Sky",
            promptText = "Young anime boy with windblown dark hair standing atop a grassy mountain hill at twilight, gazing up at a breathtaking swirling violet and deep cobalt blue Milky Way night sky filled with shooting stars, ethereal glowing fireflies, emotional Makoto Shinkai anime movie aesthetic, masterwork digital painting, 4k ultra-detailed wallpaper --ar 16:9",
            category = PromptCategory.BOY.displayName,
            aiTool = AiTool.MIDJOURNEY.displayName,
            tags = "Anime, Boy, Starry Night, Makoto Shinkai, Wallpaper",
            isDaily = false
        ),

        // ==========================================
        // 👧 GIRL & AESTHETICS PROMPTS
        // ==========================================
        PromptEntity(
            title = "Beautiful Girl Golden Hour Aesthetic Portrait",
            promptText = "A cinematic medium close-up photograph of an exceptionally beautiful 21-year-old young woman with natural radiant glass skin, expressive amber hazel eyes, and soft windblown wavy chestnut hair, glowing warm golden hour sunset rim light highlighting facial contours, natural delicate freckles, wearing an oversized ivory linen shirt, shot on Hasselblad H6D-100c with 85mm f/1.2 lens, creamy background bokeh, 8k resolution, photorealistic, Vogue editorial --ar 9:16 --style raw --v 6.0",
            category = PromptCategory.GIRL.displayName,
            aiTool = AiTool.MIDJOURNEY.displayName,
            tags = "Beautiful girl, Girl, Portrait, Golden Hour, Aesthetic, Photorealistic",
            isDaily = true
        ),
        PromptEntity(
            title = "Royal Saree Elegance Beautiful Indian Girl",
            promptText = "Cinematic royal portrait of a graceful and beautiful Indian woman draped in an opulent crimson Banarasi silk saree with intricate antique gold zardozi brocade, adorned with traditional kundan jhumkas and delicate maang tikka, soft warm candlelight from handcrafted clay diyas illuminating her serene face, ancient heritage palace haveli carved stone archways in background, photorealistic 8k textures --ar 9:16 --style raw",
            category = PromptCategory.GIRL.displayName,
            aiTool = AiTool.FLUX.displayName,
            tags = "Beautiful girl, Saree, Traditional, Royal, Indian, Diya Glow",
            isDaily = true
        ),
        PromptEntity(
            title = "Ethereal Fairycore Wildflower Bloom Beautiful Girl",
            promptText = "Dreamy ethereal portrait of a beautiful young woman with a delicate floral wreath woven into wavy auburn hair, seated gracefully among blooming white wildflowers and lush green moss in a sunlit meadow, morning sun rays filtering through forest canopy creating divine god rays, luminous glass skin, pastel color grading, shot on 85mm f/1.2 lens, soft creamy bokeh --ar 4:5 --v 6.0",
            category = PromptCategory.GIRL.displayName,
            aiTool = AiTool.MIDJOURNEY.displayName,
            tags = "Beautiful girl, Fairycore, Nature, Bloom, Ethereal, Flowers",
            isDaily = true
        ),
        PromptEntity(
            title = "Candid 35mm Monsoon Rain Beautiful Girl with Umbrella",
            promptText = "Authentic candid street photography of a smiling beautiful young woman holding a clear transparent umbrella dotted with raindrops, walking through a vibrant city crossing at twilight, colorful vehicle taillights creating warm pastel bokeh circles, reflections on wet asphalt, natural windblown wisps of hair, Kodak Portra 800 film grain, cinematic realism --ar 3:4",
            category = PromptCategory.GIRL.displayName,
            aiTool = AiTool.MIDJOURNEY.displayName,
            tags = "Beautiful girl, Monsoon, Rain, Umbrella, Film Grain, Street",
            isDaily = false
        ),
        PromptEntity(
            title = "Futuristic Cyberpunk Beautiful Girl with Neon AR Visor",
            promptText = "Edgy futuristic cyberpunk portrait of a beautiful young woman with asymmetrical pastel pink bob haircut, wearing sleek holographic neon AR data glasses with glowing code streams reflecting in her eyes, matte black techwear collar jacket with subtle magenta LED piping, volumetric smoke background, Unreal Engine 5 render, raytracing, ultra-fine details --ar 16:9",
            category = PromptCategory.GIRL.displayName,
            aiTool = AiTool.MIDJOURNEY.displayName,
            tags = "Beautiful girl, Cyberpunk, Hologram, Futuristic, Neon",
            isDaily = false
        ),
        PromptEntity(
            title = "Dewy Clean Girl Beautiful Aesthetic Studio Portrait",
            promptText = "Minimalist beauty editorial portrait of a beautiful young woman with natural dewy makeup, radiant glass skin, and slicked-back bun, soft morning sunlight casting organic botanical shadows across her face, wearing a neutral cream ribbed knit tank top, soft beige warm monochrome palette, Vogue magazine cover quality, 85mm macro lens --ar 1:1 --style raw",
            category = PromptCategory.GIRL.displayName,
            aiTool = AiTool.FLUX.displayName,
            tags = "Beautiful girl, Clean Girl, Beauty, Studio, Minimalist",
            isDaily = false
        ),
        PromptEntity(
            title = "Vintage 90s Polaroid Beach Sunset Beautiful Girl",
            promptText = "Nostalgic 1990s vintage Polaroid flash portrait of a carefree beautiful young girl with wind-tousled beach hair and oversized aviator sunglasses on the beach during golden sunset, ocean waves crashing gently behind, warm amber and magenta twilight sky, light film grain, authentic retro flash photography aesthetic, candid laughter --ar 4:5",
            category = PromptCategory.GIRL.displayName,
            aiTool = AiTool.MIDJOURNEY.displayName,
            tags = "Beautiful girl, Vintage, 90s, Sunset, Beach, Polaroid",
            isDaily = false
        ),
        PromptEntity(
            title = "Makoto Shinkai Anime Beautiful Girl Under Starry Sky",
            promptText = "Emotional masterwork anime digital illustration of a beautiful young girl with windblown hair gazing at a breathtaking swirling violet and deep cobalt blue Milky Way galaxy sky filled with shooting stars, ethereal glowing fireflies, emotional Makoto Shinkai movie aesthetic, 4k ultra-detailed wallpaper --ar 16:9",
            category = PromptCategory.GIRL.displayName,
            aiTool = AiTool.MIDJOURNEY.displayName,
            tags = "Beautiful girl, Anime, Starry Sky, Makoto Shinkai, Wallpaper",
            isDaily = false
        ),

        // ==========================================
        // 🌿 NATURE & LANDSCAPES PROMPTS
        // ==========================================
        PromptEntity(
            title = "Dramatic Himalayan Mist & Golden Sunrise Peaks",
            promptText = "Epic wide-angle panoramic landscape of towering snow-capped Himalayan mountain peaks illuminated by the first golden alpine glow of dawn, dramatic cascading layers of mountain mist drifting through pristine pine valleys, turquoise glacial river winding through valley floor below, shot on Phase One 100MP, ultra-crisp detail, dramatic atmospheric depth, National Geographic award winner --ar 16:9 --v 6.0",
            category = PromptCategory.NATURE.displayName,
            aiTool = AiTool.MIDJOURNEY.displayName,
            tags = "Nature, Himalayas, Mountains, Sunrise, Landscape",
            isDaily = true
        ),
        PromptEntity(
            title = "Bioluminescent Enchanted Forest & Waterfall",
            promptText = "Magical hidden emerald canyon with a multi-tiered crystal waterfall cascading into an iridescent turquoise pool, surrounded by luminous glowing blue bioluminescent moss, purple glowing mushrooms, and floating golden fireflies, deep twilight canopy, volumetric moonlight filtering through giant ancient redwood branches, otherworldly fantasy landscape, 8k octane render --ar 16:9",
            category = PromptCategory.NATURE.displayName,
            aiTool = AiTool.MIDJOURNEY.displayName,
            tags = "Nature, Bioluminescent, Waterfall, Fantasy, Forest",
            isDaily = true
        ),
        PromptEntity(
            title = "Serene Japanese Autumn Maple Lake Reflections",
            promptText = "Tranquil early morning at a mirror-calm alpine lake in Kyoto surrounded by vibrant crimson, scarlet, and golden Japanese maple trees, a historic rustic wooden bridge peeking through soft rising morning mist, gentle ripples on surface with floating fallen red leaves, peaceful zen atmosphere, Fuji Velvia 50 color profile --ar 16:9",
            category = PromptCategory.NATURE.displayName,
            aiTool = AiTool.FLUX.displayName,
            tags = "Nature, Japan, Autumn, Lake, Maple, Zen",
            isDaily = false
        ),
        PromptEntity(
            title = "Milky Way Galaxy Arching Over Sahara Dunes",
            promptText = "Stunning night astrophotography of the core of the Milky Way galaxy with purple nebula dust trails arching across pristine wind-sculpted golden desert sand dunes in the Sahara, sharp sand ripples in foreground, long exposure 30 seconds, pin-sharp stars, zero light pollution, breathtaking cosmic scale, shot on Nikon Z9 with 14-24mm f/2.8 --ar 16:9",
            category = PromptCategory.NATURE.displayName,
            aiTool = AiTool.MIDJOURNEY.displayName,
            tags = "Nature, Milky Way, Desert, Dunes, Astrophotography",
            isDaily = false
        ),
        PromptEntity(
            title = "Lush Monsoon Rainforest with Dew on Emerald Leaves",
            promptText = "Cinematic nature documentary close-up and wide environmental shot of a lush tropical monsoon rainforest in Western Ghats, oversized elephant ear and monstera leaves dripping with glistening crystal raindrops, vibrant moss-covered ancient bark, soft overcast moody lighting, rich emerald and jade green gradients, macro water droplets reflecting canopy --ar 4:5",
            category = PromptCategory.NATURE.displayName,
            aiTool = AiTool.FLUX.displayName,
            tags = "Nature, Rainforest, Monsoon, Raindrops, Emerald",
            isDaily = false
        ),
        PromptEntity(
            title = "Pristine Tropical Turquoise Island Lagoon Drone Shot",
            promptText = "Spectacular top-down aerial drone photography of a secluded heart-shaped sandbar island in French Polynesia, surrounded by vivid translucent turquoise and deep sapphire lagoon waters, intricate living coral reef formations clearly visible beneath calm water, blinding white sands, brilliant sunny midday lighting, shot on Hasselblad aerial --ar 1:1",
            category = PromptCategory.NATURE.displayName,
            aiTool = AiTool.MIDJOURNEY.displayName,
            tags = "Nature, Island, Lagoon, Aerial, Tropical, Coral",
            isDaily = false
        ),

        // ==========================================
        // --- AI ART / CREATIVE ---
        // ==========================================
        PromptEntity(
            title = "Cinematic Cyberpunk Rain Street",
            promptText = "A cinematic medium shot of a cybernetic wanderer standing in a neon-drenched Tokyo alleyway during heavy rain, reflections of glowing magenta and cyan billboards in water puddles, volumetric steam rising from street grates, shot on 35mm Arri Alexa, anamorphic lens flare, photorealistic, intricate textures, 8k resolution --ar 16:9 --style raw --v 6.0",
            category = PromptCategory.AI_ART.displayName,
            aiTool = AiTool.MIDJOURNEY.displayName,
            tags = "Photorealistic, Cyberpunk, 16:9, Neon",
            isDaily = false
        ),
        PromptEntity(
            title = "Hyper-Realistic Studio Product Mockup",
            promptText = "Minimalist luxury perfume bottle made of frosted glass with brushed champagne gold cap, placed on a smooth raw travertine stone pedestal, soft morning sunlight casting dramatic architectural shadows, beige and warm cream minimalist studio background, 85mm macro lens, depth of field, commercial product photography --ar 4:5 --v 6.0",
            category = PromptCategory.AI_ART.displayName,
            aiTool = AiTool.MIDJOURNEY.displayName,
            tags = "Product Photography, Minimalist, Luxury",
            isDaily = false
        ),
        PromptEntity(
            title = "Studio Ghibli Lush Mountain Village",
            promptText = "Enchanting tranquil hillside village surrounded by terraced green rice fields and ancient cherry blossoms, painted in the nostalgic animation style of Studio Ghibli, vibrant watercolor clouds, warm afternoon golden hour light, peaceful cottage with smoke curling from chimney, hand-drawn aesthetic, high detail --ar 16:9 --v 6.0",
            category = PromptCategory.AI_ART.displayName,
            aiTool = AiTool.MIDJOURNEY.displayName,
            tags = "Anime, Ghibli, Landscape, Watercolor",
            isDaily = false
        ),

        // ==========================================
        // --- CHATGPT & WRITING ---
        // ==========================================
        PromptEntity(
            title = "Senior Executive Salary Negotiation Script",
            promptText = "Act as an executive negotiation coach. I have received a job offer for [Job Title] offering $[Offer Amount]. Based on my [X] years of experience, specific achievements in [Key Achievement], and market standards, write: 1) A polite but firm counter-offer email requesting $[Target Amount] or additional perks (equity, remote flexibility, signing bonus). 2) A contingency response script if the hiring manager says the budget is fixed.",
            category = PromptCategory.CHAT_GPT.displayName,
            aiTool = AiTool.CHATGPT.displayName,
            tags = "Career, Email, Negotiation, High-Value",
            isDaily = false
        ),
        PromptEntity(
            title = "High-Converting Cold Outreach Email",
            promptText = "You are a master B2B sales copywriter. Write a 75-word cold outreach email targeting [Decision Maker Title, e.g., VP of Marketing] at [Target Industry]. The email must follow the Problem-Agitate-Solve framework without sounding salesy. Include: 1) An irresistible personalized opening observation, 2) A concise value proposition citing a realistic metric (e.g. 'boosted inbound pipeline by 34%'), and 3) A low-friction call to action asking for feedback rather than a sales call.",
            category = PromptCategory.CHAT_GPT.displayName,
            aiTool = AiTool.CHATGPT.displayName,
            tags = "Email, Sales, B2B, Copywriting",
            isDaily = false
        ),

        // ==========================================
        // --- CODING & TECH ---
        // ==========================================
        PromptEntity(
            title = "Clean Architecture Code Refactoring",
            promptText = "Act as a Principal Staff Software Engineer. Analyze the following [Language/Framework] code snippet. Review it for: 1) Architectural violations of SOLID principles, 2) Performance bottlenecks or race conditions, 3) Memory leaks. Then, provide the refactored, production-ready code with complete type annotations, unit test examples using mock fixtures, and a bulleted rationale of changes made.",
            category = PromptCategory.CODING.displayName,
            aiTool = AiTool.CLAUDE.displayName,
            tags = "Code Review, Architecture, Refactor, Clean Code",
            isDaily = false
        ),

        // ==========================================
        // --- SOCIAL MEDIA & REELS ---
        // ==========================================
        PromptEntity(
            title = "Viral Instagram Reel Hook & Script",
            promptText = "You are a viral short-form video strategist with 10M+ views. Create 5 high-converting 3-second visual and spoken hooks for a Reel/TikTok about [Topic, e.g., productivity hacks for remote workers]. For the top hook, write a 45-second script formatted in two columns: Left Column (Visual/B-roll instructions + text on screen) and Right Column (Spoken audio script with dynamic pacing pauses).",
            category = PromptCategory.SOCIAL_MEDIA.displayName,
            aiTool = AiTool.CHATGPT.displayName,
            tags = "Reels, TikTok, Viral Hook, Video Script",
            isDaily = false
        ),

        // ==========================================
        // --- BUSINESS & SALES ---
        // ==========================================
        PromptEntity(
            title = "SaaS Product Value Proposition Framework",
            promptText = "You are a veteran product marketing director. Help me build a crisp messaging guide for [Product Name/Concept]. Create: 1) A 10-second elevator pitch using the Steve Jobs 'Why-How-What' structure, 2) A comparison matrix contrasting our solution against existing alternatives/spreadsheets, 3) Three specific persona pain points with our direct feature solutions, and 4) Three objection-handling rebuttals for price-sensitive prospects.",
            category = PromptCategory.BUSINESS.displayName,
            aiTool = AiTool.CLAUDE.displayName,
            tags = "Marketing, Value Prop, SaaS, Pitch",
            isDaily = false
        ),

        // ==========================================
        // --- STUDY & LEARNING ---
        // ==========================================
        PromptEntity(
            title = "Feynman Technique Deep Concept Explainer",
            promptText = "Explain the complex concept of [Topic, e.g., Quantum Computing or Transformers in AI] using the Feynman Technique. Structure your response in 4 steps: 1) Explain it simply as if I am a 12-year-old using a vivid real-world metaphor, 2) Identify the exact technical nuances that the simple metaphor misses, 3) Bridge the gap with precise technical definitions without unnecessary academic jargon, and 4) Test my understanding with 3 thought-provoking conceptual questions.",
            category = PromptCategory.STUDY.displayName,
            aiTool = AiTool.CHATGPT.displayName,
            tags = "Feynman Method, Education, Deep Learning",
            isDaily = false
        )
    )

    fun getDailyFeaturedPrompt(offset: Int = 0): PromptEntity {
        // Pick the featured prompt deterministically by local calendar day. This keeps it
        // stable during the day, but guarantees it advances on the next day instead of
        // returning SEED_PROMPTS[0] forever. A non-zero offset is used by the manual
        // refresh action to move to another prompt on the same day.
        if (SEED_PROMPTS.isEmpty()) {
            return PromptEntity(
                title = "Today's Creative Prompt",
                promptText = "Create something original, vivid, and useful today.",
                category = PromptCategory.CHAT_GPT.displayName,
                aiTool = AiTool.CHATGPT.displayName,
                tags = "Daily, Creative",
                isDaily = true
            )
        }
        val calendar = Calendar.getInstance()
        val daySerial = calendar.get(Calendar.YEAR) * 366 + calendar.get(Calendar.DAY_OF_YEAR)
        val index = Math.floorMod(daySerial + offset, SEED_PROMPTS.size)
        return SEED_PROMPTS[index]
    }

    fun getDailySeedBatch(): List<PromptEntity> {
        return generateFreshDailyBatch(0)
    }

    fun generateFreshDailyBatch(rollSeed: Int = 0): List<PromptEntity> {
        val calendar = Calendar.getInstance()
        val dayOfYear = calendar.get(Calendar.DAY_OF_YEAR)
        val combinedOffset = ((dayOfYear * 11) + (rollSeed * 17))

        // Take an intelligent slice of curated seeds rotated by offset
        val dynamicSeeds = SEED_PROMPTS.indices.map { i ->
            val idx = (i * 3 + combinedOffset) % SEED_PROMPTS.size
            SEED_PROMPTS[idx]
        }.distinctBy { it.title }.take(12)

        // Generate procedural dynamic prompts across various categories to guarantee fresh variety
        val dynamicAdditions = listOf(
            PromptEntity(
                title = "Atmospheric Midnight Tokyo Drift Boy #${(rollSeed % 99) + 1}",
                promptText = "Cinematic 35mm film photograph of a cool young man standing next to a modified midnight purple sports car in a neon-lit Shinjuku alleyway, soft rain mist, reflections on wet pavement, ambient amber and magenta street glow, wearing vintage oversized leather jacket, shot on Leica M6 with Summilux 35mm f/1.4, subtle grain --ar 16:9 --style raw --v 6.0",
                category = PromptCategory.BOY.displayName,
                aiTool = AiTool.MIDJOURNEY.displayName,
                tags = "Boy, Street, Tokyo, Cinema, 35mm",
                isDaily = true
            ),
            PromptEntity(
                title = "Luminous Ethereal Water Lily Girl #${(rollSeed % 99) + 1}",
                promptText = "Dreamy fantasy portrait of an angelic young woman floating gracefully in crystal clear freshwater surrounded by glowing white water lilies and lotus flowers, golden twilight sunbeams filtering through water surface, ethereal glass skin, delicate wisps of hair, shot on Hasselblad 100MP with 85mm f/1.2 lens, pastel color grading --ar 9:16 --v 6.0",
                category = PromptCategory.GIRL.displayName,
                aiTool = AiTool.FLUX.displayName,
                tags = "Girl, Ethereal, Water, Lotus, Fantasy",
                isDaily = true
            ),
            PromptEntity(
                title = "Majestic Misty Alpine Sunrise #${(rollSeed % 99) + 1}",
                promptText = "Award-winning landscape photography of jagged snow-capped alpine mountain peaks piercing through a sea of morning clouds, golden god rays illuminating a tranquil turquoise glacial lake below, pine forest valley, ultra-sharp focus, shot on Sony A7R V with 16-35mm G Master lens at f/8, photorealistic 8k --ar 16:9",
                category = PromptCategory.NATURE.displayName,
                aiTool = AiTool.MIDJOURNEY.displayName,
                tags = "Nature, Mountains, Sunrise, Landscape, 8k",
                isDaily = true
            ),
            PromptEntity(
                title = "Isometric Floating Cyberpunk Sky Loft #${(rollSeed % 99) + 1}",
                promptText = "Detailed 3D isometric cutaway diorama of a futuristic high-tech rooftop studio loft apartment, glowing holographic computer terminal, neon plant terrarium, rain washing down glass ceiling, cute robotic pet cat sleeping on velvet sofa, cozy lofi lighting, Blender 3D cycles render, raytraced shadows, 4k wallpaper --ar 1:1",
                category = PromptCategory.AI_ART.displayName,
                aiTool = AiTool.MIDJOURNEY.displayName,
                tags = "3D, Isometric, Cyberpunk, Cozy, Blender",
                isDaily = true
            ),
            PromptEntity(
                title = "High-Converting Micro-SaaS Launch Strategy #${(rollSeed % 99) + 1}",
                promptText = "Act as a top-tier venture architect and SaaS growth strategist. Create a battle-tested 30-day go-to-market execution plan for an AI productivity app. Include: 1) Product Hunt launch playbook with countdown timeline, 2) Exact cold outreach copy for niche community founders, 3) 5 contrarian Twitter/X hooks that drive organic signups, and 4) Pricing tiers with psychological price anchoring.",
                category = PromptCategory.BUSINESS.displayName,
                aiTool = AiTool.CHATGPT.displayName,
                tags = "SaaS, GTM, Strategy, Growth, Marketing",
                isDaily = true
            ),
            PromptEntity(
                title = "Viral Short-Form Video Hook Multiplier #${(rollSeed % 99) + 1}",
                promptText = "Act as an elite short-form video retention specialist with 100M+ organic views. Write 7 powerful, scroll-stopping video hooks for [Topic or Niche]. Categorize each hook by psychological trigger (Curiosity Gap, Contrarian POV, FOMO, Secret Knowledge). For each hook, include the exact first 3-second visual action and on-screen caption.",
                category = PromptCategory.SOCIAL_MEDIA.displayName,
                aiTool = AiTool.CLAUDE.displayName,
                tags = "Viral Hooks, TikTok, Reels, Retention, Script",
                isDaily = true
            )
        )

        val combinedList = (dynamicAdditions + dynamicSeeds).distinctBy { it.promptText }
        return combinedList.mapIndexed { index, prompt ->
            prompt.copy(
                id = 0,
                createdAt = System.currentTimeMillis() + (index * 15L),
                isDaily = true,
                isFavorite = false,
                isDisliked = false
            )
        }
    }

    fun buildProceduralPrompt(
        topic: String,
        targetAi: String,
        category: String,
        style: String
    ): String {
        val cleanTopic = topic.trim().ifBlank { "portrait and creative visual art" }

        // 0. Dedicated handler for Image-to-Prompt analysis topics
        if (cleanTopic.startsWith("Image:", ignoreCase = true) ||
            cleanTopic.contains("Visual Analysis", ignoreCase = true) ||
            cleanTopic.contains("uploaded image", ignoreCase = true) ||
            cleanTopic.contains("Image to Prompt", ignoreCase = true) ||
            category.contains("Visual Art", ignoreCase = true) && cleanTopic.contains("•") ||
            category.contains("Art", ignoreCase = true) && (cleanTopic.contains("image", ignoreCase = true) || cleanTopic.contains("photo", ignoreCase = true))
        ) {
            val parsed = parseImageTopicAndContext(cleanTopic)
            return generateImageDescriptivePrompt(
                aspectRatio = parsed.aspectRatio,
                colorTone = parsed.colorTone,
                dominantColorHex = parsed.dominantColorHex,
                luminance = parsed.luminance,
                sampleId = parsed.sampleId,
                contextHint = parsed.visualElements
            )
        }

        val isBoy = category.contains("Boy", ignoreCase = true) ||
                cleanTopic.contains("boy", ignoreCase = true) ||
                cleanTopic.contains("man", ignoreCase = true) ||
                cleanTopic.contains("male", ignoreCase = true) ||
                cleanTopic.contains("guy", ignoreCase = true)

        val isGirl = category.contains("Girl", ignoreCase = true) ||
                cleanTopic.contains("girl", ignoreCase = true) ||
                cleanTopic.contains("woman", ignoreCase = true) ||
                cleanTopic.contains("female", ignoreCase = true) ||
                cleanTopic.contains("lady", ignoreCase = true) ||
                cleanTopic.contains("ladki", ignoreCase = true) ||
                cleanTopic.contains("kanya", ignoreCase = true) ||
                cleanTopic.contains("saree", ignoreCase = true) ||
                cleanTopic.contains("beauty", ignoreCase = true) ||
                cleanTopic.contains("beautiful", ignoreCase = true) ||
                cleanTopic.contains("model", ignoreCase = true)

        val isNature = category.contains("Nature", ignoreCase = true) ||
                cleanTopic.contains("nature", ignoreCase = true) ||
                cleanTopic.contains("landscape", ignoreCase = true) ||
                cleanTopic.contains("mountain", ignoreCase = true) ||
                cleanTopic.contains("forest", ignoreCase = true) ||
                cleanTopic.contains("waterfall", ignoreCase = true) ||
                cleanTopic.contains("sunset", ignoreCase = true)

        return when {
            isBoy -> {
                val lightingMood = when (style) {
                    "Cinematic" -> "dramatic Rembrandt rim lighting, moody atmospheric shadows, anamorphic lens flare"
                    "Minimalist" -> "clean studio high-key light, neutral grey backdrop, subtle soft shadows"
                    "Vibrant" -> "neon cyberpunk rim glow, colored reflection accents, vivid atmosphere"
                    else -> "warm golden hour side light, natural soft diffusion, authentic skin highlights"
                }
                "Masterwork portrait photograph of a handsome young boy, $cleanTopic. Intricately detailed facial features, natural skin texture with visible pores, sharp focused eyes, styled textured hair. $lightingMood. Shot on 85mm f/1.4 lens, shallow depth of field with creamy background bokeh, 8k resolution, photorealistic, hyper-detailed --ar 9:16 --style raw --v 6.0"
            }

            isGirl -> {
                val lightingMood = when (style) {
                    "Cinematic" -> "cinematic warm backlighting, gentle lens diffusion, moody color grade, atmospheric haze"
                    "Minimalist" -> "soft diffused natural window light, radiant glass skin, minimalist aesthetic"
                    "Vibrant" -> "dramatic neon edge glow, iridescent accents, high fashion editorial lighting"
                    else -> "magical sunbeams filtering through, golden hour warm tones, soft ethereal glow"
                }

                when {
                    cleanTopic.contains("saree", ignoreCase = true) || cleanTopic.contains("indian", ignoreCase = true) || cleanTopic.contains("traditional", ignoreCase = true) || cleanTopic.contains("ethnic", ignoreCase = true) -> {
                        "Cinematic royal portrait of an exceptionally beautiful young Indian girl in an opulent crimson Banarasi silk saree with intricate antique gold zardozi brocade, wearing traditional kundan jhumkas and delicate maang tikka, soft warm candlelight from handcrafted clay diyas illuminating her serene face, ancient heritage palace haveli carved stone archways in background, Hasselblad H6D-100c with 85mm f/1.2 lens, 8k resolution, photorealistic, Vogue India editorial --ar 9:16 --style raw --v 6.0"
                    }
                    cleanTopic.contains("anime", ignoreCase = true) || cleanTopic.contains("manga", ignoreCase = true) -> {
                        "Emotional masterwork anime digital illustration of an exceptionally beautiful young girl with windblown hair gazing at a breathtaking swirling violet and deep cobalt blue Milky Way galaxy sky filled with shooting stars, ethereal glowing fireflies, emotional Makoto Shinkai movie aesthetic, 4k ultra-detailed wallpaper --ar 16:9"
                    }
                    cleanTopic.contains("cyber", ignoreCase = true) || cleanTopic.contains("neon", ignoreCase = true) || cleanTopic.contains("future", ignoreCase = true) -> {
                        "Edgy futuristic cyberpunk portrait of an exceptionally beautiful young girl with asymmetrical pastel hair, wearing sleek holographic neon AR data glasses with glowing code streams reflecting in her eyes, matte black techwear collar jacket with subtle magenta LED piping, volumetric smoke background, Unreal Engine 5 render, raytracing, ultra-fine details --ar 16:9"
                    }
                    cleanTopic.contains("fairy", ignoreCase = true) || cleanTopic.contains("flower", ignoreCase = true) || cleanTopic.contains("wildflower", ignoreCase = true) || cleanTopic.contains("meadow", ignoreCase = true) -> {
                        "Dreamy ethereal portrait of an exceptionally beautiful young girl with a delicate floral wreath woven into wavy auburn hair, seated gracefully among blooming white wildflowers and lush green moss in a sunlit meadow, morning sun rays filtering through forest canopy creating divine god rays, luminous glass skin, pastel color grading, shot on 85mm f/1.2 lens, soft creamy bokeh --ar 4:5 --v 6.0"
                    }
                    targetAi.contains("ChatGPT", ignoreCase = true) || targetAi.contains("Claude", ignoreCase = true) -> {
                        """
                        Act as a master creative director, character designer, and AI prompt engineer.
                        Create a vivid, high-impact aesthetic character profile and image generation prompt for: $cleanTopic.
                        
                        Deliverable:
                        1. Subject & Aesthetic: Breathtaking visual features, radiant glass skin, expressive captivating eyes, natural hair styling, and elegant wardrobe.
                        2. Lighting & Atmosphere: $lightingMood, cinematic color grading, and ambient depth.
                        3. Camera & Composition: Shot on 85mm f/1.2 lens, creamy bokeh, 8k resolution.
                        4. Copy-Paste Ready Midjourney / Flux Art Prompt:
                        "A cinematic medium close-up photograph of an exceptionally beautiful young girl, $cleanTopic, natural radiant glass skin, expressive amber hazel eyes, soft windblown hair, $lightingMood, shot on Hasselblad H6D-100c with 85mm f/1.2 lens, creamy bokeh, 8k resolution, photorealistic, Vogue editorial --ar 9:16 --style raw --v 6.0"
                        """.trimIndent()
                    }
                    else -> {
                        "A cinematic masterwork medium close-up photograph of an exceptionally beautiful young girl, $cleanTopic. Radiant natural glass skin, expressive captivating eyes, delicate hair strands catching a gentle breeze, natural skin texture with visible pores, $lightingMood. Shot on Hasselblad H6D-100c with 85mm f/1.2 lens, creamy background bokeh, 8k resolution, photorealistic, commercial fashion magazine aesthetics --ar 9:16 --style raw --v 6.0"
                    }
                }
            }

            isNature -> {
                val lightingMood = when (style) {
                    "Cinematic" -> "volumetric god rays cutting through mountain mist, dramatic golden hour sky, deep shadows"
                    "Minimalist" -> "clean tranquil morning fog, subtle pastel twilight gradient, serene negative space"
                    "Vibrant" -> "rich saturated emeralds, fiery crimson dawn reflections, crystal clarity"
                    else -> "crisp alpine daylight, sparkling water reflections, atmospheric depth of field"
                }
                "Breathtaking National Geographic award-winning landscape photograph of $cleanTopic. Pristine natural environment, layered atmospheric depth with soft rising mist, $lightingMood. Ultra-wide 16mm lens perspective, infinite depth of field, 8k resolution, hyper-realistic nature documentary cinematography --ar 16:9 --v 6.0"
            }

            targetAi.contains("Midjourney", ignoreCase = true) ||
            targetAi.contains("Flux", ignoreCase = true) ||
            category.contains("Art", ignoreCase = true) -> {
                val parsed = parseImageTopicAndContext(cleanTopic)
                if (parsed.visualElements != null || cleanTopic.contains("image", ignoreCase = true) || cleanTopic.contains("photo", ignoreCase = true) || cleanTopic.contains("portrait", ignoreCase = true)) {
                    generateImageDescriptivePrompt(
                        aspectRatio = parsed.aspectRatio,
                        colorTone = parsed.colorTone,
                        dominantColorHex = parsed.dominantColorHex,
                        luminance = parsed.luminance,
                        sampleId = parsed.sampleId,
                        contextHint = parsed.visualElements ?: cleanTopic
                    )
                } else {
                    val lighting = when (style) {
                        "Cinematic" -> "dramatic volumetric lighting, natural depth falloff, and subtle atmospheric tone"
                        "Minimalist" -> "clean studio illumination, soft diffused highlights, and neutral spatial framing"
                        "Vibrant" -> "dynamic high-key illumination, rich color gradation, and clean specular accents"
                        else -> "authentic ambient illumination, balanced exposure, and natural textural fidelity"
                    }
                    "A detailed visual composition of $cleanTopic, featuring authentic subject geometry, $lighting, precise focal depth, natural material textures, and balanced compositional harmony."
                }
            }

            category.contains("Coding", ignoreCase = true) -> {
                """
                Act as a Principal Software Engineer and Architect.
                Regarding: $cleanTopic.
                
                Please provide:
                1. Architectural overview and best-practice pattern recommendations.
                2. Complete, idiomatic, and production-ready code with comprehensive error handling and type annotations.
                3. Key edge cases to guard against, performance considerations, and testing strategies.
                4. A brief breakdown explaining why this implementation is optimal.
                Style / Approach: $style, clean and robust.
                """.trimIndent()
            }

            category.contains("Social", ignoreCase = true) -> {
                """
                Act as an elite social media content strategist who has generated tens of millions of views.
                Topic: $cleanTopic.
                
                Deliverable:
                1. 5 irresistible hooks designed to stop the scroll in under 2 seconds (using curiosity gap and contrarian framing).
                2. A high-retention 45-second script with exact visual/B-roll suggestions and text-overlay prompts.
                3. A compelling Call To Action (CTA) that maximizes saves and shares.
                Tone / Energy: $style, high momentum and punchy.
                """.trimIndent()
            }

            category.contains("Business", ignoreCase = true) -> {
                """
                Act as an executive business advisor and senior strategist.
                Analyze and generate a high-impact execution plan for: $cleanTopic.
                
                Include:
                1. Executive summary and core value proposition.
                2. Step-by-step strategic framework with milestone metrics.
                3. Potential operational risks, customer objections, and actionable mitigation tactics.
                4. High-converting communication template (email or pitch script) ready to deploy.
                Tone: $style, results-driven and professional.
                """.trimIndent()
            }

            category.contains("Study", ignoreCase = true) -> {
                """
                Act as a master educator utilizing the Feynman Technique and cognitive science learning principles.
                Subject: $cleanTopic.
                
                Please breakdown:
                1. Intuitive core concept explained simply using a real-world analogy.
                2. Deep technical breakdown of the underlying mechanisms without unnecessary academic jargon.
                3. 3 active recall questions with hidden spoiler answers to test conceptual comprehension.
                4. A memory-hook mnemonic or framework to retain this forever.
                Style: $style, lucid and engaging.
                """.trimIndent()
            }

            else -> {
                """
                You are an expert specialist in prompt engineering.
                Your task is to thoroughly analyze, structure, and execute on: $cleanTopic.
                
                Guidelines:
                - Adopt a $style demeanor with deep subject-matter authority.
                - Provide comprehensive, step-by-step reasoning before drawing final conclusions.
                - Include concrete, real-world examples and actionable takeaways.
                - Eliminate generic filler and deliver high-density, practical value.
                """.trimIndent()
            }
        }
    }

    data class ParsedVisualContext(
        val sampleId: String? = null,
        val aspectRatio: String = "Portrait",
        val colorTone: String = "Warm Peach & Amber",
        val dominantColorHex: String = "#FFE0B2",
        val luminance: String = "Golden / Warm",
        val visualElements: String? = null
    )

    /**
     * Parses image topics, telemetry, sample references, and user descriptions
     * to extract concrete visual details, telemetry attributes, and content cues.
     */
    fun parseImageTopicAndContext(topic: String, contextHint: String? = null): ParsedVisualContext {
        val raw = topic.trim()
        val hint = contextHint?.trim()?.ifBlank { null }

        // 1. Check for recognized sample IDs in topic or hint
        val sampleId = when {
            raw.contains("golden_hour_portrait", ignoreCase = true) || hint?.contains("golden_hour_portrait", ignoreCase = true) == true -> "golden_hour_portrait"
            raw.contains("wildflower_meadow", ignoreCase = true) || hint?.contains("wildflower_meadow", ignoreCase = true) == true -> "wildflower_meadow"
            raw.contains("cosmic_landscape", ignoreCase = true) || raw.contains("cosmic_desert_sky", ignoreCase = true) ||
                    hint?.contains("cosmic_landscape", ignoreCase = true) == true || hint?.contains("cosmic_desert_sky", ignoreCase = true) == true -> "cosmic_landscape"
            else -> null
        }

        // 2. Aspect ratio
        val aspect = when {
            raw.contains("Landscape", ignoreCase = true) || hint?.contains("Landscape", ignoreCase = true) == true -> "Landscape"
            raw.contains("Square", ignoreCase = true) || hint?.contains("Square", ignoreCase = true) == true -> "Square"
            else -> "Portrait"
        }

        // 3. Color tone
        val tone = when {
            raw.contains("Peach", ignoreCase = true) || raw.contains("Amber", ignoreCase = true) ||
                    hint?.contains("Peach", ignoreCase = true) == true || hint?.contains("Amber", ignoreCase = true) == true -> "Warm Peach & Amber"
            raw.contains("Cyan", ignoreCase = true) || raw.contains("Indigo", ignoreCase = true) || raw.contains("Blue", ignoreCase = true) ||
                    hint?.contains("Cyan", ignoreCase = true) == true || hint?.contains("Indigo", ignoreCase = true) == true -> "Cool Cyan & Indigo"
            raw.contains("Green", ignoreCase = true) || hint?.contains("Green", ignoreCase = true) == true -> "Vibrant Natural Green"
            raw.contains("Monochrome", ignoreCase = true) || raw.contains("Slate", ignoreCase = true) ||
                    hint?.contains("Monochrome", ignoreCase = true) == true -> "Monochrome & Slate"
            else -> "Neutral Balanced"
        }

        // 4. Luminance
        val lum = when {
            raw.contains("Golden", ignoreCase = true) || raw.contains("Warm", ignoreCase = true) ||
                    hint?.contains("Golden", ignoreCase = true) == true || hint?.contains("Warm", ignoreCase = true) == true -> "Golden / Warm"
            raw.contains("Bright", ignoreCase = true) || raw.contains("High-Key", ignoreCase = true) ||
                    hint?.contains("Bright", ignoreCase = true) == true -> "Bright / High-Key"
            raw.contains("Moody", ignoreCase = true) || raw.contains("Low-Key", ignoreCase = true) || raw.contains("Night", ignoreCase = true) ||
                    hint?.contains("Moody", ignoreCase = true) == true -> "Moody / Low-Key"
            else -> "Balanced Natural"
        }

        // 5. Dominant Hex extraction
        val hexRegex = "#[0-9a-fA-F]{6}".toRegex()
        val hex = hexRegex.find(raw)?.value ?: hexRegex.find(hint ?: "")?.value ?: when (tone) {
            "Warm Peach & Amber" -> "#FFE0B2"
            "Cool Cyan & Indigo" -> "#81D4FA"
            "Vibrant Natural Green" -> "#C8E6C9"
            "Monochrome & Slate" -> "#334155"
            else -> "#CBD5E1"
        }

        // 6. Extract genuine content/elements description
        var content = hint
        if (content.isNullOrBlank() || content.equals("Visual Analysis", ignoreCase = true) || content.equals("Scene", ignoreCase = true)) {
            var cleaned = raw
            cleaned = cleaned.replace("(?i)^Image:\\s*".toRegex(), "")
            cleaned = cleaned.replace("(?i)^uploaded image (?:of|showing|with)?\\s*".toRegex(), "")
            cleaned = cleaned.replace("(?i)Visual Analysis".toRegex(), "")
            // Remove telemetry tokens if present
            cleaned = cleaned.replace("(?i)\\b(?:Portrait|Landscape|Square)\\b".toRegex(), "")
            cleaned = cleaned.replace("(?i)\\b(?:Warm Peach & Amber|Cool Cyan & Indigo|Vibrant Natural Green|Neutral Balanced|Monochrome & Slate)\\b".toRegex(), "")
            cleaned = cleaned.replace("(?i)\\b(?:Golden / Warm|Bright / High-Key|Moody / Low-Key|Balanced Natural)\\b".toRegex(), "")
            cleaned = cleaned.replace("•", " ")
            cleaned = cleaned.replace("(", " ").replace(")", " ")
            cleaned = cleaned.trim().trim(',', '.', ':', '-', '•')
            if (cleaned.isNotBlank() && !cleaned.equals("Scene", ignoreCase = true) &&
                !cleaned.equals("golden_hour_portrait", ignoreCase = true) &&
                !cleaned.equals("wildflower_meadow", ignoreCase = true) &&
                !cleaned.equals("cosmic_landscape", ignoreCase = true) &&
                !cleaned.equals("cosmic_desert_sky", ignoreCase = true)
            ) {
                content = cleaned
            } else {
                content = null
            }
        }

        return ParsedVisualContext(
            sampleId = sampleId,
            aspectRatio = aspect,
            colorTone = tone,
            dominantColorHex = hex,
            luminance = lum,
            visualElements = content
        )
    }

    /**
     * Accurately analyzes the visual details, subject composition, lighting dynamics,
     * and chromatic context of an image to produce a rich, descriptive prompt.
     * Focuses on the actual physical content and elements of the image rather than generic
     * descriptions or relying on repetitive or unnecessary styles.
     */
    fun generateImageDescriptivePrompt(
        aspectRatio: String = "Portrait",
        colorTone: String = "Warm Peach & Amber",
        dominantColorHex: String = "#FFE0B2",
        luminance: String = "Golden / Warm",
        sampleId: String? = null,
        contextHint: String? = null
    ): String {
        val content = contextHint?.trim()?.ifBlank { null }
        return if (content != null) {
            synthesizeContentFocusedPrompt(
                content = content,
                aspectRatio = aspectRatio,
                colorTone = colorTone,
                dominantColorHex = dominantColorHex,
                luminance = luminance
            )
        } else {
            synthesizeTelemetryFocusedPrompt(
                aspectRatio = aspectRatio,
                colorTone = colorTone,
                dominantColorHex = dominantColorHex,
                luminance = luminance
            )
        }
    }

    private fun synthesizeContentFocusedPrompt(
        content: String,
        aspectRatio: String,
        colorTone: String,
        dominantColorHex: String,
        luminance: String
    ): String {
        val lower = content.lowercase()

        val framing = when {
            aspectRatio.contains("Portrait", ignoreCase = true) ->
                "A vertical medium close-up portrait framing with upright focal balance"
            aspectRatio.contains("Landscape", ignoreCase = true) ->
                "An expansive wide-angle landscape composition with layered foreground and background depth"
            else ->
                "A balanced, centered composition with harmonious spatial proportions"
        }

        val lighting = when {
            luminance.contains("Golden", ignoreCase = true) || luminance.contains("Warm", ignoreCase = true) ->
                "illuminated by directional warm golden-hour sunlight casting soft amber rim light along prominent contours, with gentle diffused shadow transitions"
            luminance.contains("Bright", ignoreCase = true) || luminance.contains("High-Key", ignoreCase = true) ->
                "bathed in clean, high-key diffused natural daylight with minimal harsh shadows, high surface visibility, and crisp edge clarity"
            luminance.contains("Moody", ignoreCase = true) || luminance.contains("Low-Key", ignoreCase = true) ->
                "sculpted by dramatic low-key directional lighting with deep chiaroscuro contrast, pronounced shadow modeling, and focused specular highlights"
            else ->
                "lit by soft balanced ambient daylight, providing authentic tonal roll-off, natural exposure, and realistic light falloff"
        }

        val palette = when {
            colorTone.contains("Peach", ignoreCase = true) || colorTone.contains("Amber", ignoreCase = true) ->
                "The chromatic scheme features warm peach, honey-gold, amber, and terracotta undertones with deep earthy shadows (dominant tone $dominantColorHex)"
            colorTone.contains("Cyan", ignoreCase = true) || colorTone.contains("Indigo", ignoreCase = true) ->
                "The color palette centers on cool slate blue, azure, deep indigo, and muted neutral grays (dominant tone $dominantColorHex)"
            colorTone.contains("Green", ignoreCase = true) ->
                "Rich botanical greens, moss, and warm natural earth tones define the palette, accented by subtle daylight reflections (dominant tone $dominantColorHex)"
            colorTone.contains("Monochrome", ignoreCase = true) || colorTone.contains("Slate", ignoreCase = true) ->
                "A refined monochrome and tonal slate spectrum, emphasizing structural contrast, silver highlights, and deep shadow gradation (dominant tone $dominantColorHex)"
            else ->
                "A harmonious, authentic color palette with true-to-life saturation, balanced neutral midtones, and subtle environmental ambient reflections ($dominantColorHex)"
        }

        return when {
            lower.contains("woman") || lower.contains("girl") || lower.contains("lady") ||
            lower.contains("man") || lower.contains("boy") || lower.contains("person") ||
            lower.contains("portrait") || lower.contains("face") || lower.contains("model") -> {
                val attire = when {
                    lower.contains("saree") -> "an opulent Banarasi silk saree with delicate woven brocade along the pleats and pallu"
                    lower.contains("dress") -> "a flowing natural fabric dress with soft organic drape and fine seam stitching"
                    lower.contains("jacket") || lower.contains("coat") -> "a textured jacket with structured lapels and fine material grain"
                    lower.contains("sweater") -> "a soft knit sweater with visible yarn weave and natural textural warmth"
                    lower.contains("shirt") -> "a tailored cotton shirt with crisp collar lines and authentic fabric folds"
                    else -> "natural, well-fitted wardrobe with organic fabric folds and realistic textile texture"
                }

                val subjectHairAndFace = when {
                    lower.contains("curl") -> "natural textured curly hair with subtle highlights, framed around expressive facial features and clear eyes"
                    lower.contains("braid") -> "delicately styled braided hair with loose strands catching soft rim lighting"
                    lower.contains("short hair") -> "cleanly tapered haircut with realistic strand texture and defined contours"
                    else -> "naturally styled hair with soft loose strands catching the ambient light, framing authentic skin with visible fine pores"
                }

                """$framing focusing on $content.

The subject is presented with $subjectHairAndFace, dressed in $attire. Facial features, skin tone, and expressions are rendered with authentic anatomical fidelity and natural catchlight in the eyes.

The scene is $lighting. The surrounding setting establishes clear environmental context with natural depth separation between the subject and the background.

$palette. Shot on a prime portrait lens at wide aperture, producing razor-sharp focal clarity across the subject with a creamy, gentle bokeh blur in the background."""
            }

            lower.contains("dog") || lower.contains("cat") || lower.contains("pet") ||
            lower.contains("bird") || lower.contains("animal") || lower.contains("horse") -> {
                """$framing capturing $content.

The animal is rendered with sharp focal definition across its eyes, whiskers, and individual fur or feather textures. The posture and expression reflect natural, authentic behavior in its environment.

The scene is $lighting. Surrounding environmental elements provide realistic spatial context and natural tactile textures.

$palette. Crisp foreground focus with smooth, natural background falloff, highlighting true-to-life animal anatomy and authentic fur highlights."""
            }

            lower.contains("mountain") || lower.contains("beach") || lower.contains("ocean") ||
            lower.contains("lake") || lower.contains("river") || lower.contains("forest") ||
            lower.contains("tree") || lower.contains("meadow") || lower.contains("desert") ||
            lower.contains("landscape") || lower.contains("sunset") || lower.contains("sunrise") -> {
                """$framing capturing $content.

The foreground displays fine natural elements and organic textures, leading into expansive midground terrain and a well-defined horizon. Geological formations, vegetation, and water or earth surfaces exhibit rich tactile fidelity.

The scene is $lighting. Atmospheric perspective creates soft, gradual depth across distant ridgelines and the sky.

$palette. High dynamic range with authentic tonal transitions from foreground foliage to the open sky, captured with deep focal clarity."""
            }

            lower.contains("room") || lower.contains("cafe") || lower.contains("kitchen") ||
            lower.contains("interior") || lower.contains("building") || lower.contains("street") ||
            lower.contains("architecture") || lower.contains("house") || lower.contains("city") -> {
                """$framing showcasing $content.

The composition highlights architectural geometry, spatial perspective, and authentic construction materials including wood grain, stone, plaster, and glass surfaces. Furniture and decor elements are arranged with clean visual balance.

The scene is $lighting, creating realistic contact shadows on floor surfaces, soft bounce light across walls, and subtle specular reflections on glass and polished finishes.

$palette. Architectural lines remain crisp and well-aligned, with authentic interior depth and natural spatial atmosphere."""
            }

            else -> {
                """$framing capturing $content.

The composition establishes a clear focal hierarchy, accentuating the central subjects, their physical forms, and their relationship to the surrounding environment. Surface details, material textures, and edges are delineated with realistic optical clarity.

The scene is $lighting. Highlight roll-off and shadow transitions maintain natural gradation throughout the frame.

$palette. The shot features authentic optical depth of field with sharp subject fidelity and smooth ambient environmental falloff."""
            }
        }
    }

    private fun synthesizeTelemetryFocusedPrompt(
        aspectRatio: String,
        colorTone: String,
        dominantColorHex: String,
        luminance: String
    ): String {
        val framing = when {
            aspectRatio.contains("Portrait", ignoreCase = true) || aspectRatio.contains("Story", ignoreCase = true) ->
                "A vertical upright composition with focused focal framing"
            aspectRatio.contains("Landscape", ignoreCase = true) || aspectRatio.contains("Widescreen", ignoreCase = true) ->
                "An expansive wide-angle landscape composition with deep horizontal perspective"
            else ->
                "A balanced, centered composition with harmonious spatial proportions"
        }

        val lighting = when {
            luminance.contains("Golden", ignoreCase = true) || luminance.contains("Warm", ignoreCase = true) ->
                "illuminated by directional warm golden-hour light casting soft amber highlights along prominent edges, with gentle diffused shadow transitions"
            luminance.contains("Bright", ignoreCase = true) || luminance.contains("High-Key", ignoreCase = true) ->
                "bathed in clean, high-key diffused ambient daylight with minimal harsh shadows, high surface visibility, and crisp edge clarity"
            luminance.contains("Moody", ignoreCase = true) || luminance.contains("Low-Key", ignoreCase = true) ->
                "sculpted by atmospheric low-key lighting with deep chiaroscuro contrast, pronounced shadow modeling, and focused specular highlights"
            else ->
                "lit by soft balanced ambient illumination, providing natural exposure, subtle shadow gradation, and authentic light falloff"
        }

        val palette = when {
            colorTone.contains("Peach", ignoreCase = true) || colorTone.contains("Amber", ignoreCase = true) ->
                "The chromatic scheme features rich tones of warm amber, honey, peach, and soft terracotta (dominant tone $dominantColorHex)"
            colorTone.contains("Cyan", ignoreCase = true) || colorTone.contains("Indigo", ignoreCase = true) || colorTone.contains("Blue", ignoreCase = true) ->
                "The color palette centers on cool slate blue, azure, deep indigo, and muted neutral tones (dominant tone $dominantColorHex)"
            colorTone.contains("Green", ignoreCase = true) ->
                "Rich botanical greens, moss, and warm natural earth tones define the palette (dominant tone $dominantColorHex)"
            colorTone.contains("Monochrome", ignoreCase = true) || colorTone.contains("Slate", ignoreCase = true) ->
                "A refined monochrome and tonal slate spectrum, emphasizing structural contrast and clean value gradation (dominant tone $dominantColorHex)"
            else ->
                "A harmonious, authentic color palette with true-to-life saturation, balanced neutral midtones, and subtle environmental ambient reflections (dominant tone $dominantColorHex)"
        }

        val arParam = when {
            aspectRatio.contains("Portrait", ignoreCase = true) -> "--ar 4:5"
            aspectRatio.contains("Story", ignoreCase = true) -> "--ar 9:16"
            aspectRatio.contains("Landscape", ignoreCase = true) -> "--ar 16:9"
            else -> "--ar 1:1"
        }

        return """$framing. The scene is $lighting.

$palette. The composition maintains a clear focal hierarchy, accentuating natural physical contours, genuine surface textures, and refined material details with sharp optical clarity.

High dynamic range with gentle highlight roll-off and smooth ambient falloff. Photographed with authentic optical depth of field, natural color balance, 8k resolution $arParam --style raw"""
    }

    /**
     * Extracts the raw, fundamental topic/subject from a prompt, stripping any
     * preexisting enhancement wrappers, boilerplate prefixes, or structured framework headers.
     * Prevents repetitive nested concatenation ("A masterwork cinematic visual of A masterwork...").
     */
    fun extractCoreTopic(rawPrompt: String): String {
        var text = rawPrompt.trim()
        if (text.isBlank()) return ""

        // 1. Strip repeated cinematic visual prefixes
        text = text.replace("(?i)(?:A masterwork cinematic visual of\\s*)+".toRegex(), "")
        text = text.replace("(?i)(?:A cinematic masterwork medium close-up photograph of [^,]+,\\s*)+".toRegex(), "")
        text = text.replace("(?i)(?:A cinematic masterwork visual of\\s*)+".toRegex(), "")
        text = text.replace("(?i)(?:A cinematic masterwork\\s*)+".toRegex(), "")
        text = text.replace("(?i)(?:A masterwork visual of\\s*)+".toRegex(), "")
        text = text.replace("(?i)(?:A masterwork cinematic portrait of\\s*)+".toRegex(), "")
        text = text.replace("(?i)(?:A photorealistic ultra-detailed portrait of\\s*)+".toRegex(), "")
        text = text.replace("(?i)(?:An ethereal atmospheric cinematic visual of\\s*)+".toRegex(), "")
        text = text.replace("(?i)(?:An editorial high-fashion magazine cover shot of\\s*)+".toRegex(), "")
        text = text.replace("(?i)(?:A dramatic hyper-detailed visual of\\s*)+".toRegex(), "")

        // 2. Extract from structured frameworks (Role, Context, etc.) if present
        val contextMatch = "(?m)^\\s*(?:Requirement|Campaign Goal|Subject to Master|Task):\\s*(.+)$".toRegex().find(text)
        if (contextMatch != null && contextMatch.groupValues[1].isNotBlank()) {
            return contextMatch.groupValues[1].trim()
        }

        // 3. Strip framework headers if present
        if (text.contains("🎯 ROLE & EXPERTISE:")) {
            text = text.substringAfter("📋 CONTEXT & OBJECTIVE:", text)
            text = text.substringBefore("⚡ STEP-BY-STEP INSTRUCTIONS:", text)
            text = text.replace("(?m)^\\s*(?:Requirement|Campaign Goal|Subject to Master|Task):\\s*".toRegex(), "")
        }

        // 4. Strip trailing visual boilerplates (lenses, ar parameters, etc.)
        text = text.replace("(?i)\\.?\\s*Highly detailed textures.*$".toRegex(), "")
        text = text.replace("(?i)\\.?\\s*Studio portrait lighting.*$".toRegex(), "")
        text = text.replace("(?i)\\.?\\s*Golden hour backlight.*$".toRegex(), "")
        text = text.replace("(?i)\\.?\\s*Shot on 85mm.*$".toRegex(), "")
        text = text.replace("(?i)\\.?\\s*Shot on Hasselblad.*$".toRegex(), "")
        text = text.replace("(?i)\\s*--ar\\s+\\d+:\\d+.*$".toRegex(), "")
        text = text.replace("(?i)\\s*--style\\s+raw.*$".toRegex(), "")
        text = text.replace("(?i)\\s*--v\\s+\\d+(\\.\\d+)?.*$".toRegex(), "")

        val cleaned = text.trim().trim('.', ',')
        return if (cleaned.length >= 2) cleaned else rawPrompt.trim()
    }

    /**
     * Magic Prompt Enhancer (1-Tap Optimizer)
     * Transforms basic or vague prompts into high-performance Master Prompts
     * featuring explicit Role, Context, Step-by-Step Instructions, Tone, Constraints,
     * and Output Format. Cleanly extracts the core topic and supports multi-variant cycling.
     */
    fun enhancePrompt(
        rawPrompt: String,
        targetAi: String = "ChatGPT",
        category: String = "General",
        style: String = "Professional",
        variant: Int = 0
    ): String {
        // ALWAYS extract the true core topic first to guarantee zero nested duplication
        val clean = extractCoreTopic(rawPrompt)
        if (clean.isBlank()) return ""

        val lower = clean.lowercase()
        val v = (variant % 3).let { if (it < 0) it + 3 else it }

        // 1. Image / Midjourney / Visual generation check
        if (clean.startsWith("Image:", ignoreCase = true) ||
            clean.contains("uploaded image", ignoreCase = true) ||
            clean.contains("Visual Analysis", ignoreCase = true)
        ) {
            val parsed = parseImageTopicAndContext(clean)
            return generateImageDescriptivePrompt(
                aspectRatio = parsed.aspectRatio,
                colorTone = parsed.colorTone,
                dominantColorHex = parsed.dominantColorHex,
                luminance = parsed.luminance,
                sampleId = parsed.sampleId,
                contextHint = parsed.visualElements ?: clean
            )
        }

        val isVisual = targetAi.contains("Midjourney", ignoreCase = true) ||
                targetAi.contains("Flux", ignoreCase = true) ||
                targetAi.contains("DALL-E", ignoreCase = true) ||
                category.contains("Art", ignoreCase = true) ||
                category.contains("Girl", ignoreCase = true) ||
                category.contains("Boy", ignoreCase = true) ||
                lower.contains("photorealistic") || lower.contains("portrait") ||
                lower.contains("wallpaper") || lower.contains("illustration") ||
                lower.contains("saree") || lower.contains("anime")

        if (isVisual) {
            val mood = when {
                lower.contains("cyber") || lower.contains("neon") -> "volumetric neon rim light, cyberpunk chromatic aberrations, moody atmospheric haze"
                lower.contains("girl") || lower.contains("woman") || lower.contains("ladki") -> "soft diffuse golden hour sunlight, natural radiant skin highlights, gentle catchlight in eyes"
                lower.contains("boy") || lower.contains("man") -> "cinematic directional split lighting, sharp jawline shadow definition, textured rim light"
                lower.contains("landscape") || lower.contains("mountain") -> "dramatic god rays piercing through alpine mist, golden sunrise gradient, deep natural contrast"
                else -> "cinematic studio lighting, soft diffused bounce light, subtle depth of field, 8k resolution"
            }

            return when (v) {
                0 -> "A masterwork cinematic visual of $clean. Highly detailed textures, photorealistic materials, $mood. Shot on 85mm f/1.2 lens, shallow depth of field, creamy background bokeh, color graded in 35mm film aesthetic, award-winning composition --ar 16:9 --style raw --v 6.0"
                1 -> "A photorealistic ultra-detailed portrait of $clean. Studio portrait lighting with softbox key light and subtle hair rim light, authentic skin micropores, natural subsurface scattering, Hasselblad medium format camera, razor-sharp focal clarity, hyper-realistic depth --ar 16:9 --style raw --v 6.0"
                else -> "An ethereal atmospheric cinematic visual of $clean. Golden hour backlight, misty ambient atmospheric glow, cinematic anamorphic widescreen ratio, rich color grading in teal and warm amber tones, dreamlike depth of field, award-winning National Geographic aesthetic --ar 16:9 --style raw --v 6.0"
            }
        }

        // 2. Coding & Technical
        val isCoding = category.contains("Coding", ignoreCase = true) ||
                lower.contains("python") || lower.contains("javascript") || lower.contains("kotlin") ||
                lower.contains("java") || lower.contains("react") || lower.contains("sql") ||
                lower.contains("code") || lower.contains("api") || lower.contains("bug") ||
                lower.contains("script") || lower.contains("function") || lower.contains("database")

        if (isCoding) {
            return when (v) {
                0 -> """
                🎯 ROLE & EXPERTISE:
                Act as a Principal Software Engineer and System Architect with 15+ years of experience in modern enterprise software.

                📋 CONTEXT & OBJECTIVE:
                Requirement: $clean

                ⚡ STEP-BY-STEP INSTRUCTIONS:
                1. Analyze requirements, potential edge cases, and design trade-offs.
                2. Provide clean, idiomatic, fully functional, and modular production-ready code with comprehensive error handling and type safety.
                3. Highlight key complexity factors (Big-O time/space) and performance optimizations.
                4. Include a concise testing approach or unit test verification example.

                🎨 TONE & STYLE:
                Senior Engineering Standard: Concise, authoritative, idiomatic, and zero pseudo-code placeholders.

                🛑 CONSTRAINTS & WHAT TO AVOID:
                - Avoid incomplete snippets (do not leave '// TODO: implement later' comments).
                - Avoid outdated deprecated libraries or unsafe constructs.
                - Do NOT include generic conversational pleasantries.

                📤 OUTPUT FORMAT:
                Structured Markdown with syntax-highlighted code blocks, inline doc comments, and brief implementation notes.
                """.trimIndent()

                1 -> """
                🎯 ROLE & EXPERTISE:
                Act as an Elite Full-Stack Tech Lead & Code Optimizer.

                📋 CONTEXT & OBJECTIVE:
                Deliver the most efficient, robust, and scalable implementation for: $clean

                ⚡ ARCHITECTURAL SPECIFICATION:
                1. Architecture & Design Patterns: Use optimal industry patterns (clean architecture, SOLID principles).
                2. Full Implementation: Complete, production-grade source code with defensive programming.
                3. Security & Validation: Strict input sanitization and failure recovery.
                4. Performance: Zero unnecessary memory allocations or blocking I/O.

                🛑 CONSTRAINTS:
                No boilerplate fluff or filler text. Jump straight to the architectural breakdown and runnable code.

                📤 OUTPUT FORMAT:
                Clean Markdown formatted code blocks with brief bulleted technical highlights.
                """.trimIndent()

                else -> """
                🎯 ROLE & EXPERTISE:
                Act as a Senior DevOps & Systems Specialist.

                📋 CONTEXT & OBJECTIVE:
                Build a resilient, production-ready solution for: $clean

                ⚡ ACTION CHECKLIST:
                1. Step-by-Step Implementation Guide.
                2. Complete Code / Configuration with inline explanations.
                3. Common Failure Modes and exact debugging instructions.
                4. Production Deployment Verification Steps.

                📤 OUTPUT FORMAT:
                Concise Markdown with exact commands, configs, and executable code.
                """.trimIndent()
            }
        }

        // 3. Marketing, Sales & Copywriting
        val isMarketing = category.contains("Business", ignoreCase = true) ||
                category.contains("Social", ignoreCase = true) ||
                lower.contains("email") || lower.contains("sales") || lower.contains("copy") ||
                lower.contains("ad") || lower.contains("marketing") || lower.contains("pitch") ||
                lower.contains("instagram") || lower.contains("youtube") || lower.contains("hook")

        if (isMarketing) {
            return when (v) {
                0 -> """
                🎯 ROLE & EXPERTISE:
                Act as a World-Class Direct-Response Copywriter and Conversion Optimization Strategist (trained on Ogilvy, Halbert, and modern 8-figure DTC brands).

                📋 CONTEXT & OBJECTIVE:
                Campaign Goal: $clean
                Target: Maximize attention, emotional resonance, and conversion action.

                ⚡ STEP-BY-STEP INSTRUCTIONS:
                1. Craft 3 high-impact, scroll-stopping hooks/subject lines using distinct psychological triggers (Curiosity Gap, Contrarian Proof, Extreme Urgency).
                2. Write persuasive, high-momentum body copy structured around the AIDA (Attention, Interest, Desire, Action) or PAS (Problem, Agitate, Solution) framework.
                3. Address the top 2 objections the target audience will naturally have.
                4. End with an irresistible, frictionless Call To Action (CTA).

                🎨 TONE & STYLE:
                Punchy, high-energy, persuasive yet authentic. $style voice that builds trust immediately.

                🛑 CONSTRAINTS & WHAT TO AVOID:
                - No corporate jargon, passive voice, or boring buzzwords.
                - Never start with clichés like "In today's fast-paced world...".
                - Keep paragraphs short (1-2 sentences) for effortless readability.

                📤 OUTPUT FORMAT:
                Clean Markdown sections with clearly labeled hooks, body copy options, and deployment checklist.
                """.trimIndent()

                1 -> """
                🎯 ROLE & EXPERTISE:
                Act as a Viral Content Strategist & Growth Marketer.

                📋 CONTEXT & OBJECTIVE:
                Create viral, high-engagement content for: $clean

                ⚡ FORMULA & STRUCTURE:
                1. 5 High-CTR Hook Variations (Question, Contrarian, Numbered List, Story, Urgency).
                2. Body: High-retention storytelling pacing with open loops and emotional resonance.
                3. Engagement Driver: High-converting question prompt for comment section explosion.
                4. Clear Action Trigger: Direct conversion CTA.

                🎨 TONE:
                High energy, conversational, authentic, and magnetic.

                📤 OUTPUT FORMAT:
                Ready-to-copy social post template with formatting and hashtag recommendations.
                """.trimIndent()

                else -> """
                🎯 ROLE & EXPERTISE:
                Act as a Direct-Response Email Marketing Master.

                📋 CONTEXT & OBJECTIVE:
                Campaign: $clean

                ⚡ EMAIL SEQUENCE ARCHITECTURE:
                1. 3 Click-Worthy Subject Lines + Preview Text.
                2. Opening Hook: Relatable pain point or intriguing story.
                3. Agitation & Breakthrough: Why usual solutions fail and the new paradigm.
                4. Irresistible Offer Presentation & Frictionless Call to Action.
                5. High-Impact P.S. line reinforcing scarcity or core benefit.

                📤 OUTPUT FORMAT:
                Full ready-to-send email copy formatted in Markdown.
                """.trimIndent()
            }
        }

        // 4. Learning, Study & Research
        val isStudy = category.contains("Study", ignoreCase = true) ||
                lower.contains("explain") || lower.contains("learn") || lower.contains("study") ||
                lower.contains("how does") || lower.contains("teach me") || lower.contains("summary")

        if (isStudy) {
            return """
            🎯 ROLE & EXPERTISE:
            Act as an elite cognitive educator and domain specialist utilizing the Feynman Technique and First-Principles thinking.

            📋 CONTEXT & OBJECTIVE:
            Subject to Master: $clean

            ⚡ STEP-BY-STEP INSTRUCTIONS:
            1. The Plain-English Analogy: Explain the fundamental core concept simply enough for a bright 12-year-old using a vivid, relatable analogy.
            2. Deep-Dive Mechanics: Unpack the precise technical mechanisms, key terminology, and real-world cause-and-effect relationships.
            3. Common Misconceptions: Expose the 2 most frequent beginner misunderstandings and why they are flawed.
            4. Active Recall Quiz: Provide 3 diagnostic questions to verify deep conceptual comprehension (hide the answers at the end).
            5. Memory Anchor: Provide a concise mental model or mnemonic to retain this insight permanently.

            🎨 TONE & STYLE:
            Lucid, engaging, illuminating, and intellectually rigorous ($style).

            🛑 CONSTRAINTS & WHAT TO AVOID:
            - Eliminate dense academic fluff and circular definitions.
            - Ensure all technical terms introduced are immediately anchored in intuitive context.

            📤 OUTPUT FORMAT:
            Well-organized Markdown with distinct headings, bulleted takeaways, and a callout box for the core takeaway.
            """.trimIndent()
        }

        // 5. Universal Master Prompt Optimizer
        return when (v) {
            0 -> """
            🎯 ROLE & EXPERTISE:
            Act as a world-leading specialist and elite strategic advisor in this domain.

            📋 CONTEXT & OBJECTIVE:
            Task: $clean
            Goal: Deliver an extraordinarily thorough, high-value, and actionable response that directly accomplishes the user's objective with zero fluff.

            ⚡ STEP-BY-STEP INSTRUCTIONS:
            1. Contextual Setup: Establish the foundational principles and parameters needed for an optimal solution.
            2. Core Execution: Deliver a step-by-step, granular solution addressing $clean with concrete real-world specifics.
            3. Edge Cases & Guardrails: Identify potential pitfalls, hidden risks, and how to proactively avoid them.
            4. Actionable Next Steps: Provide an immediate 3-step action checklist the user can execute right now.

            🎨 TONE & STYLE:
            $style, authoritative, engaging, and razor-sharp. Focused entirely on dense, practical utility.

            🛑 CONSTRAINTS & WHAT TO AVOID:
            - Do NOT include filler, preamble, or robotic introductions like "Sure, I would be happy to help...".
            - Avoid vague or surface-level generalizations; every point must be concrete and actionable.

            📤 OUTPUT FORMAT:
            Use clean Markdown with bold headers, bulleted lists, and a highlighted summary section.
            """.trimIndent()

            1 -> """
            🎯 ROLE & EXPERTISE:
            Act as a Senior Domain Consultant and Executive Decision Advisor.

            📋 CONTEXT & OBJECTIVE:
            Challenge: $clean

            ⚡ DEEP-DIVE FRAMEWORK:
            1. Root Cause & Strategic Diagnosis: What are the key drivers and levers?
            2. Best-in-Class Blueprint: Comprehensive execution roadmap with exact milestones.
            3. Resource & Risk Analysis: Critical constraints, trade-offs, and mitigation plans.
            4. Concrete Deliverables: Exact templates, checklists, or scripts needed for execution.

            🎨 TONE:
            Strategic, data-driven, decisive, and pragmatic ($style).

            📤 OUTPUT FORMAT:
            Executive briefing format with bulleted analysis and actionable blueprints.
            """.trimIndent()

            else -> """
            🎯 ROLE & EXPERTISE:
            Act as a Top-Tier Specialist executing on: $clean

            📋 GOAL:
            Produce an immediate, best-possible output solving $clean with extreme precision.

            ⚡ EXECUTION STEPS:
            1. Deliver the complete, finalized solution immediately.
            2. Highlight 3 pro tips for maximum effectiveness.
            3. Detail troubleshooting steps for any edge cases.

            🛑 CONSTRAINTS:
            Zero fluff, maximum practical value.

            📤 OUTPUT FORMAT:
            Clean Markdown with bold headings and high-density practical recommendations.
            """.trimIndent()
        }
    }
}
