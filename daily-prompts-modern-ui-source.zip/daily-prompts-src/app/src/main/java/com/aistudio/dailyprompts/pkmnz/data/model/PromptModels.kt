package com.aistudio.dailyprompts.pkmnz.data.model

enum class PromptCategory(
    val displayName: String,
    val icon: String,
    val countLabel: String = "100+ Prompts"
) {
    ALL("All Prompts", "✨", "500+ Prompts"),
    MOTIVATION("Motivation", "⚡", "120+ Prompts"),
    SELF_CARE("Self Care", "🌿", "95+ Prompts"),
    PRODUCTIVITY("Productivity", "💻", "100+ Prompts"),
    CREATIVITY("Creativity", "🎨", "80+ Prompts"),
    RELATIONSHIPS("Relationships", "❤️", "75+ Prompts"),
    MINDFULNESS("Mindfulness", "🧘", "90+ Prompts"),
    HEALTH("Health", "🏃", "70+ Prompts"),
    LIFESTYLE("Lifestyle", "🪴", "85+ Prompts"),

    // Tech & Media categories (preserved for full compatibility)
    BOY("Boy & Male Style", "👦", "60+ Prompts"),
    GIRL("Girl & Aesthetics", "👧", "70+ Prompts"),
    NATURE("Nature & Landscapes", "🌿", "80+ Prompts"),
    AI_ART("AI Art & Image", "🎨", "90+ Prompts"),
    CHAT_GPT("ChatGPT & Writing", "✍️", "110+ Prompts"),
    CODING("Coding & Tech", "💻", "65+ Prompts"),
    SOCIAL_MEDIA("Social & Reels", "📱", "55+ Prompts"),
    BUSINESS("Business & Sales", "💼", "50+ Prompts"),
    STUDY("Study & Learning", "🧠", "60+ Prompts")
}

enum class AiTool(val displayName: String, val badgeHex: Long) {
    CHATGPT("ChatGPT", 0xFF10A37F),
    MIDJOURNEY("Midjourney", 0xFF7C3AED),
    CLAUDE("Claude", 0xFFD97706),
    GEMINI("Gemini", 0xFF2563EB),
    FLUX("Flux / SD", 0xFFDB2777),
    GENERAL("Any AI", 0xFF4F46E5)
}

