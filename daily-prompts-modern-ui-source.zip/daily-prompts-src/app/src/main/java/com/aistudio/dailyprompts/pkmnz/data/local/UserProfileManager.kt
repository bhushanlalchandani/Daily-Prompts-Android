package com.aistudio.dailyprompts.pkmnz.data.local

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.aistudio.dailyprompts.pkmnz.data.model.UserProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * Manages persistent storage of the user account and profile data.
 *
 * Uses SharedPreferences for profile attributes and private app internal storage
 * for custom profile avatar images, ensuring 100% offline persistence across app restarts.
 */
class UserProfileManager(private val context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val avatarFile = File(context.filesDir, AVATAR_FILE_NAME)

    fun loadProfile(): UserProfile {
        val name = prefs.getString(KEY_NAME, UserProfile.DEFAULT_NAME) ?: UserProfile.DEFAULT_NAME
        val bio = prefs.getString(KEY_BIO, UserProfile.DEFAULT_BIO) ?: UserProfile.DEFAULT_BIO
        val email = prefs.getString(KEY_EMAIL, UserProfile.DEFAULT_EMAIL) ?: UserProfile.DEFAULT_EMAIL
        val avatarType = prefs.getString(KEY_AVATAR_TYPE, UserProfile.AVATAR_DEFAULT) ?: UserProfile.AVATAR_DEFAULT
        val savedPath = prefs.getString(KEY_CUSTOM_AVATAR_PATH, null)

        val customPath = if (savedPath != null && avatarFile.exists() && avatarFile.length() > 0L) {
            avatarFile.absolutePath
        } else {
            null
        }

        val resolvedType = if (avatarType == UserProfile.AVATAR_CUSTOM && customPath == null) {
            UserProfile.AVATAR_DEFAULT
        } else {
            avatarType
        }

        return UserProfile(
            name = name,
            bio = bio,
            email = email,
            avatarType = resolvedType,
            customAvatarPath = customPath
        )
    }

    suspend fun saveProfile(
        name: String,
        bio: String,
        email: String = UserProfile.DEFAULT_EMAIL,
        avatarType: String = UserProfile.AVATAR_DEFAULT,
        customAvatarPath: String? = null
    ): UserProfile = withContext(Dispatchers.IO) {
        val cleanName = name.trim().ifEmpty { UserProfile.DEFAULT_NAME }
        val cleanBio = bio.trim()
        val cleanEmail = email.trim()

        prefs.edit()
            .putString(KEY_NAME, cleanName)
            .putString(KEY_BIO, cleanBio)
            .putString(KEY_EMAIL, cleanEmail)
            .putString(KEY_AVATAR_TYPE, avatarType)
            .putString(KEY_CUSTOM_AVATAR_PATH, customAvatarPath)
            .commit()

        UserProfile(
            name = cleanName,
            bio = cleanBio,
            email = cleanEmail,
            avatarType = avatarType,
            customAvatarPath = customAvatarPath
        )
    }

    suspend fun saveCustomAvatarPhoto(uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        try {
            val tempFile = File(context.cacheDir, "temp_avatar_${System.currentTimeMillis()}.tmp")
            try {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(tempFile).use { output ->
                        input.copyTo(output)
                    }
                } ?: return@withContext Result.failure(IllegalArgumentException("Cannot open image stream"))

                if (!tempFile.exists() || tempFile.length() == 0L) {
                    return@withContext Result.failure(IllegalArgumentException("Empty image file"))
                }

                val boundsOptions = BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }
                BitmapFactory.decodeFile(tempFile.absolutePath, boundsOptions)

                val width = boundsOptions.outWidth
                val height = boundsOptions.outHeight
                if (width <= 0 || height <= 0) {
                    return@withContext Result.failure(IllegalArgumentException("Invalid image dimensions"))
                }

                // Downsample to max dimension 512px for efficient avatar memory usage
                val maxDim = 512
                var sampleSize = 1
                while ((width / sampleSize) > maxDim || (height / sampleSize) > maxDim) {
                    sampleSize *= 2
                }

                val decodeOptions = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }

                val bitmap = BitmapFactory.decodeFile(tempFile.absolutePath, decodeOptions)
                    ?: return@withContext Result.failure(IllegalStateException("Failed to decode image"))

                FileOutputStream(avatarFile).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
                }
                bitmap.recycle()

                val savedPath = avatarFile.absolutePath
                prefs.edit()
                    .putString(KEY_CUSTOM_AVATAR_PATH, savedPath)
                    .putString(KEY_AVATAR_TYPE, UserProfile.AVATAR_CUSTOM)
                    .commit()

                Result.success(savedPath)
            } finally {
                if (tempFile.exists()) {
                    tempFile.delete()
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun clearCustomAvatarPhoto() = withContext(Dispatchers.IO) {
        try {
            if (avatarFile.exists()) {
                avatarFile.delete()
            }
        } catch (_: Exception) { }

        prefs.edit()
            .remove(KEY_CUSTOM_AVATAR_PATH)
            .putString(KEY_AVATAR_TYPE, UserProfile.AVATAR_DEFAULT)
            .commit()
    }

    suspend fun resetProfile(): UserProfile = withContext(Dispatchers.IO) {
        clearCustomAvatarPhoto()
        prefs.edit().clear().commit()
        loadProfile()
    }

    companion object {
        private const val PREFS_NAME = "user_profile_prefs"
        private const val KEY_NAME = "profile_name"
        private const val KEY_BIO = "profile_bio"
        private const val KEY_EMAIL = "profile_email"
        private const val KEY_AVATAR_TYPE = "profile_avatar_type"
        private const val KEY_CUSTOM_AVATAR_PATH = "profile_custom_avatar_path"
        private const val AVATAR_FILE_NAME = "user_avatar_photo.jpg"
    }
}
