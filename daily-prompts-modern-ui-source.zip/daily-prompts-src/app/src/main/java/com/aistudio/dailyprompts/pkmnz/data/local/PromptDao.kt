package com.aistudio.dailyprompts.pkmnz.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PromptDao {
    @Query("SELECT * FROM prompts WHERE isDisliked = 0 ORDER BY createdAt DESC")
    fun getAllPrompts(): Flow<List<PromptEntity>>

    @Query("SELECT * FROM prompts WHERE isFavorite = 1 AND isDisliked = 0 ORDER BY createdAt DESC")
    fun getFavoritePrompts(): Flow<List<PromptEntity>>

    @Query("SELECT * FROM prompts WHERE category = :category AND isDisliked = 0 ORDER BY createdAt DESC")
    fun getPromptsByCategory(category: String): Flow<List<PromptEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrompt(prompt: PromptEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrompts(prompts: List<PromptEntity>)

    @Update
    suspend fun updatePrompt(prompt: PromptEntity)

    @Query("UPDATE prompts SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavorite(id: Long, isFavorite: Boolean)

    @Query("UPDATE prompts SET isDisliked = 1 WHERE id = :id")
    suspend fun markPromptDisliked(id: Long)

    @Query("UPDATE prompts SET isDisliked = 1 WHERE category = :category")
    suspend fun markCategoryDisliked(category: String)

    @Query("UPDATE prompts SET isDisliked = 0 WHERE category = :category")
    suspend fun unmarkCategoryDisliked(category: String)

    @Query("DELETE FROM prompts WHERE id = :id")
    suspend fun deletePromptById(id: Long)

    @Query("SELECT * FROM prompts WHERE id = :id LIMIT 1")
    suspend fun getPromptById(id: Long): PromptEntity?

    @Query("SELECT * FROM prompts WHERE promptText = :promptText LIMIT 1")
    suspend fun findPromptByText(promptText: String): PromptEntity?

    @Query("SELECT * FROM prompts WHERE isDaily = 1 AND isDisliked = 0 ORDER BY id ASC")
    suspend fun getDailyPromptsSync(): List<PromptEntity>

    @Query("SELECT COUNT(*) FROM prompts")
    suspend fun getPromptCount(): Int

    @Query("SELECT title FROM prompts")
    suspend fun getAllPromptTitles(): List<String>

    @Query("DELETE FROM prompts WHERE isFavorite = 0 AND isDaily = 1")
    suspend fun clearStaleDailyPrompts()

    @Query("DELETE FROM prompts WHERE isFavorite = 0 AND isDaily = 0 AND createdAt < :threshold")
    suspend fun clearOldUnsavedPrompts(threshold: Long)

    // Disliked Types Management
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDislikedType(type: DislikedTypeEntity): Long

    @Query("SELECT * FROM disliked_types ORDER BY timestamp DESC")
    fun getAllDislikedTypes(): Flow<List<DislikedTypeEntity>>

    @Query("DELETE FROM disliked_types WHERE category = :category")
    suspend fun removeDislikedTypeByCategory(category: String)

    @Query("DELETE FROM disliked_types WHERE id = :id")
    suspend fun deleteDislikedTypeById(id: Long)

    @Query("SELECT category FROM disliked_types")
    suspend fun getDislikedCategories(): List<String>

    // Generated Prompts History Cache (Last 10 for offline access)
    @Query("SELECT * FROM generated_history ORDER BY createdAt DESC LIMIT 10")
    fun getRecentGeneratedPrompts(): Flow<List<GeneratedPromptEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGeneratedPrompt(item: GeneratedPromptEntity): Long

    @Query("DELETE FROM generated_history WHERE id NOT IN (SELECT id FROM generated_history ORDER BY createdAt DESC LIMIT 10)")
    suspend fun trimGeneratedHistory()

    @Query("DELETE FROM generated_history WHERE id = :id")
    suspend fun deleteGeneratedPrompt(id: Long)

    @Query("DELETE FROM generated_history")
    suspend fun clearGeneratedHistory()

    @Query("SELECT COUNT(*) FROM generated_history")
    suspend fun getGeneratedHistoryCount(): Int
}
