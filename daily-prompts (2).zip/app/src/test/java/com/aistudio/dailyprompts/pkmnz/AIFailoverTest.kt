package com.aistudio.dailyprompts.pkmnz

import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIModels
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIPromptRequest
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIProvider
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIProviderError
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIProviderManager
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIProviderResult
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.GeminiProvider
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.OpenAIProvider
import kotlinx.coroutines.runBlocking
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.junit.Test

/**
 * Comprehensive Unit Test Suite for AI Provider Failover and Automatic Vision Fallback:
 *
 * Requirements tested:
 *  a. Gemini succeeds (Text generation & Vision analysis).
 *  b. Gemini returns HTTP 429 / RESOURCE_EXHAUSTED and OpenAI succeeds (Text & Vision fallback).
 *  c. Gemini quota is exhausted and OpenAI is unavailable (or missing API key).
 *  d. Both API keys are missing.
 *  e. Network failure (Gemini network error fails over to OpenAI; both fail returns network diagnostics).
 *  f. Invalid API key (does not attempt failover to prevent masked auth issues or quota leaks).
 *  g. Image input formatting and response parsing for both Gemini and OpenAI Vision.
 *  h. Infinite retry loop prevention (zero redundant loops on 429 quota exhaustion).
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AIFailoverTest {

    private class MockAIProvider(
        override val name: String,
        var resultToReturn: AIProviderResult
    ) : AIProvider {
        var callCount = 0
        var lastReceivedRequest: AIPromptRequest? = null

        override suspend fun generatePrompt(request: AIPromptRequest): AIProviderResult {
            callCount++
            lastReceivedRequest = request
            return resultToReturn
        }
    }

    private val textRequest = AIPromptRequest(
        topic = "Portrait of a cyberpunk boy in neon rain",
        targetAi = "Midjourney",
        category = "Boy",
        style = "Cinematic",
        dislikedTypes = listOf("anime", "sketch"),
        systemPrompt = "Custom System Instruction",
        temperature = 0.8,
        maxTokens = 1200
    )

    private val imageRequest = AIPromptRequest(
        topic = "Analyze this image and describe the lighting, subject, and composition",
        targetAi = "Midjourney / Vision",
        category = "Visual Art",
        style = "Descriptive",
        imageBase64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=",
        imageMimeType = "image/png"
    )

    // =========================================================================
    // a. Gemini succeeds
    // =========================================================================

    @Test
    fun test_a_GeminiSucceeds_TextGeneration() = runBlocking {
        val mockGemini = MockAIProvider(
            name = "Gemini",
            resultToReturn = AIProviderResult.Success("Gemini master text prompt", "Gemini")
        )
        val mockOpenAI = MockAIProvider(
            name = "OpenAI",
            resultToReturn = AIProviderResult.Success("OpenAI should not be called", "OpenAI")
        )

        val manager = AIProviderManager(
            geminiProvider = mockGemini,
            openAIProvider = mockOpenAI
        )

        val result = manager.generatePrompt(textRequest)

        assertTrue(result is AIProviderResult.Success)
        val success = result as AIProviderResult.Success
        assertEquals("Gemini master text prompt", success.text)
        assertEquals("Gemini", success.providerName)
        assertEquals(1, mockGemini.callCount)
        assertEquals(0, mockOpenAI.callCount) // Secondary provider NEVER called when primary succeeds
    }

    @Test
    fun test_a_GeminiSucceeds_ImageAnalysis() = runBlocking {
        val mockGemini = MockAIProvider(
            name = "Gemini",
            resultToReturn = AIProviderResult.Success("Gemini descriptive visual prompt", "Gemini")
        )
        val mockOpenAI = MockAIProvider(
            name = "OpenAI",
            resultToReturn = AIProviderResult.Success("OpenAI should not be called", "OpenAI")
        )

        val manager = AIProviderManager(
            geminiProvider = mockGemini,
            openAIProvider = mockOpenAI
        )

        val result = manager.generatePrompt(imageRequest)

        assertTrue(result is AIProviderResult.Success)
        val success = result as AIProviderResult.Success
        assertEquals("Gemini descriptive visual prompt", success.text)
        assertEquals("Gemini", success.providerName)
        assertEquals(1, mockGemini.callCount)
        assertEquals(0, mockOpenAI.callCount) // Must NOT call fallback if Gemini vision succeeds
    }

    // =========================================================================
    // b. Gemini returns HTTP 429 and OpenAI succeeds
    // =========================================================================

    @Test
    fun test_b_GeminiReturns429_OpenAISucceeds_TextGeneration() = runBlocking {
        val mockGemini = MockAIProvider(
            name = "Gemini",
            resultToReturn = AIProviderResult.Failure(
                AIProviderError.QuotaExhausted("Gemini", "429 RESOURCE_EXHAUSTED: quota exceeded")
            )
        )
        val mockOpenAI = MockAIProvider(
            name = "OpenAI",
            resultToReturn = AIProviderResult.Success("OpenAI fallback text prompt", "OpenAI")
        )

        val manager = AIProviderManager(
            geminiProvider = mockGemini,
            openAIProvider = mockOpenAI
        )

        val result = manager.generatePrompt(textRequest)

        assertTrue(result is AIProviderResult.Success)
        val success = result as AIProviderResult.Success
        assertEquals("OpenAI fallback text prompt", success.text)
        assertEquals("OpenAI", success.providerName)
        assertEquals(1, mockGemini.callCount)
        assertEquals(1, mockOpenAI.callCount)
    }

    @Test
    fun test_b_GeminiReturns429_OpenAIVisionSucceeds_ImageAnalysis() = runBlocking {
        val mockGemini = MockAIProvider(
            name = "Gemini",
            resultToReturn = AIProviderResult.Failure(
                AIProviderError.QuotaExhausted("Gemini", "429 RESOURCE_EXHAUSTED: Gemini vision quota exhausted")
            )
        )
        val mockOpenAI = MockAIProvider(
            name = "OpenAI",
            resultToReturn = AIProviderResult.Success("OpenAI Vision descriptive prompt", "OpenAI")
        )

        val manager = AIProviderManager(
            geminiProvider = mockGemini,
            openAIProvider = mockOpenAI
        )

        val result = manager.generatePrompt(imageRequest)

        assertTrue("Fallback to OpenAI Vision must succeed", result is AIProviderResult.Success)
        val success = result as AIProviderResult.Success
        assertEquals("OpenAI Vision descriptive prompt", success.text)
        assertEquals("OpenAI", success.providerName)
        assertEquals(1, mockGemini.callCount)
        assertEquals(1, mockOpenAI.callCount)
        // Verify image payload was preserved and passed through to OpenAI
        assertEquals(imageRequest.imageBase64, mockOpenAI.lastReceivedRequest?.imageBase64)
        assertEquals(imageRequest.imageMimeType, mockOpenAI.lastReceivedRequest?.imageMimeType)
    }

    // =========================================================================
    // c. Gemini quota exhausted and OpenAI is unavailable / missing key
    // =========================================================================

    @Test
    fun test_c_GeminiQuotaExhausted_OpenAIUnavailable_NullProvider() = runBlocking {
        val mockGemini = MockAIProvider(
            name = "Gemini",
            resultToReturn = AIProviderResult.Failure(
                AIProviderError.QuotaExhausted("Gemini", "429 RESOURCE_EXHAUSTED")
            )
        )

        val manager = AIProviderManager(
            geminiProvider = mockGemini,
            openAIProvider = null
        )

        val result = manager.generatePrompt(imageRequest)

        assertTrue(result is AIProviderResult.Failure)
        val failure = result as AIProviderResult.Failure
        assertTrue(failure.error is AIProviderError.QuotaExhausted)
        assertEquals(1, mockGemini.callCount)
    }

    @Test
    fun test_c_GeminiQuotaExhausted_OpenAIKeyMissing() = runBlocking {
        val mockGemini = MockAIProvider(
            name = "Gemini",
            resultToReturn = AIProviderResult.Failure(
                AIProviderError.QuotaExhausted("Gemini", "429 RESOURCE_EXHAUSTED: quota exceeded")
            )
        )
        val mockOpenAI = MockAIProvider(
            name = "OpenAI",
            resultToReturn = AIProviderResult.Failure(
                AIProviderError.KeyMissing("OpenAI", "OpenAI key not configured in Settings")
            )
        )

        val manager = AIProviderManager(
            geminiProvider = mockGemini,
            openAIProvider = mockOpenAI
        )

        val result = manager.generatePrompt(imageRequest)

        assertTrue(result is AIProviderResult.Failure)
        val failure = result as AIProviderResult.Failure
        assertEquals(1, mockGemini.callCount)
        assertEquals(1, mockOpenAI.callCount)
        assertTrue(failure.error.message.contains("Gemini quota exhausted", ignoreCase = true))
        assertTrue(failure.error.message.contains("OpenAI API key is not configured", ignoreCase = true))
    }

    // =========================================================================
    // d. Both API keys are missing
    // =========================================================================

    @Test
    fun test_d_BothApiKeysMissing() = runBlocking {
        val mockGemini = MockAIProvider(
            name = "Gemini",
            resultToReturn = AIProviderResult.Failure(
                AIProviderError.KeyMissing("Gemini", "Gemini API key is not set")
            )
        )
        val mockOpenAI = MockAIProvider(
            name = "OpenAI",
            resultToReturn = AIProviderResult.Failure(
                AIProviderError.KeyMissing("OpenAI", "OpenAI API key is not configured")
            )
        )

        val manager = AIProviderManager(
            geminiProvider = mockGemini,
            openAIProvider = mockOpenAI
        )

        val result = manager.generatePrompt(textRequest)

        assertTrue(result is AIProviderResult.Failure)
        val failure = result as AIProviderResult.Failure
        assertTrue(
            "Should inform user that both keys are unconfigured",
            failure.error.message.contains("Both Gemini and OpenAI API keys are unconfigured", ignoreCase = true)
        )
    }

    // =========================================================================
    // e. Network failure
    // =========================================================================

    @Test
    fun test_e_GeminiNetworkFailure_FailsOverToOpenAISuccessfully() = runBlocking {
        val mockGemini = MockAIProvider(
            name = "Gemini",
            resultToReturn = AIProviderResult.Failure(
                AIProviderError.NetworkError("Gemini", "Connection timed out")
            )
        )
        val mockOpenAI = MockAIProvider(
            name = "OpenAI",
            resultToReturn = AIProviderResult.Success("Prompt generated via OpenAI after network retry", "OpenAI")
        )

        val manager = AIProviderManager(
            geminiProvider = mockGemini,
            openAIProvider = mockOpenAI
        )

        val result = manager.generatePrompt(textRequest)

        assertTrue(result is AIProviderResult.Success)
        val success = result as AIProviderResult.Success
        assertEquals("Prompt generated via OpenAI after network retry", success.text)
        assertEquals(1, mockGemini.callCount)
        assertEquals(1, mockOpenAI.callCount)
    }

    @Test
    fun test_e_BothProvidersNetworkFailure_ReturnsCleanDiagnostic() = runBlocking {
        val mockGemini = MockAIProvider(
            name = "Gemini",
            resultToReturn = AIProviderResult.Failure(
                AIProviderError.NetworkError("Gemini", "Unable to resolve host")
            )
        )
        val mockOpenAI = MockAIProvider(
            name = "OpenAI",
            resultToReturn = AIProviderResult.Failure(
                AIProviderError.NetworkError("OpenAI", "Unable to resolve host")
            )
        )

        val manager = AIProviderManager(
            geminiProvider = mockGemini,
            openAIProvider = mockOpenAI
        )

        val result = manager.generatePrompt(textRequest)

        assertTrue(result is AIProviderResult.Failure)
        val failure = result as AIProviderResult.Failure
        assertTrue(
            failure.error.message.contains("Network connection failed", ignoreCase = true)
        )
    }

    // =========================================================================
    // f. Invalid API key
    // =========================================================================

    @Test
    fun test_f_GeminiInvalidApiKey_DoesNotFailOverToOpenAI() = runBlocking {
        val mockGemini = MockAIProvider(
            name = "Gemini",
            resultToReturn = AIProviderResult.Failure(
                AIProviderError.InvalidApiKey("Gemini", "API_KEY_INVALID: 401 Unauthorized")
            )
        )
        val mockOpenAI = MockAIProvider(
            name = "OpenAI",
            resultToReturn = AIProviderResult.Success("Should NOT be reached", "OpenAI")
        )

        val manager = AIProviderManager(
            geminiProvider = mockGemini,
            openAIProvider = mockOpenAI
        )

        val result = manager.generatePrompt(textRequest)

        assertTrue(result is AIProviderResult.Failure)
        val failure = result as AIProviderResult.Failure
        assertTrue(failure.error is AIProviderError.InvalidApiKey)
        assertEquals(1, mockGemini.callCount)
        assertEquals(0, mockOpenAI.callCount) // Failover must NOT run on invalid key to avoid masking auth errors
    }

    // =========================================================================
    // g. Image input and response parsing
    // =========================================================================

    @Test
    fun test_g_OpenAIVisionPayloadAndResponseParsing() = runBlocking {
        var interceptedRequestBody = ""
        var interceptedAuthHeader = ""

        val mockClient = OkHttpClient.Builder()
            .addInterceptor { chain ->
                val request = chain.request()
                interceptedAuthHeader = request.header("Authorization").orEmpty()
                val buffer = okio.Buffer()
                request.body?.writeTo(buffer)
                interceptedRequestBody = buffer.readUtf8()

                val fakeSuccessResponse = """
                    {
                      "id": "chatcmpl-test-vision-123",
                      "object": "chat.completion",
                      "choices": [
                        {
                          "index": 0,
                          "message": {
                            "role": "assistant",
                            "content": "A high-fashion editorial portrait illuminated by soft neon sidelight, captured with an 85mm f/1.4 lens, cinematic color grading."
                          },
                          "finish_reason": "stop"
                        }
                      ],
                      "usage": { "prompt_tokens": 120, "completion_tokens": 45, "total_tokens": 165 }
                    }
                """.trimIndent()

                Response.Builder()
                    .request(request)
                    .protocol(Protocol.HTTP_1_1)
                    .code(200)
                    .message("OK")
                    .body(fakeSuccessResponse.toResponseBody("application/json".toMediaType()))
                    .build()
            }
            .build()

        val provider = OpenAIProvider(
            httpClient = mockClient,
            apiKeyProvider = { "sk-test-openai-key-abc123xyz" },
            baseUrl = "https://mock.openai.com/"
        )

        val result = provider.generatePrompt(imageRequest)

        assertTrue(result is AIProviderResult.Success)
        val success = result as AIProviderResult.Success
        assertEquals(
            "A high-fashion editorial portrait illuminated by soft neon sidelight, captured with an 85mm f/1.4 lens, cinematic color grading.",
            success.text
        )
        assertEquals("OpenAI", success.providerName)

        // Verify request payload formatting
        assertEquals("Bearer sk-test-openai-key-abc123xyz", interceptedAuthHeader)
        val jsonPayload = JSONObject(interceptedRequestBody)
        assertEquals(AIModels.OPENAI_DEFAULT, jsonPayload.getString("model"))

        val messages = jsonPayload.getJSONArray("messages")
        assertEquals(2, messages.length()) // system message + user message
        val userMsg = messages.getJSONObject(1)
        val userContent = userMsg.getJSONArray("content")
        assertEquals(2, userContent.length()) // text part + image_url part

        val textPart = userContent.getJSONObject(0)
        assertEquals("text", textPart.getString("type"))
        assertTrue(textPart.getString("text").contains("Analyze the uploaded image in depth"))

        val imagePart = userContent.getJSONObject(1)
        assertEquals("image_url", imagePart.getString("type"))
        val imageUrlObj = imagePart.getJSONObject("image_url")
        assertEquals("auto", imageUrlObj.getString("detail"))
        assertTrue(imageUrlObj.getString("url").startsWith("data:image/png;base64,"))
    }

    @Test
    fun test_g_GeminiVisionPayloadAndResponseParsing() = runBlocking {
        var interceptedRequestBody = ""
        var interceptedKeyHeader = ""
        var interceptedUrl = ""

        val mockClient = OkHttpClient.Builder()
            .addInterceptor { chain ->
                val request = chain.request()
                interceptedKeyHeader = request.header("x-goog-api-key").orEmpty()
                interceptedUrl = request.url.toString()
                val buffer = okio.Buffer()
                request.body?.writeTo(buffer)
                interceptedRequestBody = buffer.readUtf8()

                val fakeSuccessResponse = """
                    {
                      "candidates": [
                        {
                          "content": {
                            "parts": [
                              {
                                "text": "Masterpiece golden-hour portrait of a young model looking through window blinds, warm amber highlights, 35mm film aesthetic."
                              }
                            ],
                            "role": "model"
                          },
                          "finishReason": "STOP"
                        }
                      ]
                    }
                """.trimIndent()

                Response.Builder()
                    .request(request)
                    .protocol(Protocol.HTTP_1_1)
                    .code(200)
                    .message("OK")
                    .body(fakeSuccessResponse.toResponseBody("application/json".toMediaType()))
                    .build()
            }
            .build()

        val provider = GeminiProvider(
            httpClient = mockClient,
            apiKeyProvider = { "AIzaSyFakeGeminiKey789" },
            baseUrl = "https://mock.gemini.com/"
        )

        val result = provider.generatePrompt(imageRequest)

        assertTrue(result is AIProviderResult.Success)
        val success = result as AIProviderResult.Success
        assertEquals(
            "Masterpiece golden-hour portrait of a young model looking through window blinds, warm amber highlights, 35mm film aesthetic.",
            success.text
        )
        assertEquals("Gemini", success.providerName)

        // Verify request payload formatting
        assertEquals("AIzaSyFakeGeminiKey789", interceptedKeyHeader)
        assertTrue(interceptedUrl.contains(AIModels.GEMINI_PRIMARY))

        val jsonPayload = JSONObject(interceptedRequestBody)
        val contents = jsonPayload.getJSONArray("contents")
        val parts = contents.getJSONObject(0).getJSONArray("parts")
        assertEquals(2, parts.length()) // inlineData + text

        val inlineDataPart = parts.getJSONObject(0).getJSONObject("inlineData")
        assertEquals("image/png", inlineDataPart.getString("mimeType"))
        assertEquals(imageRequest.imageBase64, inlineDataPart.getString("data"))
    }

    // =========================================================================
    // h. Ensure fallback does not create infinite retry loops
    // =========================================================================

    @Test
    fun test_h_QuotaExhaustionDoesNotLoopInfinitely() = runBlocking {
        var geminiCallCount = 0
        var openAICallCount = 0

        val mockClient = OkHttpClient.Builder()
            .addInterceptor { chain ->
                val host = chain.request().url.host
                if (host.contains("gemini")) {
                    geminiCallCount++
                    val error429 = """
                        {
                          "error": {
                            "code": 429,
                            "message": "Resource has been exhausted (e.g. check quota).",
                            "status": "RESOURCE_EXHAUSTED"
                          }
                        }
                    """.trimIndent()
                    Response.Builder()
                        .request(chain.request())
                        .protocol(Protocol.HTTP_1_1)
                        .code(429)
                        .message("Too Many Requests")
                        .header("Retry-After", "30")
                        .body(error429.toResponseBody("application/json".toMediaType()))
                        .build()
                } else {
                    openAICallCount++
                    val error429 = """
                        {
                          "error": {
                            "message": "You exceeded your current quota, please check your plan and billing details.",
                            "type": "insufficient_quota",
                            "code": "insufficient_quota"
                          }
                        }
                    """.trimIndent()
                    Response.Builder()
                        .request(chain.request())
                        .protocol(Protocol.HTTP_1_1)
                        .code(429)
                        .message("Too Many Requests")
                        .body(error429.toResponseBody("application/json".toMediaType()))
                        .build()
                }
            }
            .build()

        val geminiProvider = GeminiProvider(
            httpClient = mockClient,
            apiKeyProvider = { "AIzaSyTestKey12345" },
            baseUrl = "https://mock.gemini.com/"
        )
        val openAIProvider = OpenAIProvider(
            httpClient = mockClient,
            apiKeyProvider = { "sk-testOpenAIKey12345" },
            baseUrl = "https://mock.openai.com/"
        )

        val manager = AIProviderManager(
            geminiProvider = geminiProvider,
            openAIProvider = openAIProvider
        )

        val result = manager.generatePrompt(imageRequest)

        // Ensure both providers returned on 429 immediately without retry loops
        assertTrue(result is AIProviderResult.Failure)
        assertEquals("Gemini must be called exactly once on 429", 1, geminiCallCount)
        assertEquals("OpenAI fallback must be called exactly once on 429", 1, openAICallCount)
    }

    // =========================================================================
    // Model Constants verification
    // =========================================================================

    @Test
    fun testModelConstantsIntegrity() {
        assertEquals("gemini-3.8-flash", AIModels.GEMINI_PRIMARY)
        assertEquals("gemini-flash-latest", AIModels.GEMINI_FALLBACK)
        assertEquals("gpt-4o-mini", AIModels.OPENAI_DEFAULT)
        assertEquals(listOf("gemini-3.8-flash", "gemini-flash-latest"), AIModels.GEMINI_MODELS)
        assertFalse(AIModels.GEMINI_MODELS.contains("gemini-1.5-flash"))
    }
}
