package com.aistudio.dailyprompts.pkmnz.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aistudio.dailyprompts.pkmnz.ui.components.AppearanceBottomSheet
import com.aistudio.dailyprompts.pkmnz.ui.components.CategoryFilterBar
import com.aistudio.dailyprompts.pkmnz.ui.components.DailyHeroCard
import com.aistudio.dailyprompts.pkmnz.ui.components.PromptCard
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedBackground
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedBorder
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedButtonSecondary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedCardContainer
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedCardSurface
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedTextLabel
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedTextPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedTextSecondary
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.PromptViewModel

@Composable
fun DailyPromptsScreen(
    viewModel: PromptViewModel,
    onNavigateToScratchpad: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val prompts by viewModel.allPrompts.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val recentlyCopiedId by viewModel.recentlyCopiedId.collectAsStateWithLifecycle()
    val dailyFeatured by viewModel.dailyFeaturedPrompt.collectAsStateWithLifecycle()
    val dislikedTypes by viewModel.dislikedTypes.collectAsStateWithLifecycle()
    val haptic = LocalHapticFeedback.current
    var showAppearanceSheet by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Transparent)
            .testTag("daily_prompts_screen"),
        contentPadding = PaddingValues(bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Header & Branding (Sophisticated Dark Aesthetic)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "DAILY CREATIVE",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.6.sp,
                            color = SophisticatedPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "PromptGen",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = SophisticatedTextPrimary
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Appearance / Cover Photo Button
                        Surface(
                            shape = CircleShape,
                            color = SophisticatedCardSurface,
                            border = BorderStroke(1.dp, SophisticatedBorder),
                            modifier = Modifier.size(44.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    showAppearanceSheet = true
                                },
                                modifier = Modifier.testTag("appearance_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Palette,
                                    contentDescription = "Appearance & Cover Photo",
                                    tint = SophisticatedPrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        // Auto-Roll / Generate New Button
                        Surface(
                            shape = CircleShape,
                            color = SophisticatedCardSurface,
                            border = BorderStroke(1.dp, SophisticatedBorder),
                            modifier = Modifier.size(44.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    viewModel.rollFreshPrompts()
                                },
                                modifier = Modifier.testTag("roll_fresh_prompts_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Roll Fresh Prompts",
                                    tint = SophisticatedPrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Daily Featured Hero Card
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                DailyHeroCard(
                    prompt = dailyFeatured,
                    isRecentlyCopied = (recentlyCopiedId == dailyFeatured.id),
                    onCopy = { ctx, text, id -> viewModel.copyPrompt(ctx, text, id) },
                    onShare = { ctx, text, title -> viewModel.sharePrompt(ctx, text, title) },
                    onDislike = { prompt -> viewModel.dislikePrompt(prompt) }
                )
            }
        }

        // Active Disliked Types Filter Bar (if any types disliked)
        if (dislikedTypes.isNotEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Block,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "DISLIKED / BLOCKED CATEGORIES (WILL NOT BE CREATED)",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.1.sp,
                            color = SophisticatedTextSecondary
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        dislikedTypes.distinctBy { it.category }.forEach { disliked ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = SophisticatedCardContainer,
                                border = BorderStroke(1.dp, SophisticatedBorder)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = disliked.category,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SophisticatedTextPrimary
                                    )
                                    IconButton(
                                        onClick = {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            viewModel.unblockCategory(disliked.category)
                                        },
                                        modifier = Modifier.size(18.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Clear,
                                            contentDescription = "Unblock ${disliked.category}",
                                            tint = SophisticatedTextSecondary,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Search Bar (Dark Container & Outline)
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                placeholder = {
                    Text(
                        "Search prompts, keywords, or AI models...",
                        color = SophisticatedTextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = SophisticatedTextSecondary
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                viewModel.setSearchQuery("")
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Clear search",
                                tint = SophisticatedTextSecondary
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = SophisticatedCardSurface,
                    unfocusedContainerColor = SophisticatedCardSurface,
                    focusedBorderColor = SophisticatedPrimary,
                    unfocusedBorderColor = SophisticatedBorder,
                    focusedTextColor = SophisticatedTextPrimary,
                    unfocusedTextColor = SophisticatedTextPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .testTag("prompts_search_input")
            )
        }

        // Category Filter Chips
        item {
            CategoryFilterBar(
                selectedCategory = selectedCategory,
                onSelectCategory = { viewModel.setCategory(it) }
            )
        }

        // Section Title with Uppercase Tracking
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (selectedCategory.displayName == "All Prompts") "EXPLORE PROMPTS" else selectedCategory.displayName.uppercase(),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp,
                    color = SophisticatedTextLabel
                )
                Text(
                    text = "${prompts.size} items",
                    style = MaterialTheme.typography.labelSmall,
                    color = SophisticatedTextSecondary
                )
            }
        }

        // Prompts List
        if (prompts.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(36.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (searchQuery.isNotBlank()) "No prompts found matching '$searchQuery'" else "No prompts available for this filter or category is disliked.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = SophisticatedTextSecondary
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            viewModel.setSearchQuery("")
                            viewModel.rollFreshPrompts()
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SophisticatedButtonSecondary,
                            contentColor = SophisticatedTextPrimary
                        )
                    ) {
                        Text("Roll New Prompts")
                    }
                }
            }
        } else {
            items(prompts, key = { it.id }) { prompt ->
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    PromptCard(
                        prompt = prompt,
                        isRecentlyCopied = (recentlyCopiedId == prompt.id),
                        onCopy = { ctx, text, id -> viewModel.copyPrompt(ctx, text, id) },
                        onShare = { ctx, text, title -> viewModel.sharePrompt(ctx, text, title) },
                        onToggleFavorite = { id, fav -> viewModel.toggleFavorite(id, fav) },
                        onDislike = { dislikedPrompt -> viewModel.dislikePrompt(dislikedPrompt) },
                        onEdit = { text ->
                            viewModel.loadIntoScratchpad(text)
                            onNavigateToScratchpad(text)
                        }
                    )
                }
            }
        }
    }

    if (showAppearanceSheet) {
        AppearanceBottomSheet(
            viewModel = viewModel,
            onDismissRequest = { showAppearanceSheet = false }
        )
    }
}
