package com.aistudio.dailyprompts.pkmnz.data.repository

import com.aistudio.dailyprompts.pkmnz.data.generator.SmartPromptEngine
import com.aistudio.dailyprompts.pkmnz.data.local.DislikedTypeEntity
import com.aistudio.dailyprompts.pkmnz.data.local.GeneratedPromptEntity
import com.aistudio.dailyprompts.pkmnz.data.local.PromptDao
import com.aistudio.dailyprompts.pkmnz.data.local.PromptEntity
import com.aistudio.dailyprompts.pkmnz.data.model.PromptCategory
import com.aistudio.dailyprompts.pkmnz.data.remote.GeminiPromptService
import com.aistudio.dailyprompts.pkmnz.data.remote.PromptAiService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

data class PromptGenerationResult(
    val promptText: String,
    val isGemini: Boolean,
    val errorNotice: String? = null
)

private val FEMALE_TOPIC_REGEX = Regex("\\b(girls?|wom[ae]n|females?|ladki|ladkiyan|lady|ladies)\\b", RegexOption.IGNORE_CASE)
private val MALE_TOPIC_REGEX = Regex("\\b(boys?|m[ae]n|males?|ladka|ladke|guy|guys)\\b", RegexOption.IGNORE_CASE)

/**
 * Detects whether a topic is about a girl/woman or boy/man using whole-word matching.
 * (Plain substring checks wrongly matched words like "manga", "human", "romantic" or "boycott".)
 * Returns the matching category display name, or null when the topic is neutral.
 */
fun detectPeopleCategory(topic: String): String? = when {
    FEMALE_TOPIC_REGEX.containsMatchIn(topic) -> PromptCategory.GIRL.displayName
    MALE_TOPIC_REGEX.containsMatchIn(topic) -> PromptCategory.BOY.displayName
    else -> null
}

class PromptRepository(
    private val promptDao: PromptDao,
    private val geminiService: PromptAiService = GeminiPromptService()
) {

    private companion object {
        const val AI_TEXT_TIMEOUT_MS = 30_000L
    }

    val allPrompts: Flow<List<PromptEntity>> = promptDao.getAllPrompts()
    val favoritePrompts: Flow<List<PromptEntity>> = promptDao.getFavoritePrompts()
    val dislikedTypes: Flow<List<DislikedTypeEntity>> = promptDao.getAllDislikedTypes()
    val recentGeneratedPrompts: Flow<List<GeneratedPromptEntity>> = promptDao.getRecentGeneratedPrompts()

    /** Inserts curated seed prompts that are not in the database yet (matched by title). */
    private suspend fun insertMissingSeeds(disliked: Set<String>) {
        val existingTitles = promptDao.getAllPromptTitles().toSet()
        val missingSeeds = SmartPromptEngine.SEED_PROMPTS
            .filter { it.title !in existingTitles && it.category.lowercase() !in disliked }
        if (missingSeeds.isNotEmpty()) {
            promptDao.insertPrompts(missingSeeds)
        }
    }

    /** Inserts only prompts whose text is not already stored, so Explore never shows duplicates. */
    private suspend fun insertNewPrompts(prompts: List<PromptEntity>) {
        if (prompts.isEmpty()) return
        val existingTexts = promptDao.getAllPromptTexts().toHashSet()
        val fresh = prompts.filter { existingTexts.add(it.promptText) }
        if (fresh.isNotEmpty()) {
            promptDao.insertPrompts(fresh)
        }
    }

    suspend fun ensureInitialData() = withContext(Dispatchers.IO) {
        val count = promptDao.getPromptCount()
        val disliked = promptDao.getDislikedCategories().map { it.lowercase() }.toSet()
        if (count == 0) {
            val allSeeds = SmartPromptEngine.SEED_PROMPTS
                .filter { it.category.lowercase() !in disliked }
            promptDao.insertPrompts(allSeeds)
            insertNewPrompts(
                SmartPromptEngine.generateFreshDailyBatch(0)
                    .filter { it.category.lowercase() !in disliked }
            )
        } else {
            insertMissingSeeds(disliked)
        }
    }

    suspend fun rollFreshPrompts(rollSeed: Int = 0): PromptEntity = withContext(Dispatchers.IO) {
        val disliked = promptDao.getDislikedCategories().map { it.lowercase() }.toSet()
        // 1. Clean up old non-favorite daily prompts so stale prompts do not pile up
        promptDao.clearStaleDailyPrompts()

        // 2. Make sure the curated library is present. Previously a "new day" roll skipped this,
        //    so users who opened the app once a day never got the seed library in Explore.
        insertMissingSeeds(disliked)

        // 3. Generate a brand new, diverse batch of creative prompts
        val freshBatch = SmartPromptEngine.generateFreshDailyBatch(rollSeed)
            .filter { it.category.lowercase() !in disliked }

        // 4. Insert fresh batch into database (skipping texts that already exist)
        insertNewPrompts(freshBatch)

        // 5. Return new featured daily prompt
        val candidateFeatured = SmartPromptEngine.getDailyFeaturedPrompt(rollSeed)
        if (candidateFeatured.category.lowercase() !in disliked) {
            candidateFeatured
        } else {
            freshBatch.firstOrNull() ?: candidateFeatured
        }
    }

    suspend fun getDailyPrompts(rollSeed: Int = 0): List<PromptEntity> = withContext(Dispatchers.IO) {
        val disliked = promptDao.getDislikedCategories().map { it.lowercase() }.toSet()
        val candidateFeatured = SmartPromptEngine.getDailyFeaturedPrompt(rollSeed)
        val featured = if (candidateFeatured.category.lowercase() !in disliked) candidateFeatured else getDailyFeatured()
        val dbDaily = promptDao.getDailyPromptsSync().filter { it.category.lowercase() !in disliked }
        val seeds = SmartPromptEngine.SEED_PROMPTS.filter { it.isDaily && it.category.lowercase() !in disliked }
        (listOf(featured) + dbDaily + seeds)
            .distinctBy { it.promptText }
            .take(5)
    }

    suspend fun toggleFavoriteForPrompt(prompt: PromptEntity, currentStatus: Boolean) = withContext(Dispatchers.IO) {
        if (prompt.id != 0L) {
            promptDao.updateFavorite(prompt.id, !currentStatus)
        } else {
            val existing = promptDao.findPromptByText(prompt.promptText)
            if (existing != null) {
                promptDao.updateFavorite(existing.id, !currentStatus)
            } else {
                promptDao.insertPrompt(prompt.copy(isFavorite = !currentStatus))
            }
        }
    }

    /** Reads the real favorite state from the database (UI state flows may be stale/unsubscribed). */
    suspend fun isPromptFavorite(prompt: PromptEntity): Boolean = withContext(Dispatchers.IO) {
        val byId = if (prompt.id != 0L) promptDao.getPromptById(prompt.id) else null
        val entity = byId ?: promptDao.findPromptByText(prompt.promptText)
        entity?.isFavorite == true
    }

    suspend fun toggleFavorite(id: Long, currentStatus: Boolean) = withContext(Dispatchers.IO) {
        promptDao.updateFavorite(id, !currentStatus)
    }

    suspend fun dislikePromptAndType(
        promptId: Long,
        category: String,
        tags: String = "",
        title: String = ""
    ) = withContext(Dispatchers.IO) {
        promptDao.markPromptDisliked(promptId)
        promptDao.markCategoryDisliked(category)
        promptDao.insertDislikedType(
            DislikedTypeEntity(
                category = category,
                tagOrKeyword = tags,
                promptTitle = title
            )
        )
    }

    suspend fun unblockCategory(category: String) = withContext(Dispatchers.IO) {
        promptDao.removeDislikedTypeByCategory(category)
        promptDao.unmarkCategoryDisliked(category)
    }

    suspend fun savePrompt(
        title: String,
        promptText: String,
        category: String,
        aiTool: String,
        tags: String = ""
    ): Long = withContext(Dispatchers.IO) {
        val trimmedPromptText = promptText.trim()
        val existing = promptDao.findPromptByText(trimmedPromptText)
        if (existing != null) {
            // Already exists; prevent duplicate record and update bookmark status
            if (!existing.isFavorite || existing.isDisliked) {
                promptDao.updateFavorite(existing.id, true)
                if (existing.isDisliked) {
                    promptDao.updatePrompt(existing.copy(isFavorite = true, isDisliked = false))
                }
            }
            return@withContext existing.id
        }

        val entity = PromptEntity(
            title = title.ifBlank { "Custom Generated Prompt" },
            promptText = trimmedPromptText,
            category = category,
            aiTool = aiTool,
            tags = tags,
            isFavorite = true,
            isDaily = false,
            isDisliked = false
        )
        promptDao.insertPrompt(entity)
    }

    suspend fun deletePrompt(id: Long) = withContext(Dispatchers.IO) {
        promptDao.deletePromptById(id)
    }

    suspend fun generatePrompt(
        topic: String,
        targetAi: String,
        category: String,
        style: String
    ): PromptGenerationResult = withContext(Dispatchers.IO) {
        val cleanTopic = topic.trim()
        val effectiveCategory = if (category == "All Prompts" || category == "ChatGPT & Writing") {
            detectPeopleCategory(cleanTopic) ?: category
        } else {
            category
        }

        val disliked = promptDao.getDislikedCategories().filter { dislikedCat ->
            !cleanTopic.contains(dislikedCat, ignoreCase = true) &&
                    !effectiveCategory.contains(dislikedCat, ignoreCase = true)
        }

        // 4s was far too short for a real LLM round trip: slower answers were discarded and the
        // user silently got the offline engine while still consuming API quota.
        val geminiResult = kotlinx.coroutines.withTimeoutOrNull(AI_TEXT_TIMEOUT_MS) {
            geminiService.generatePrompt(cleanTopic, targetAi, effectiveCategory, style, disliked)
        }
        val geminiText = geminiResult?.getOrNull()?.trim()

        if (geminiResult != null && geminiResult.isSuccess && !geminiText.isNullOrBlank()) {
            PromptGenerationResult(
                promptText = geminiText,
                isGemini = true
            )
        } else {
            val errorNotice = geminiResult?.exceptionOrNull()?.localizedMessage
            // Intelligent procedural generation fallback guaranteed to produce top-tier results
            val procedural = SmartPromptEngine.buildProceduralPrompt(cleanTopic, targetAi, effectiveCategory, style)
            PromptGenerationResult(
                promptText = procedural,
                isGemini = false,
                errorNotice = errorNotice
            )
        }
    }

    suspend fun analyzeImagePrompt(
        imageBase64: String,
        imageMimeType: String = "image/jpeg",
        localFallbackPrompt: String
    ): PromptGenerationResult = withContext(Dispatchers.IO) {
        // Image-to-prompt must describe the uploaded image, not synthesize a generic
        // telemetry-based substitute. If Vision AI fails, surface the failure instead.
        val generatedText = geminiService
            .analyzeImagePrompt(imageBase64, imageMimeType)
            .getOrThrow()
            .trim()

        if (generatedText.isBlank()) {
            throw IllegalStateException("Vision AI returned an empty description. Please try again.")
        }

        PromptGenerationResult(
            promptText = generatedText,
            isGemini = true
        )
    }

    suspend fun getDailyFeatured(): PromptEntity = withContext(Dispatchers.IO) {
        val disliked = promptDao.getDislikedCategories().map { it.lowercase() }.toSet()
        val allSeeds = SmartPromptEngine.SEED_PROMPTS
        val defaultFeatured = SmartPromptEngine.getDailyFeaturedPrompt()
        if (defaultFeatured.category.lowercase() !in disliked) {
            defaultFeatured
        } else {
            allSeeds.firstOrNull { it.category.lowercase() !in disliked } ?: defaultFeatured
        }
    }

    suspend fun cacheGeneratedPrompt(
        topic: String,
        promptText: String,
        targetAi: String,
        category: String,
        style: String,
        isGemini: Boolean,
        mode: String = "TEXT"
    ): Long = withContext(Dispatchers.IO) {
        val cleanPrompt = promptText.trim()
        if (cleanPrompt.isBlank()) return@withContext 0L
        val entity = GeneratedPromptEntity(
            topic = topic.trim().ifBlank { if (mode == "IMAGE") "Image Analysis Prompt" else "Custom Prompt" },
            promptText = cleanPrompt,
            targetAi = targetAi,
            category = category,
            style = style,
            isGeminiPowered = isGemini,
            mode = mode,
            createdAt = System.currentTimeMillis()
        )
        val id = promptDao.insertGeneratedPrompt(entity)
        // Automatically prune so we retain only the last 10 generated prompts locally in Room
        promptDao.trimGeneratedHistory()
        id
    }

    suspend fun deleteGeneratedPrompt(id: Long) = withContext(Dispatchers.IO) {
        promptDao.deleteGeneratedPrompt(id)
    }

    suspend fun clearGeneratedHistory() = withContext(Dispatchers.IO) {
        promptDao.clearGeneratedHistory()
    }
}
