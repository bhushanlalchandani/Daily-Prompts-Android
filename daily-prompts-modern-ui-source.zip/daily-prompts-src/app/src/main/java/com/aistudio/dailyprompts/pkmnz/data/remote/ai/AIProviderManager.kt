package com.aistudio.dailyprompts.pkmnz.data.remote.ai

/**
 * Manages AI prompt generation with primary provider (Google Gemini) and
 * automatic fallback to OpenAI/ChatGPT on quota exhaustion or rate limits.
 */
class AIProviderManager(
    val geminiProvider: AIProvider = GeminiProvider(),
    val openAIProvider: AIProvider? = null
) {
    suspend fun generatePrompt(request: AIPromptRequest): AIProviderResult {
        val geminiResult = geminiProvider.generatePrompt(request)
        if (geminiResult is AIProviderResult.Success) {
            return geminiResult
        }

        val geminiError = (geminiResult as AIProviderResult.Failure).error
        val eligibleForFailover = geminiError.isQuotaOrRateLimit() ||
                geminiError is AIProviderError.ServerError ||
                geminiError is AIProviderError.NetworkError

        if (eligibleForFailover && openAIProvider != null) {
            val openAIResult = openAIProvider.generatePrompt(request)
            if (openAIResult is AIProviderResult.Success) {
                return openAIResult
            }
            return openAIResult
        }

        return geminiResult
    }
}
