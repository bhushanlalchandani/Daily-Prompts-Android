package com.aistudio.dailyprompts.pkmnz.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * Dynamic theme colors for the Daily Prompts app.
 * Supports: Yellow (default sunflower), Peach, Rose, and Mint palettes,
 * each with high-contrast light and dark modes.
 */
data class AppThemeColors(
    val name: String,
    val primary: Color,
    val onPrimary: Color,
    val primaryDark: Color,
    val primaryLight: Color,
    val primarySurface: Color,
    val secondary: Color,
    val secondaryContainer: Color,
    val background: Color,
    val backgroundSecondary: Color,
    val cardSurface: Color,
    val cardSurfaceTinted: Color,
    val cardBorder: Color,
    val cardBorderSubtle: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val textLabel: Color,
    val chipContainer: Color,
    val isDark: Boolean = false
)

fun getThemeColors(themeName: String, isDark: Boolean): AppThemeColors {
    return when (themeName.lowercase()) {
        "peach" -> {
            if (isDark) {
                AppThemeColors(
                    name = "Peach",
                    primary = Color(0xFFFF9E80),
                    onPrimary = Color(0xFF381408),
                    primaryDark = Color(0xFFFF7043),
                    primaryLight = Color(0xFF45281D),
                    primarySurface = Color(0xFF331C14),
                    secondary = Color(0xFFFFCCBC),
                    secondaryContainer = Color(0xFF5A2A1E),
                    background = Color(0xFF181311),
                    backgroundSecondary = Color(0xFF211A17),
                    cardSurface = Color(0xFF27201D),
                    cardSurfaceTinted = Color(0xFF302723),
                    cardBorder = Color(0xFF433530),
                    cardBorderSubtle = Color(0xFF352B27),
                    textPrimary = Color(0xFFF9EFEB),
                    textSecondary = Color(0xFFCBBBB4),
                    textTertiary = Color(0xFFA3928B),
                    textLabel = Color(0xFFB5A49D),
                    chipContainer = Color(0xFF302622),
                    isDark = true
                )
            } else {
                AppThemeColors(
                    name = "Peach",
                    primary = Color(0xFFFF9E80),
                    onPrimary = Color(0xFF381A0F),
                    primaryDark = Color(0xFFE65100),
                    primaryLight = Color(0xFFFFEBE5),
                    primarySurface = Color(0xFFFFF4F0),
                    secondary = Color(0xFFFFE0D2),
                    secondaryContainer = Color(0xFFFFD5C2),
                    background = Color(0xFFFFFBF9),
                    backgroundSecondary = Color(0xFFFFF3EE),
                    cardSurface = Color(0xFFFFFFFF),
                    cardSurfaceTinted = Color(0xFFFFF6F2),
                    cardBorder = Color(0xFFF8E5DC),
                    cardBorderSubtle = Color(0xFFFCEFE9),
                    textPrimary = Color(0xFF2B1C16),
                    textSecondary = Color(0xFF5E4940),
                    textTertiary = Color(0xFF867268),
                    textLabel = Color(0xFF725F56),
                    chipContainer = Color(0xFFFAF2ED),
                    isDark = false
                )
            }
        }
        "rose" -> {
            if (isDark) {
                AppThemeColors(
                    name = "Rose",
                    primary = Color(0xFFF48FB1),
                    onPrimary = Color(0xFF38081B),
                    primaryDark = Color(0xFFEC407A),
                    primaryLight = Color(0xFF421E2D),
                    primarySurface = Color(0xFF331622),
                    secondary = Color(0xFFF8BBD0),
                    secondaryContainer = Color(0xFF552238),
                    background = Color(0xFF181215),
                    backgroundSecondary = Color(0xFF22181F),
                    cardSurface = Color(0xFF281D24),
                    cardSurfaceTinted = Color(0xFF31232C),
                    cardBorder = Color(0xFF45303D),
                    cardBorderSubtle = Color(0xFF372630),
                    textPrimary = Color(0xFFFAEBF1),
                    textSecondary = Color(0xFFCBB7C1),
                    textTertiary = Color(0xFFA38E99),
                    textLabel = Color(0xFFB5A0AB),
                    chipContainer = Color(0xFF31232C),
                    isDark = true
                )
            } else {
                AppThemeColors(
                    name = "Rose",
                    primary = Color(0xFFF06292),
                    onPrimary = Color(0xFF38081B),
                    primaryDark = Color(0xFFC2185B),
                    primaryLight = Color(0xFFFCE4EC),
                    primarySurface = Color(0xFFFFF0F5),
                    secondary = Color(0xFFF8BBD0),
                    secondaryContainer = Color(0xFFFCE7F3),
                    background = Color(0xFFFFFBFD),
                    backgroundSecondary = Color(0xFFFFF0F6),
                    cardSurface = Color(0xFFFFFFFF),
                    cardSurfaceTinted = Color(0xFFFFF6FA),
                    cardBorder = Color(0xFFF7DEE8),
                    cardBorderSubtle = Color(0xFFFBEBF1),
                    textPrimary = Color(0xFF2D1621),
                    textSecondary = Color(0xFF604552),
                    textTertiary = Color(0xFF886E7B),
                    textLabel = Color(0xFF765D6A),
                    chipContainer = Color(0xFFFAF1F5),
                    isDark = false
                )
            }
        }
        "mint" -> {
            if (isDark) {
                AppThemeColors(
                    name = "Mint",
                    primary = Color(0xFF80CBC4),
                    onPrimary = Color(0xFF042824),
                    primaryDark = Color(0xFF26A69A),
                    primaryLight = Color(0xFF1B3D39),
                    primarySurface = Color(0xFF152E2B),
                    secondary = Color(0xFFB2DFDB),
                    secondaryContainer = Color(0xFF1C423E),
                    background = Color(0xFF111716),
                    backgroundSecondary = Color(0xFF172221),
                    cardSurface = Color(0xFF1C2826),
                    cardSurfaceTinted = Color(0xFF233230),
                    cardBorder = Color(0xFF314441),
                    cardBorderSubtle = Color(0xFF263633),
                    textPrimary = Color(0xFFEBF7F5),
                    textSecondary = Color(0xFFB7CBC8),
                    textTertiary = Color(0xFF8EA3A0),
                    textLabel = Color(0xFFA1B6B3),
                    chipContainer = Color(0xFF243431),
                    isDark = true
                )
            } else {
                AppThemeColors(
                    name = "Mint",
                    primary = Color(0xFF4DB6AC),
                    onPrimary = Color(0xFF042824),
                    primaryDark = Color(0xFF00897B),
                    primaryLight = Color(0xFFE0F2F1),
                    primarySurface = Color(0xFFF0FAF9),
                    secondary = Color(0xFFB2DFDB),
                    secondaryContainer = Color(0xFFD1F2EE),
                    background = Color(0xFFF8FCFC),
                    backgroundSecondary = Color(0xFFEBF7F6),
                    cardSurface = Color(0xFFFFFFFF),
                    cardSurfaceTinted = Color(0xFFF4FAF9),
                    cardBorder = Color(0xFFD8ECE9),
                    cardBorderSubtle = Color(0xFFE6F4F2),
                    textPrimary = Color(0xFF142624),
                    textSecondary = Color(0xFF3F5C58),
                    textTertiary = Color(0xFF6A8682),
                    textLabel = Color(0xFF55726E),
                    chipContainer = Color(0xFFEFF7F6),
                    isDark = false
                )
            }
        }
        "blue" -> {
            if (isDark) {
                AppThemeColors(
                    name = "Blue",
                    primary = Color(0xFF60A5FA),
                    onPrimary = Color(0xFF0B192C),
                    primaryDark = Color(0xFF3B82F6),
                    primaryLight = Color(0xFF1E293B),
                    primarySurface = Color(0xFF172033),
                    secondary = Color(0xFF93C5FD),
                    secondaryContainer = Color(0xFF1E3A5F),
                    background = Color(0xFF0B0F19),
                    backgroundSecondary = Color(0xFF111827),
                    cardSurface = Color(0xFF162032),
                    cardSurfaceTinted = Color(0xFF1C2A40),
                    cardBorder = Color(0xFF283B57),
                    cardBorderSubtle = Color(0xFF1F2F45),
                    textPrimary = Color(0xFFF1F5F9),
                    textSecondary = Color(0xFFCBD5E1),
                    textTertiary = Color(0xFF94A3B8),
                    textLabel = Color(0xFFA8B7CA),
                    chipContainer = Color(0xFF1E2B3E),
                    isDark = true
                )
            } else {
                AppThemeColors(
                    name = "Blue",
                    primary = Color(0xFF2563EB),
                    onPrimary = Color(0xFFFFFFFF),
                    primaryDark = Color(0xFF1D4ED8),
                    primaryLight = Color(0xFFDBEAFE),
                    primarySurface = Color(0xFFEFF6FF),
                    secondary = Color(0xFFBFDBFE),
                    secondaryContainer = Color(0xFFE0E7FF),
                    background = Color(0xFFF8FAFC),
                    backgroundSecondary = Color(0xFFEFF6FF),
                    cardSurface = Color(0xFFFFFFFF),
                    cardSurfaceTinted = Color(0xFFF5F9FF),
                    cardBorder = Color(0xFFDCE7F5),
                    cardBorderSubtle = Color(0xFFEBF2FA),
                    textPrimary = Color(0xFF0F172A),
                    textSecondary = Color(0xFF334155),
                    textTertiary = Color(0xFF64748B),
                    textLabel = Color(0xFF475569),
                    chipContainer = Color(0xFFF1F5F9),
                    isDark = false
                )
            }
        }
        "red" -> {
            if (isDark) {
                AppThemeColors(
                    name = "Red",
                    primary = Color(0xFFF87171),
                    onPrimary = Color(0xFF36080B),
                    primaryDark = Color(0xFFEF4444),
                    primaryLight = Color(0xFF3D1619),
                    primarySurface = Color(0xFF2E1113),
                    secondary = Color(0xFFFCA5A5),
                    secondaryContainer = Color(0xFF5C1B20),
                    background = Color(0xFF170C0D),
                    backgroundSecondary = Color(0xFF201113),
                    cardSurface = Color(0xFF261517),
                    cardSurfaceTinted = Color(0xFF301A1D),
                    cardBorder = Color(0xFF452225),
                    cardBorderSubtle = Color(0xFF361B1D),
                    textPrimary = Color(0xFFFAEBEC),
                    textSecondary = Color(0xFFD1B7BA),
                    textTertiary = Color(0xFFA58C8F),
                    textLabel = Color(0xFFB89DA0),
                    chipContainer = Color(0xFF2F1A1D),
                    isDark = true
                )
            } else {
                AppThemeColors(
                    name = "Red",
                    primary = Color(0xFFEF4444),
                    onPrimary = Color(0xFFFFFFFF),
                    primaryDark = Color(0xFFB91C1C),
                    primaryLight = Color(0xFFFEE2E2),
                    primarySurface = Color(0xFFFEF2F2),
                    secondary = Color(0xFFFECACA),
                    secondaryContainer = Color(0xFFFFE4E6),
                    background = Color(0xFFFFFBFB),
                    backgroundSecondary = Color(0xFFFEF1F2),
                    cardSurface = Color(0xFFFFFFFF),
                    cardSurfaceTinted = Color(0xFFFFF5F5),
                    cardBorder = Color(0xFFFCDADA),
                    cardBorderSubtle = Color(0xFFFDECEB),
                    textPrimary = Color(0xFF2B1012),
                    textSecondary = Color(0xFF5E272B),
                    textTertiary = Color(0xFF884E52),
                    textLabel = Color(0xFF753E42),
                    chipContainer = Color(0xFFFDF0F0),
                    isDark = false
                )
            }
        }
        "purple" -> {
            if (isDark) {
                AppThemeColors(
                    name = "Purple",
                    primary = Color(0xFFA78BFA),
                    onPrimary = Color(0xFF1C0E38),
                    primaryDark = Color(0xFF8B5CF6),
                    primaryLight = Color(0xFF2E1C4E),
                    primarySurface = Color(0xFF23153C),
                    secondary = Color(0xFFC4B5FD),
                    secondaryContainer = Color(0xFF422170),
                    background = Color(0xFF120C1F),
                    backgroundSecondary = Color(0xFF1B122C),
                    cardSurface = Color(0xFF211637),
                    cardSurfaceTinted = Color(0xFF2B1D46),
                    cardBorder = Color(0xFF3F2B66),
                    cardBorderSubtle = Color(0xFF312250),
                    textPrimary = Color(0xFFF4EEFC),
                    textSecondary = Color(0xFFCEBFDF),
                    textTertiary = Color(0xFFA494B6),
                    textLabel = Color(0xFFB7A7C9),
                    chipContainer = Color(0xFF2A1C44),
                    isDark = true
                )
            } else {
                AppThemeColors(
                    name = "Purple",
                    primary = Color(0xFF8B5CF6),
                    onPrimary = Color(0xFFFFFFFF),
                    primaryDark = Color(0xFF6D28D9),
                    primaryLight = Color(0xFFEDE9FE),
                    primarySurface = Color(0xFFF5F3FF),
                    secondary = Color(0xFFDDD6FE),
                    secondaryContainer = Color(0xFFE9D5FF),
                    background = Color(0xFFFAF8FF),
                    backgroundSecondary = Color(0xFFF3EFFF),
                    cardSurface = Color(0xFFFFFFFF),
                    cardSurfaceTinted = Color(0xFFF7F4FE),
                    cardBorder = Color(0xFFE6DEFA),
                    cardBorderSubtle = Color(0xFFEFEAFB),
                    textPrimary = Color(0xFF1F1436),
                    textSecondary = Color(0xFF4C3A6E),
                    textTertiary = Color(0xFF78659C),
                    textLabel = Color(0xFF635084),
                    chipContainer = Color(0xFFF3EDFD),
                    isDark = false
                )
            }
        }
        "teal" -> {
            if (isDark) {
                AppThemeColors(
                    name = "Teal",
                    primary = Color(0xFF2DD4BF),
                    onPrimary = Color(0xFF042622),
                    primaryDark = Color(0xFF14B8A6),
                    primaryLight = Color(0xFF123B36),
                    primarySurface = Color(0xFF0D2C28),
                    secondary = Color(0xFF5EEAD4),
                    secondaryContainer = Color(0xFF114A43),
                    background = Color(0xFF0A1614),
                    backgroundSecondary = Color(0xFF11211E),
                    cardSurface = Color(0xFF162926),
                    cardSurfaceTinted = Color(0xFF1D3531),
                    cardBorder = Color(0xFF294E48),
                    cardBorderSubtle = Color(0xFF1F3D38),
                    textPrimary = Color(0xFFE6FAF6),
                    textSecondary = Color(0xFFB4DDD5),
                    textTertiary = Color(0xFF88B5AC),
                    textLabel = Color(0xFF9DC7BF),
                    chipContainer = Color(0xFF1B322F),
                    isDark = true
                )
            } else {
                AppThemeColors(
                    name = "Teal",
                    primary = Color(0xFF14B8A6),
                    onPrimary = Color(0xFF042622),
                    primaryDark = Color(0xFF0F766E),
                    primaryLight = Color(0xFFCCFBF1),
                    primarySurface = Color(0xFFF0FDF4),
                    secondary = Color(0xFF99F6E4),
                    secondaryContainer = Color(0xFFA7F3D0),
                    background = Color(0xFFF7FDFB),
                    backgroundSecondary = Color(0xFFEBF9F5),
                    cardSurface = Color(0xFFFFFFFF),
                    cardSurfaceTinted = Color(0xFFF2FBF8),
                    cardBorder = Color(0xFFD1F0E8),
                    cardBorderSubtle = Color(0xFFE2F6F1),
                    textPrimary = Color(0xFF0D2924),
                    textSecondary = Color(0xFF27554D),
                    textTertiary = Color(0xFF517E76),
                    textLabel = Color(0xFF3F6961),
                    chipContainer = Color(0xFFEBF7F4),
                    isDark = false
                )
            }
        }
        "lavender" -> {
            if (isDark) {
                AppThemeColors(
                    name = "Lavender",
                    primary = Color(0xFFC084FC),
                    onPrimary = Color(0xFF250B3E),
                    primaryDark = Color(0xFFA855F7),
                    primaryLight = Color(0xFF3B1A5C),
                    primarySurface = Color(0xFF2C1347),
                    secondary = Color(0xFFD8B4FE),
                    secondaryContainer = Color(0xFF501F7C),
                    background = Color(0xFF140B1E),
                    backgroundSecondary = Color(0xFF1D112B),
                    cardSurface = Color(0xFF241536),
                    cardSurfaceTinted = Color(0xFF2D1B44),
                    cardBorder = Color(0xFF432863),
                    cardBorderSubtle = Color(0xFF351F4E),
                    textPrimary = Color(0xFFF8EFFE),
                    textSecondary = Color(0xFFD6BFEC),
                    textTertiary = Color(0xFFAA91C2),
                    textLabel = Color(0xFFBFA7D6),
                    chipContainer = Color(0xFF2C1A42),
                    isDark = true
                )
            } else {
                AppThemeColors(
                    name = "Lavender",
                    primary = Color(0xFFA855F7),
                    onPrimary = Color(0xFFFFFFFF),
                    primaryDark = Color(0xFF7E22CE),
                    primaryLight = Color(0xFFF3E8FF),
                    primarySurface = Color(0xFFFAF5FF),
                    secondary = Color(0xFFE9D5FF),
                    secondaryContainer = Color(0xFFF5D0FE),
                    background = Color(0xFFFCFAFF),
                    backgroundSecondary = Color(0xFFF6F0FD),
                    cardSurface = Color(0xFFFFFFFF),
                    cardSurfaceTinted = Color(0xFFF9F5FE),
                    cardBorder = Color(0xFFEBDCFB),
                    cardBorderSubtle = Color(0xFFF3EAFB),
                    textPrimary = Color(0xFF25103A),
                    textSecondary = Color(0xFF533275),
                    textTertiary = Color(0xFF805C9F),
                    textLabel = Color(0xFF6C478C),
                    chipContainer = Color(0xFFF6EEFC),
                    isDark = false
                )
            }
        }
        "sky blue", "skyblue" -> {
            if (isDark) {
                AppThemeColors(
                    name = "Sky Blue",
                    primary = Color(0xFF38BDF8),
                    onPrimary = Color(0xFF052338),
                    primaryDark = Color(0xFF0EA5E9),
                    primaryLight = Color(0xFF13364E),
                    primarySurface = Color(0xFF0E283B),
                    secondary = Color(0xFF7DD3FC),
                    secondaryContainer = Color(0xFF10466B),
                    background = Color(0xFF09141D),
                    backgroundSecondary = Color(0xFF101F2C),
                    cardSurface = Color(0xFF142738),
                    cardSurfaceTinted = Color(0xFF1A3247),
                    cardBorder = Color(0xFF264966),
                    cardBorderSubtle = Color(0xFF1D3951),
                    textPrimary = Color(0xFFEBF7FD),
                    textSecondary = Color(0xFFB7DAED),
                    textTertiary = Color(0xFF8BB2C9),
                    textLabel = Color(0xFFA0C6DC),
                    chipContainer = Color(0xFF193044),
                    isDark = true
                )
            } else {
                AppThemeColors(
                    name = "Sky Blue",
                    primary = Color(0xFF0EA5E9),
                    onPrimary = Color(0xFFFFFFFF),
                    primaryDark = Color(0xFF0369A1),
                    primaryLight = Color(0xFFE0F2FE),
                    primarySurface = Color(0xFFF0F9FF),
                    secondary = Color(0xFFBAE6FD),
                    secondaryContainer = Color(0xFFCFFAFE),
                    background = Color(0xFFF8FBFE),
                    backgroundSecondary = Color(0xFFEDF6FD),
                    cardSurface = Color(0xFFFFFFFF),
                    cardSurfaceTinted = Color(0xFFF2F9FD),
                    cardBorder = Color(0xFFD3EBF9),
                    cardBorderSubtle = Color(0xFFE3F3FA),
                    textPrimary = Color(0xFF0A2540),
                    textSecondary = Color(0xFF254B6E),
                    textTertiary = Color(0xFF4F779C),
                    textLabel = Color(0xFF3B6286),
                    chipContainer = Color(0xFFECF5FB),
                    isDark = false
                )
            }
        }
        "emerald green", "emerald", "emeraldgreen" -> {
            if (isDark) {
                AppThemeColors(
                    name = "Emerald Green",
                    primary = Color(0xFF34D399),
                    onPrimary = Color(0xFF022C1D),
                    primaryDark = Color(0xFF10B981),
                    primaryLight = Color(0xFF133C2D),
                    primarySurface = Color(0xFF0E2E22),
                    secondary = Color(0xFF6EE7B7),
                    secondaryContainer = Color(0xFF114E38),
                    background = Color(0xFF0A1712),
                    backgroundSecondary = Color(0xFF10231B),
                    cardSurface = Color(0xFF142B22),
                    cardSurfaceTinted = Color(0xFF1B372B),
                    cardBorder = Color(0xFF26503F),
                    cardBorderSubtle = Color(0xFF1D3F32),
                    textPrimary = Color(0xFFE9FBF3),
                    textSecondary = Color(0xFFB5DEC9),
                    textTertiary = Color(0xFF88B8A0),
                    textLabel = Color(0xFF9DCAB3),
                    chipContainer = Color(0xFF1A3429),
                    isDark = true
                )
            } else {
                AppThemeColors(
                    name = "Emerald Green",
                    primary = Color(0xFF10B981),
                    onPrimary = Color(0xFF022C1D),
                    primaryDark = Color(0xFF047857),
                    primaryLight = Color(0xFFD1FAE5),
                    primarySurface = Color(0xFFECFDF5),
                    secondary = Color(0xFFA7F3D0),
                    secondaryContainer = Color(0xFFBBF7D0),
                    background = Color(0xFFF7FCF9),
                    backgroundSecondary = Color(0xFFEAF7F0),
                    cardSurface = Color(0xFFFFFFFF),
                    cardSurfaceTinted = Color(0xFFF2FAF5),
                    cardBorder = Color(0xFFCEEFE0),
                    cardBorderSubtle = Color(0xFFE0F6EC),
                    textPrimary = Color(0xFF062B1D),
                    textSecondary = Color(0xFF225842),
                    textTertiary = Color(0xFF4B836C),
                    textLabel = Color(0xFF386E58),
                    chipContainer = Color(0xFFE9F7F0),
                    isDark = false
                )
            }
        }
        "coral" -> {
            if (isDark) {
                AppThemeColors(
                    name = "Coral",
                    primary = Color(0xFFFF8A7A),
                    onPrimary = Color(0xFF3D130C),
                    primaryDark = Color(0xFFFF6F61),
                    primaryLight = Color(0xFF451F18),
                    primarySurface = Color(0xFF351711),
                    secondary = Color(0xFFFFB5AA),
                    secondaryContainer = Color(0xFF5F2318),
                    background = Color(0xFF170E0C),
                    backgroundSecondary = Color(0xFF221411),
                    cardSurface = Color(0xFF281815),
                    cardSurfaceTinted = Color(0xFF321E1A),
                    cardBorder = Color(0xFF482923),
                    cardBorderSubtle = Color(0xFF38201B),
                    textPrimary = Color(0xFFFAEBE8),
                    textSecondary = Color(0xFFD2B6B0),
                    textTertiary = Color(0xFFA78B85),
                    textLabel = Color(0xFFBC9F99),
                    chipContainer = Color(0xFF301D19),
                    isDark = true
                )
            } else {
                AppThemeColors(
                    name = "Coral",
                    primary = Color(0xFFFF6F61),
                    onPrimary = Color(0xFF3A100B),
                    primaryDark = Color(0xFFE64A38),
                    primaryLight = Color(0xFFFFE5E2),
                    primarySurface = Color(0xFFFFF4F2),
                    secondary = Color(0xFFFFCCC7),
                    secondaryContainer = Color(0xFFFFD8D3),
                    background = Color(0xFFFFFBFB),
                    backgroundSecondary = Color(0xFFFFF1EF),
                    cardSurface = Color(0xFFFFFFFF),
                    cardSurfaceTinted = Color(0xFFFFF6F4),
                    cardBorder = Color(0xFFFCE1DC),
                    cardBorderSubtle = Color(0xFFFDECE9),
                    textPrimary = Color(0xFF301511),
                    textSecondary = Color(0xFF683A32),
                    textTertiary = Color(0xFF946057),
                    textLabel = Color(0xFF7E4B43),
                    chipContainer = Color(0xFFFDF0ED),
                    isDark = false
                )
            }
        }
        else -> { // Default Yellow / Sunflower
            if (isDark) {
                AppThemeColors(
                    name = "Yellow",
                    primary = Color(0xFFFFD54F),
                    onPrimary = Color(0xFF2C1A0E),
                    primaryDark = Color(0xFFF5B700),
                    primaryLight = Color(0xFF423719),
                    primarySurface = Color(0xFF2E2718),
                    secondary = Color(0xFF382924),
                    secondaryContainer = Color(0xFF402E38),
                    background = Color(0xFF161412),
                    backgroundSecondary = Color(0xFF1E1B18),
                    cardSurface = Color(0xFF24201C),
                    cardSurfaceTinted = Color(0xFF2B2622),
                    cardBorder = Color(0xFF3D3630),
                    cardBorderSubtle = Color(0xFF302B26),
                    textPrimary = Color(0xFFF7EFE8),
                    textSecondary = Color(0xFFC7BCB3),
                    textTertiary = Color(0xFF9E938A),
                    textLabel = Color(0xFFAFA39A),
                    chipContainer = Color(0xFF2D2621),
                    isDark = true
                )
            } else {
                AppThemeColors(
                    name = "Yellow",
                    primary = Color(0xFFFFD54F),
                    onPrimary = Color(0xFF2C1A0E),
                    primaryDark = Color(0xFFF5B700),
                    primaryLight = Color(0xFFFFF3CD),
                    primarySurface = Color(0xFFFEF9E7),
                    secondary = Color(0xFFFFE8DD),
                    secondaryContainer = Color(0xFFFCE7F3),
                    background = Color(0xFFFFFDF9),
                    backgroundSecondary = Color(0xFFFFF7EE),
                    cardSurface = Color(0xFFFFFFFF),
                    cardSurfaceTinted = Color(0xFFFFFBF5),
                    cardBorder = Color(0xFFF2EAE0),
                    cardBorderSubtle = Color(0xFFFAF2E9),
                    textPrimary = Color(0xFF261D15),
                    textSecondary = Color(0xFF574B42),
                    textTertiary = Color(0xFF7D7066),
                    textLabel = Color(0xFF6B5F56),
                    chipContainer = Color(0xFFF9F5F0),
                    isDark = false
                )
            }
        }
    }
}

val LocalAppThemeColors = compositionLocalOf {
    getThemeColors("Purple", false)
}

object AppTheme {
    val colors: AppThemeColors
        @Composable
        get() = LocalAppThemeColors.current
}

@Composable
fun DailyPromptsTheme(
    darkTheme: Boolean = false,
    themeName: String = "Purple",
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val themeColors = getThemeColors(themeName, darkTheme)
    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = themeColors.primary,
            onPrimary = themeColors.onPrimary,
            primaryContainer = themeColors.primaryDark,
            onPrimaryContainer = themeColors.onPrimary,
            secondary = themeColors.secondary,
            onSecondary = themeColors.textPrimary,
            secondaryContainer = themeColors.secondaryContainer,
            onSecondaryContainer = themeColors.textPrimary,
            tertiary = AccentHeartPink,
            onTertiary = Color.White,
            background = themeColors.background,
            onBackground = themeColors.textPrimary,
            surface = themeColors.cardSurface,
            onSurface = themeColors.textPrimary,
            surfaceVariant = themeColors.cardSurfaceTinted,
            onSurfaceVariant = themeColors.textSecondary,
            outline = themeColors.cardBorder,
            outlineVariant = themeColors.cardBorderSubtle
        )
    } else {
        lightColorScheme(
            primary = themeColors.primary,
            onPrimary = themeColors.onPrimary,
            primaryContainer = themeColors.primaryLight,
            onPrimaryContainer = themeColors.onPrimary,
            secondary = themeColors.secondary,
            onSecondary = themeColors.textPrimary,
            secondaryContainer = themeColors.secondaryContainer,
            onSecondaryContainer = themeColors.textPrimary,
            tertiary = AccentHeartPink,
            onTertiary = Color.White,
            background = themeColors.background,
            onBackground = themeColors.textPrimary,
            surface = themeColors.cardSurface,
            onSurface = themeColors.textPrimary,
            surfaceVariant = themeColors.cardSurfaceTinted,
            onSurfaceVariant = themeColors.textSecondary,
            outline = themeColors.cardBorder,
            outlineVariant = themeColors.cardBorderSubtle
        )
    }

    CompositionLocalProvider(
        LocalAppThemeColors provides themeColors
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
