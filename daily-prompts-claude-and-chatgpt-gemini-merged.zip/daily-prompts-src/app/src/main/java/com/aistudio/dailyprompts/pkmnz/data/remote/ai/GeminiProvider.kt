package com.aistudio.dailyprompts.pkmnz.data.remote.ai

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class GeminiProvider(
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build(),
    private val apiKeyProvider: () -> String = { "" },
    private val baseUrl: String = "https://generativelanguage.googleapis.com/"
) : AIProvider {

    override val name: String = "Gemini"

    /**
     * Executes the call in a cancellable way: when the calling coroutine is cancelled
     * (timeout, user pressed clear, screen closed) the underlying HTTP call is cancelled too,
     * instead of finishing in the background and having its result thrown away.
     */
    private suspend fun Call.awaitResponse(): Response = suspendCancellableCoroutine { cont ->
        cont.invokeOnCancellation {
            try {
                cancel()
            } catch (_: Throwable) {
            }
        }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (cont.isActive) cont.resumeWithException(e)
            }

            override fun onResponse(call: Call, response: Response) {
                if (cont.isActive) cont.resume(response) else response.close()
            }
        })
    }

    override suspend fun generatePrompt(request: AIPromptRequest): AIProviderResult = withContext(Dispatchers.IO) {
        val apiKey = apiKeyProvider().trim()
        if (!isKeyValid(apiKey)) {
            return@withContext AIProviderResult.Failure(
                AIProviderError.KeyMissing(name, "Gemini API key is not set. Add your key in Settings > API Key to unlock AI features.")
            )
        }

        val relevantDislikes = request.dislikedTypes.filter { disliked ->
            !request.topic.contains(disliked, ignoreCase = true) &&
                    !request.category.contains(disliked, ignoreCase = true)
        }

        val negativeConstraint = if (relevantDislikes.isNotEmpty()) {
            "\nCRITICAL USER PREFERENCE: The user has disliked and blocked the following types/categories: ${relevantDislikes.joinToString(", ")}. NEVER generate a prompt belonging to or resembling these blocked categories or styles."
        } else ""

        val systemPrompt = request.systemPrompt ?: """
            You are an elite Prompt Engineer. Your task is to generate a single, master-crafted, copy-paste ready prompt for ${request.targetAi}.
            The prompt must be exceptionally detailed, effective, and ready for the user to copy directly into ${request.targetAi} to get top-tier results.
            For portrait, beauty, fashion, character, or people prompts (such as 'beautiful girl', aesthetic portraits, models, creative characters), generate tasteful, respectful, artistic, and cinematic prompts detailing lighting, camera lenses (e.g. 85mm f/1.2), composition, color grading, and textures.
            Do not include conversational filler like 'Here is your prompt' or 'Sure!'.
            Return ONLY the exact prompt text ready to be copied and pasted.
            Category: ${request.category}
            Style / Tone: ${request.style}$negativeConstraint
        """.trimIndent()

        val userMessage = if (request.imageBase64.isNullOrBlank()) {
            "Create an advanced, high-performing prompt for: ${request.topic}"
        } else {
            request.topic
        }

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", "$systemPrompt\n\n$userMessage")
                        })
                        if (!request.imageBase64.isNullOrBlank()) {
                            put(JSONObject().apply {
                                put("inlineData", JSONObject().apply {
                                    put("mimeType", request.imageMimeType ?: "image/jpeg")
                                    put("data", request.imageBase64)
                                })
                            })
                        }
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", request.temperature)
                put("maxOutputTokens", request.maxTokens)
                // Gemini 2.5 "thinking" tokens count against maxOutputTokens. With the small
                // budgets used here that can leave an empty answer (finishReason=MAX_TOKENS),
                // so thinking is disabled for these short, single-shot prompt requests.
                put("thinkingConfig", JSONObject().apply {
                    put("thinkingBudget", 0)
                })
            })
            put("safetySettings", JSONArray().apply {
                listOf(
                    "HARM_CATEGORY_HARASSMENT",
                    "HARM_CATEGORY_HATE_SPEECH",
                    "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                    "HARM_CATEGORY_DANGEROUS_CONTENT"
                ).forEach { harmCategory ->
                    put(JSONObject().apply {
                        put("category", harmCategory)
                        put("threshold", "BLOCK_ONLY_HIGH")
                    })
                }
            })
        }

        val mediaType = "application/json; charset=utf-8".toMediaType()
        val bodyString = jsonBody.toString()

        val models = AIModels.GEMINI_MODELS
        var lastError: AIProviderError? = null

        for (model in models) {
            // The key is sent only as a header. Never put it in the URL: URLs end up in logs.
            val endpoint = "${baseUrl.trimEnd('/')}/v1beta/models/$model:generateContent"

            // One quick retry for transient overload (5xx) on the same model.
            var attempt = 0
            var moveToNextModel = false
            while (attempt < 2 && !moveToNextModel) {
                attempt++
                val httpRequest = Request.Builder()
                    .url(endpoint)
                    .addHeader("x-goog-api-key", apiKey)
                    .post(bodyString.toRequestBody(mediaType))
                    .build()

                try {
                    httpClient.newCall(httpRequest).awaitResponse().use { response ->
                        val code = response.code
                        val rawBody = response.body?.string().orEmpty()
                        val lowerBody = rawBody.lowercase()

                        if (!response.isSuccessful) {
                            // --- Quota & rate limit (only ever judged on error responses, so a
                            // generated prompt that merely contains the words "rate limit" is
                            // never mistaken for an error) ---
                            val isQuotaOrRateLimit = code == 429 ||
                                    lowerBody.contains("resource_exhausted") ||
                                    lowerBody.contains("quota_exceeded") ||
                                    lowerBody.contains("rate_limit_exceeded") ||
                                    lowerBody.contains("too_many_requests") ||
                                    lowerBody.contains("exceeded your current quota")
                            if (isQuotaOrRateLimit) {
                                return@withContext AIProviderResult.Failure(
                                    AIProviderError.QuotaExhausted(name, "Gemini quota or rate limit exceeded: $rawBody")
                                )
                            }

                            if (code == 401 || code == 403) {
                                return@withContext AIProviderResult.Failure(
                                    AIProviderError.InvalidApiKey(name, "Gemini API key is unauthorized or invalid.")
                                )
                            }

                            if (code == 400) {
                                if (lowerBody.contains("api_key") || lowerBody.contains("key_invalid") ||
                                    lowerBody.contains("api key not valid")
                                ) {
                                    return@withContext AIProviderResult.Failure(
                                        AIProviderError.InvalidApiKey(name, "Gemini API key is invalid.")
                                    )
                                }
                                return@withContext AIProviderResult.Failure(
                                    AIProviderError.InvalidRequest(name, "Malformed Gemini request: $rawBody")
                                )
                            }

                            if (code == 404) {
                                // Model not found/retired: try the next model in the list.
                                lastError = AIProviderError.ServerError(name, code, "Model $model not found (HTTP 404)")
                                moveToNextModel = true
                                return@use
                            }

                            if (code in 500..599) {
                                lastError = AIProviderError.ServerError(name, code, "Gemini server error ($code)")
                                if (attempt >= 2) moveToNextModel = true
                                return@use
                            }

                            return@withContext AIProviderResult.Failure(
                                AIProviderError.GeneralError(name, "Gemini API error ($code): $rawBody")
                            )
                        }

                        // --- Successful response ---
                        if (rawBody.isBlank()) {
                            return@withContext AIProviderResult.Failure(
                                AIProviderError.GeneralError(name, "Empty response body from Gemini.")
                            )
                        }

                        val json = JSONObject(rawBody)

                        val promptFeedback = json.optJSONObject("promptFeedback")
                        val blockReason = promptFeedback?.optString("blockReason")
                        if (!blockReason.isNullOrBlank() && blockReason != "BLOCK_REASON_UNSPECIFIED") {
                            return@withContext AIProviderResult.Failure(
                                AIProviderError.PolicyRefusal(name, "Gemini blocked response: $blockReason")
                            )
                        }

                        val candidates = json.optJSONArray("candidates")
                        if (candidates != null && candidates.length() > 0) {
                            val firstCandidate = candidates.getJSONObject(0)
                            val finishReason = firstCandidate.optString("finishReason")

                            val parts = firstCandidate.optJSONObject("content")?.optJSONArray("parts")
                            val text = buildString {
                                if (parts != null) {
                                    for (i in 0 until parts.length()) {
                                        val part = parts.optJSONObject(i) ?: continue
                                        // Skip "thought" parts if the model ever returns them.
                                        if (part.optBoolean("thought", false)) continue
                                        append(part.optString("text"))
                                    }
                                }
                            }.trim()

                            if (text.isNotBlank()) {
                                return@withContext AIProviderResult.Success(text, name)
                            }

                            if (finishReason.equals("SAFETY", ignoreCase = true) ||
                                finishReason.equals("RECITATION", ignoreCase = true) ||
                                finishReason.equals("PROHIBITED_CONTENT", ignoreCase = true) ||
                                finishReason.equals("BLOCKLIST", ignoreCase = true)
                            ) {
                                return@withContext AIProviderResult.Failure(
                                    AIProviderError.PolicyRefusal(name, "Gemini generation refused due to policy ($finishReason)")
                                )
                            }
                        }

                        return@withContext AIProviderResult.Failure(
                            AIProviderError.GeneralError(name, "No valid content candidates returned by Gemini.")
                        )
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: UnknownHostException) {
                    return@withContext AIProviderResult.Failure(AIProviderError.NetworkError(name, "No internet connection: ${e.message}"))
                } catch (e: ConnectException) {
                    return@withContext AIProviderResult.Failure(AIProviderError.NetworkError(name, "Could not connect to Gemini: ${e.message}"))
                } catch (e: SocketTimeoutException) {
                    lastError = AIProviderError.NetworkError(name, "Gemini request timed out.")
                    moveToNextModel = true
                } catch (e: IOException) {
                    val msg = e.message.orEmpty().lowercase()
                    if (msg.contains("canceled") || msg.contains("cancelled")) {
                        throw CancellationException("Gemini request cancelled")
                    }
                    if (msg.contains("reset") || msg.contains("broken pipe") || msg.contains("connection")) {
                        return@withContext AIProviderResult.Failure(AIProviderError.NetworkError(name, "Network connection interrupted."))
                    }
                    lastError = AIProviderError.NetworkError(name, e.message ?: "Network I/O error")
                    moveToNextModel = true
                } catch (e: Exception) {
                    return@withContext AIProviderResult.Failure(AIProviderError.GeneralError(name, e.message ?: "Unexpected error"))
                }

                if (!moveToNextModel && attempt < 2) {
                    delay(800L)
                }
            }
        }

        AIProviderResult.Failure(lastError ?: AIProviderError.GeneralError(name, "Unable to generate prompt via Gemini."))
    }

    private fun isKeyValid(key: String): Boolean {
        return key.isNotBlank() &&
                !key.contains("NOT_SET") &&
                !key.startsWith("MY_") &&
                !key.contains("placeholder", ignoreCase = true) &&
                key.length >= 15
    }
}
