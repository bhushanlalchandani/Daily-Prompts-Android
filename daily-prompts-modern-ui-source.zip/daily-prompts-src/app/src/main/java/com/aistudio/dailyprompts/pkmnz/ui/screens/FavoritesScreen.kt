package com.aistudio.dailyprompts.pkmnz.ui.screens

import android.content.Context
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aistudio.dailyprompts.pkmnz.ui.components.AnimatedCopyIcon
import com.aistudio.dailyprompts.pkmnz.ui.components.CategoryArtThumbnail
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppStrings
import com.aistudio.dailyprompts.pkmnz.ui.theme.AccentHeartPink
import com.aistudio.dailyprompts.pkmnz.ui.theme.OnWarmYellow
import com.aistudio.dailyprompts.pkmnz.ui.theme.SoftPink
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmBackground
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardBorderSubtle
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardSurface
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextSecondary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextTertiary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellow
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.AppTab
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.PromptViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun FavoritesScreen(
    viewModel: PromptViewModel,
    modifier: Modifier = Modifier
) {
    val favorites by viewModel.favoritePrompts.collectAsStateWithLifecycle()
    val recentlyCopiedId by viewModel.recentlyCopiedId.collectAsStateWithLifecycle()
    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current
    val strings = LocalAppStrings.current

    val dateStr = remember {
        SimpleDateFormat("d MMM yyyy", Locale.US).format(Date())
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmBackground)
            .testTag("favorites_screen"),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Header (Title: "My Favorites", Subtitle: "Your saved prompts")
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                Text(
                    text = strings.favoritesTitle,
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 28.sp,
                        color = WarmTextPrimary
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = strings.favoritesSubtitle,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 15.sp,
                        color = WarmTextSecondary
                    )
                )
            }
        }

        // 2. Favorites List or Empty State
        if (favorites.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 60.dp, start = 24.dp, end = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .background(SoftPink, shape = CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "❤️", fontSize = 36.sp)
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Text(
                            text = strings.noSavedPrompts,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = WarmTextPrimary
                            ),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = strings.noSavedPromptsDesc,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontSize = 14.sp,
                                color = WarmTextSecondary
                            ),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                viewModel.setTab(AppTab.EXPLORE)
                            },
                            shape = RoundedCornerShape(20.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = WarmYellow,
                                contentColor = OnWarmYellow
                            ),
                            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp)
                        ) {
                            Text(
                                text = strings.explorePromptsBtn,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        } else {
            items(favorites, key = { it.id }) { prompt ->
                var showMenu by remember { mutableStateOf(false) }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .shadow(elevation = 2.dp, shape = RoundedCornerShape(20.dp), ambientColor = Color(0x14000000))
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            viewModel.openPromptDetail(prompt)
                        }
                        .testTag("favorite_card_${prompt.id}"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = WarmCardSurface),
                    border = BorderStroke(1.dp, WarmCardBorderSubtle)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Thumbnail on Left
                        Box(
                            modifier = Modifier
                                .size(74.dp)
                                .clip(RoundedCornerShape(14.dp))
                        ) {
                            CategoryArtThumbnail(category = prompt.category)
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        // Text Content & Date
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = prompt.promptText,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp,
                                    lineHeight = 20.sp,
                                    color = WarmTextPrimary
                                ),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = dateStr,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 12.sp,
                                    color = WarmTextTertiary
                                )
                            )
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        val isRecentlyCopied = (recentlyCopiedId == prompt.id)
                        val copyBtnBg by animateColorAsState(
                            targetValue = if (isRecentlyCopied) Color(0xFFDCFCE7) else WarmCardBorderSubtle,
                            animationSpec = tween(durationMillis = 260),
                            label = "favCopyBtnBg_${prompt.id}"
                        )

                        // Quick Copy Button with animated checkmark
                        IconButton(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                viewModel.copyPrompt(context, prompt.promptText, prompt.id)
                            },
                            modifier = Modifier
                                .size(32.dp)
                                .background(copyBtnBg, shape = CircleShape)
                                .testTag("favorite_copy_button_${prompt.id}")
                        ) {
                            AnimatedCopyIcon(
                                isCopied = isRecentlyCopied,
                                iconSize = 16.dp,
                                normalTint = WarmTextPrimary,
                                copiedTint = Color(0xFF15803D)
                            )
                        }

                        // Favorite Heart (Active Pink)
                        IconButton(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                viewModel.toggleFavorite(prompt.id, true)
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Favorite,
                                contentDescription = "Remove favorite",
                                tint = AccentHeartPink,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        // More Menu
                        Box {
                            IconButton(
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    showMenu = true
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = "More actions",
                                    tint = WarmTextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            DropdownMenu(
                                expanded = showMenu,
                                onDismissRequest = { showMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text(if (isRecentlyCopied) strings.copied else strings.copy) },
                                    leadingIcon = {
                                        AnimatedCopyIcon(
                                            isCopied = isRecentlyCopied,
                                            iconSize = 18.dp,
                                            normalTint = LocalContentColor.current,
                                            copiedTint = Color(0xFF15803D)
                                        )
                                    },
                                    onClick = {
                                        showMenu = false
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        viewModel.copyPrompt(context, prompt.promptText, prompt.id)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(strings.share) },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Share,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    },
                                    onClick = {
                                        showMenu = false
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        viewModel.sharePrompt(context, prompt.promptText, prompt.title)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(strings.delete, color = Color(0xFFDC2626)) },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = null,
                                            tint = Color(0xFFDC2626),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    },
                                    onClick = {
                                        showMenu = false
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        viewModel.deletePrompt(prompt.id)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
