package com.aistudio.dailyprompts.pkmnz.ui.viewmodel

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.aistudio.dailyprompts.pkmnz.data.analyzer.ImagePromptAnalyzer
import com.aistudio.dailyprompts.pkmnz.data.analyzer.ImageTelemetry
import com.aistudio.dailyprompts.pkmnz.data.cover.CoverPhotoManager
import com.aistudio.dailyprompts.pkmnz.data.cover.WallpaperState
import com.aistudio.dailyprompts.pkmnz.data.generator.SmartPromptEngine
import com.aistudio.dailyprompts.pkmnz.data.local.ApiKeyManager
import com.aistudio.dailyprompts.pkmnz.data.local.DislikedTypeEntity
import com.aistudio.dailyprompts.pkmnz.data.local.GeneratedPromptEntity
import com.aistudio.dailyprompts.pkmnz.data.local.PromptEntity
import com.aistudio.dailyprompts.pkmnz.data.local.UserProfileManager
import com.aistudio.dailyprompts.pkmnz.data.model.AiTool
import com.aistudio.dailyprompts.pkmnz.data.model.PromptCategory
import com.aistudio.dailyprompts.pkmnz.data.model.UserProfile
import com.aistudio.dailyprompts.pkmnz.data.repository.PromptGenerationResult
import com.aistudio.dailyprompts.pkmnz.data.repository.PromptRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppTab(val title: String, val iconName: String) {
    HOME("Home", "home"),
    EXPLORE("Explore", "explore"),
    FAVORITES("Favorites", "heart"),
    PROFILE("Profile", "person"),

    // Sub-screens & Feature destinations
    PROMPT_DETAIL("Detail", "detail"),
    CATEGORIES("Categories", "grid"),
    SETTINGS("Settings", "settings"),
    GENERATOR("Generator", "magic"),
    SCRATCHPAD("Scratchpad", "clipboard"),
    EDIT_PROFILE("Edit Profile", "person"),
    API_KEY_SETTINGS("API Key", "key");

    companion object {
        val DAILY = HOME
        val SAVED = FAVORITES
    }
}

enum class GeneratorMode {
    TEXT,
    IMAGE
}

data class GeneratorUiState(
    val generatorMode: GeneratorMode = GeneratorMode.TEXT,
    val topicInput: String = "",
    val selectedAi: AiTool = AiTool.CHATGPT,
    val selectedCategory: PromptCategory = PromptCategory.CHAT_GPT,
    val selectedStyle: String = "Professional",
    val isGenerating: Boolean = false,
    val isSaving: Boolean = false,
    val isSaved: Boolean = false,
    val generatedResult: String = "",
    val isGeminiPowered: Boolean = false,
    val isTurboFastMode: Boolean = true,
    val errorMessage: String? = null,
    // Image to Prompt specific fields
    val selectedImageUri: Uri? = null,
    val selectedImageBase64: String? = null,
    val selectedImageMimeType: String = "image/jpeg",
    val imageAspectRatio: String = "",
    val imageColorSummary: String = "",
    val imageSampleId: String? = null,
    val selectedImageTelemetry: ImageTelemetry? = null,
    // Magic Enhancer state
    val isEnhancing: Boolean = false,
    val lastOriginalTopic: String? = null,
    val lastEnhancedTopic: String? = null
)

class PromptViewModel(
    private val repository: PromptRepository,
    context: Context? = null,
    injectedApiKeyManager: ApiKeyManager? = null
) : ViewModel() {

    val apiKeyManager: ApiKeyManager? = injectedApiKeyManager ?: context?.let { ApiKeyManager(it.applicationContext) }
    val hasApiKey: StateFlow<Boolean> = apiKeyManager?.hasGeminiKey ?: MutableStateFlow(false)
    val hasOpenAIKey: StateFlow<Boolean> = apiKeyManager?.hasOpenAIKey ?: MutableStateFlow(false)

    fun getGeminiApiKey(): String = apiKeyManager?.getGeminiApiKey().orEmpty()
    fun saveGeminiApiKey(key: String) {
        apiKeyManager?.setGeminiApiKey(key)
        viewModelScope.launch {
            _userMessage.emit("✨ Gemini API Key saved securely!")
        }
    }
    fun clearGeminiApiKey() {
        apiKeyManager?.clearGeminiApiKey()
        viewModelScope.launch {
            _userMessage.emit("Gemini API Key removed. Using offline Smart Engine.")
        }
    }
    fun isGeminiKeyConfigured(): Boolean = apiKeyManager?.isGeminiKeyConfigured() == true

    fun getOpenAIApiKey(): String = apiKeyManager?.getOpenAIApiKey().orEmpty()
    fun saveOpenAIApiKey(key: String) {
        apiKeyManager?.setOpenAIApiKey(key)
        viewModelScope.launch {
            _userMessage.emit("✨ OpenAI API Key saved securely!")
        }
    }
    fun clearOpenAIApiKey() {
        apiKeyManager?.clearOpenAIApiKey()
        viewModelScope.launch {
            _userMessage.emit("OpenAI API Key removed.")
        }
    }
    fun isOpenAIKeyConfigured(): Boolean = apiKeyManager?.isOpenAIKeyConfigured() == true

    private val userProfileManager = context?.let { UserProfileManager(it.applicationContext) }
    private val _userProfile = MutableStateFlow(userProfileManager?.loadProfile() ?: UserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private val coverPhotoManager = context?.let { CoverPhotoManager(it.applicationContext) }
    val coverPhotoPath: StateFlow<String?> = coverPhotoManager?.coverPhotoPath
        ?: MutableStateFlow(null).asStateFlow()
    val wallpaperState: StateFlow<WallpaperState> = coverPhotoManager?.wallpaperState
        ?: MutableStateFlow(WallpaperState()).asStateFlow()

    private val _currentTab = MutableStateFlow(AppTab.DAILY)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    private val _selectedCategory = MutableStateFlow(PromptCategory.ALL)
    val selectedCategory: StateFlow<PromptCategory> = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _recentlyCopiedId = MutableStateFlow<Long?>(null)
    val recentlyCopiedId: StateFlow<Long?> = _recentlyCopiedId.asStateFlow()
    private var copyResetJob: Job? = null

    companion object {
        const val COPIED_ID_SCRATCHPAD = -101L
        const val COPIED_ID_GENERATOR = -102L
    }

    fun resetRecentlyCopied() {
        copyResetJob?.cancel()
        _recentlyCopiedId.value = null
    }

    private val _userMessage = MutableSharedFlow<String>()
    val userMessage = _userMessage.asSharedFlow()

    private val _generatorState = MutableStateFlow(GeneratorUiState())
    val generatorState: StateFlow<GeneratorUiState> = _generatorState.asStateFlow()

    private val _scratchpadText = MutableStateFlow("")
    val scratchpadText: StateFlow<String> = _scratchpadText.asStateFlow()

    private val _dailyFeatured = MutableStateFlow(SmartPromptEngine.getDailyFeaturedPrompt())
    val dailyFeaturedPrompt: StateFlow<PromptEntity> = _dailyFeatured.asStateFlow()

    private val _dailyPrompts = MutableStateFlow<List<PromptEntity>>(
        SmartPromptEngine.SEED_PROMPTS.filter { it.isDaily }.take(5)
    )
    val dailyPrompts: StateFlow<List<PromptEntity>> = _dailyPrompts.asStateFlow()

    // Prompt Detail state
    private val _selectedPromptForDetail = MutableStateFlow<PromptEntity?>(null)
    val selectedPromptForDetail: StateFlow<PromptEntity?> = _selectedPromptForDetail.asStateFlow()

    // Completed Prompts Tracking
    private val _completedPromptIds = MutableStateFlow<Set<Long>>(emptySet())
    val completedPromptIds: StateFlow<Set<Long>> = _completedPromptIds.asStateFlow()

    // Explore filter: All, Trending, New, Popular
    private val _exploreFilter = MutableStateFlow("All")
    val exploreFilter: StateFlow<String> = _exploreFilter.asStateFlow()

    // Settings States with persistent SharedPreferences
    private val prefs = context?.getSharedPreferences("daily_prompt_settings", Context.MODE_PRIVATE)

    private val _dailyReminder = MutableStateFlow(
        prefs?.getBoolean("daily_reminder", true) ?: true
    )
    val dailyReminder: StateFlow<Boolean> = _dailyReminder.asStateFlow()

    private val _darkMode = MutableStateFlow(
        prefs?.getBoolean("dark_mode", false) ?: false
    )
    val darkMode: StateFlow<Boolean> = _darkMode.asStateFlow()

    private val _notifications = MutableStateFlow(
        prefs?.getBoolean("notifications", true) ?: true
    )
    val notifications: StateFlow<Boolean> = _notifications.asStateFlow()

    private val _selectedTheme = MutableStateFlow(
        prefs?.getString("selected_theme", "Purple") ?: "Purple"
    )
    val selectedTheme: StateFlow<String> = _selectedTheme.asStateFlow()

    private val _selectedLanguage = MutableStateFlow(
        prefs?.getString("selected_language", "English") ?: "English"
    )
    val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

    fun openPromptDetail(prompt: PromptEntity) {
        _selectedPromptForDetail.value = prompt
        _currentTab.value = AppTab.PROMPT_DETAIL
    }

    fun openDailyDetail() {
        _selectedPromptForDetail.value = _dailyFeatured.value
        _currentTab.value = AppTab.PROMPT_DETAIL
    }

    fun openCategories() {
        _currentTab.value = AppTab.CATEGORIES
    }

    fun openSettings() {
        _currentTab.value = AppTab.SETTINGS
    }

    fun openEditProfile() {
        _currentTab.value = AppTab.EDIT_PROFILE
    }

    fun saveUserProfile(
        name: String,
        bio: String,
        email: String = UserProfile.DEFAULT_EMAIL,
        avatarType: String = _userProfile.value.avatarType,
        customAvatarPath: String? = _userProfile.value.customAvatarPath,
        onSaved: (() -> Unit)? = null
    ): Boolean {
        val trimmedName = name.trim()
        if (trimmedName.isBlank()) {
            viewModelScope.launch {
                _userMessage.emit("⚠️ Name cannot be empty")
            }
            return false
        }

        val immediateUpdated = UserProfile(
            name = trimmedName,
            bio = bio.trim(),
            email = email.trim(),
            avatarType = avatarType,
            customAvatarPath = customAvatarPath
        )
        _userProfile.value = immediateUpdated

        viewModelScope.launch {
            val updated = if (userProfileManager != null) {
                userProfileManager.saveProfile(
                    name = trimmedName,
                    bio = bio.trim(),
                    email = email.trim(),
                    avatarType = avatarType,
                    customAvatarPath = customAvatarPath
                )
            } else {
                immediateUpdated
            }
            _userProfile.value = updated
            _userMessage.emit("✨ Profile updated successfully!")
            onSaved?.invoke()
        }
        return true
    }

    fun saveCustomAvatarPhoto(uri: Uri, onComplete: ((Boolean) -> Unit)? = null) {
        viewModelScope.launch {
            if (userProfileManager != null) {
                val result = userProfileManager.saveCustomAvatarPhoto(uri)
                if (result.isSuccess) {
                    val path = result.getOrNull()
                    val current = _userProfile.value
                    val updated = current.copy(
                        avatarType = UserProfile.AVATAR_CUSTOM,
                        customAvatarPath = path
                    )
                    _userProfile.value = updated
                    _userMessage.emit("📸 Profile photo updated!")
                    onComplete?.invoke(true)
                } else {
                    _userMessage.emit("❌ Failed to load image. Please try again.")
                    onComplete?.invoke(false)
                }
            } else {
                onComplete?.invoke(false)
            }
        }
    }

    fun removeCustomAvatarPhoto(onComplete: (() -> Unit)? = null) {
        viewModelScope.launch {
            userProfileManager?.clearCustomAvatarPhoto()
            val current = _userProfile.value
            val updated = current.copy(
                avatarType = UserProfile.AVATAR_DEFAULT,
                customAvatarPath = null
            )
            _userProfile.value = updated
            _userMessage.emit("Avatar reset to default.")
            onComplete?.invoke()
        }
    }

    fun setAvatarPreset(presetType: String) {
        viewModelScope.launch {
            val current = _userProfile.value
            val updated = if (userProfileManager != null) {
                userProfileManager.saveProfile(
                    name = current.name,
                    bio = current.bio,
                    email = current.email,
                    avatarType = presetType,
                    customAvatarPath = current.customAvatarPath
                )
            } else {
                current.copy(avatarType = presetType)
            }
            _userProfile.value = updated
        }
    }

    fun resetUserProfile() {
        viewModelScope.launch {
            val reset = userProfileManager?.resetProfile() ?: UserProfile()
            _userProfile.value = reset
        }
    }

    fun setExploreFilter(filter: String) {
        _exploreFilter.value = filter
    }

    fun togglePromptCompleted(promptId: Long) {
        val current = _completedPromptIds.value
        if (promptId in current) {
            _completedPromptIds.value = current - promptId
            viewModelScope.launch {
                _userMessage.emit("Prompt marked as uncompleted")
            }
        } else {
            _completedPromptIds.value = current + promptId
            viewModelScope.launch {
                _userMessage.emit("🎉 Great job completing this daily prompt!")
            }
        }
    }

    fun isPromptCompleted(promptId: Long): Boolean {
        return promptId in _completedPromptIds.value
    }

    fun toggleDailyReminder() {
        val next = !_dailyReminder.value
        _dailyReminder.value = next
        prefs?.edit()?.putBoolean("daily_reminder", next)?.apply()
    }

    fun toggleDarkMode() {
        val next = !_darkMode.value
        _darkMode.value = next
        prefs?.edit()?.putBoolean("dark_mode", next)?.apply()
    }

    fun toggleNotifications() {
        val next = !_notifications.value
        _notifications.value = next
        prefs?.edit()?.putBoolean("notifications", next)?.apply()
    }

    fun setTheme(theme: String) {
        _selectedTheme.value = theme
        prefs?.edit()?.putString("selected_theme", theme)?.apply()
    }

    fun setLanguage(language: String) {
        _selectedLanguage.value = language
        prefs?.edit()?.putString("selected_language", language)?.apply()
    }

    fun clearAppHistory() {
        viewModelScope.launch {
            _completedPromptIds.value = emptySet()
            _userMessage.emit("App history cleared successfully.")
        }
    }

    // Concurrency guards and roll tracking
    private var isRollingFresh = false
    private var rollCount = 0
    private val processingDislikes = mutableSetOf<Long>()
    private val togglingFavorites = mutableSetOf<Long>()

    val dislikedTypes: StateFlow<List<DislikedTypeEntity>> = repository.dislikedTypes
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allPrompts: StateFlow<List<PromptEntity>> = combine(
        repository.allPrompts,
        _selectedCategory,
        _searchQuery,
        dislikedTypes
    ) { prompts, category, query, dislikedList ->
        val sourcePrompts = prompts.ifEmpty { SmartPromptEngine.SEED_PROMPTS }
        val dislikedCategories = dislikedList.map { it.category.lowercase() }.toSet()
        val cleanQuery = query.trim()
        sourcePrompts.filter { prompt ->
            val isNotDisliked = prompt.category.lowercase() !in dislikedCategories && !prompt.isDisliked
            val matchesCategory = (category == PromptCategory.ALL) ||
                    prompt.category.equals(category.displayName, ignoreCase = true)
            val matchesQuery = cleanQuery.isEmpty() ||
                    prompt.title.contains(cleanQuery, ignoreCase = true) ||
                    prompt.promptText.contains(cleanQuery, ignoreCase = true) ||
                    prompt.tags.contains(cleanQuery, ignoreCase = true)
            isNotDisliked && matchesCategory && matchesQuery
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SmartPromptEngine.SEED_PROMPTS
    )

    val favoritePrompts: StateFlow<List<PromptEntity>> = repository.favoritePrompts
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val recentGeneratedPrompts: StateFlow<List<GeneratedPromptEntity>> = repository.recentGeneratedPrompts
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        viewModelScope.launch {
            val prefs = context?.getSharedPreferences("daily_prompt_tracker", Context.MODE_PRIVATE)
            val todayKey = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
            val lastDate = prefs?.getString("last_date", "") ?: ""

            if (lastDate != todayKey) {
                // First open of the day! Prune stale daily prompts and roll fresh batch
                prefs?.edit()?.putString("last_date", todayKey)?.apply()
                val newFeatured = repository.rollFreshPrompts(0)
                _dailyFeatured.value = newFeatured
            } else {
                repository.ensureInitialData()
                refreshDailyFeatured()
            }
            refreshDailyPrompts()
        }
    }

    private suspend fun refreshDailyFeatured() {
        _dailyFeatured.value = repository.getDailyFeatured()
    }

    private suspend fun refreshDailyPrompts() {
        val list = repository.getDailyPrompts(0)
        if (list.isNotEmpty()) {
            _dailyPrompts.value = list
        }
    }

    fun setDailyFeatured(prompt: PromptEntity) {
        _dailyFeatured.value = prompt
    }

    private val tabBackStack = mutableListOf<AppTab>()

    fun setTab(tab: AppTab) {
        if (_currentTab.value == tab) return
        tabBackStack.remove(tab)
        tabBackStack.add(_currentTab.value)
        if (tabBackStack.size > 20) {
            tabBackStack.removeAt(0)
        }
        _currentTab.value = tab
    }

    fun canNavigateBack(): Boolean {
        return tabBackStack.isNotEmpty() || _currentTab.value != AppTab.HOME
    }

    fun navigateBack(): Boolean {
        while (tabBackStack.isNotEmpty()) {
            val previousTab = tabBackStack.removeAt(tabBackStack.lastIndex)
            if (previousTab != _currentTab.value) {
                _currentTab.value = previousTab
                return true
            }
        }
        if (_currentTab.value != AppTab.HOME) {
            _currentTab.value = AppTab.HOME
            return true
        }
        return false
    }

    fun setCategory(category: PromptCategory) {
        _selectedCategory.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun rollFreshPrompts() {
        if (isRollingFresh) return
        isRollingFresh = true
        viewModelScope.launch {
            try {
                rollCount++
                val newFeatured = repository.rollFreshPrompts(rollCount)
                _dailyFeatured.value = newFeatured
                _selectedPromptForDetail.value = newFeatured
                val freshList = repository.getDailyPrompts(rollCount)
                if (freshList.isNotEmpty()) {
                    _dailyPrompts.value = freshList
                }
                _userMessage.emit("✨ Rolled brand new fresh prompts!")
            } finally {
                isRollingFresh = false
            }
        }
    }

    fun nextPromptDetail() {
        val all = allPrompts.value.ifEmpty { SmartPromptEngine.SEED_PROMPTS }
        val current = _selectedPromptForDetail.value ?: _dailyFeatured.value
        val currentIndex = all.indexOfFirst { it.id == current.id }
        val nextPrompt = if (currentIndex != -1 && currentIndex + 1 < all.size) {
            all[currentIndex + 1]
        } else {
            rollCount++
            all.firstOrNull() ?: SmartPromptEngine.getDailyFeaturedPrompt(rollCount)
        }
        _selectedPromptForDetail.value = nextPrompt
        _dailyFeatured.value = nextPrompt
    }

    fun dislikePrompt(prompt: PromptEntity) {
        if (prompt.id in processingDislikes) return
        processingDislikes.add(prompt.id)
        viewModelScope.launch {
            try {
                repository.dislikePromptAndType(
                    promptId = prompt.id,
                    category = prompt.category,
                    tags = prompt.tags,
                    title = prompt.title
                )
                refreshDailyFeatured()
                _userMessage.emit("🚫 Disliked! We won't generate or show '${prompt.category}' prompts anymore.")
            } finally {
                processingDislikes.remove(prompt.id)
            }
        }
    }

    fun unblockCategory(category: String) {
        viewModelScope.launch {
            repository.unblockCategory(category)
            refreshDailyFeatured()
            _userMessage.emit("✅ Restored '${category}' prompts.")
        }
    }

    fun copyPrompt(context: Context, promptText: String, promptId: Long? = null) {
        try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            if (clipboard == null) {
                viewModelScope.launch { _userMessage.emit("Clipboard service unavailable") }
                return
            }
            val clip = ClipData.newPlainText("AI Prompt", promptText)
            clipboard.setPrimaryClip(clip)

            val targetId = promptId ?: -999L
            _recentlyCopiedId.value = targetId

            // Immediate visual feedback: temporary toast message
            try {
                Handler(Looper.getMainLooper()).post {
                    Toast.makeText(context.applicationContext, "📋 Prompt copied to clipboard!", Toast.LENGTH_SHORT).show()
                }
            } catch (_: Exception) {
                // Ignore in testing environments where looper isn't prepared
            }

            // Automatically reset back to default after 2 seconds
            copyResetJob?.cancel()
            copyResetJob = viewModelScope.launch {
                delay(2000L)
                if (_recentlyCopiedId.value == targetId) {
                    _recentlyCopiedId.value = null
                }
            }

            viewModelScope.launch {
                _userMessage.emit("📋 Prompt copied! Ready to paste into ChatGPT/Claude.")
            }
        } catch (e: Exception) {
            viewModelScope.launch {
                _userMessage.emit("Could not copy to clipboard")
            }
        }
    }

    fun sharePrompt(context: Context, promptText: String, title: String) {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, promptText)
            }
            val chooser = Intent.createChooser(intent, "Paste prompt to:")
            chooser.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(chooser)
        } catch (e: Exception) {
            viewModelScope.launch {
                _userMessage.emit("Could not open share app")
            }
        }
    }

    fun toggleFavorite(id: Long, currentStatus: Boolean) {
        if (id in togglingFavorites) return
        togglingFavorites.add(id)
        viewModelScope.launch {
            try {
                repository.toggleFavorite(id, currentStatus)
                if (!currentStatus) {
                    _userMessage.emit("❤️ Saved to Favorites")
                }
            } finally {
                togglingFavorites.remove(id)
            }
        }
    }

    fun toggleFavoritePrompt(prompt: PromptEntity) {
        val isCurrentlyFav = favoritePrompts.value.any {
            it.id == prompt.id || (it.title == prompt.title && it.promptText == prompt.promptText)
        }
        viewModelScope.launch {
            try {
                repository.toggleFavoriteForPrompt(prompt, isCurrentlyFav)
                if (!isCurrentlyFav) {
                    _userMessage.emit("❤️ Saved to Favorites")
                } else {
                    _userMessage.emit("Removed from Favorites")
                }
            } catch (e: Exception) {
                // Ignore
            }
        }
    }

    fun deletePrompt(id: Long) {
        viewModelScope.launch {
            repository.deletePrompt(id)
            _userMessage.emit("🗑️ Prompt removed")
        }
    }

    fun setGeneratorMode(mode: GeneratorMode) {
        _generatorState.value = _generatorState.value.copy(
            generatorMode = mode,
            errorMessage = null
        )
    }

    fun selectImageUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            _generatorState.value = _generatorState.value.copy(isGenerating = true, errorMessage = null)
            val prepared = ImagePromptAnalyzer.prepareImageFromUri(context, uri)
            if (prepared != null) {
                _generatorState.value = _generatorState.value.copy(
                    isGenerating = false,
                    selectedImageUri = uri,
                    selectedImageBase64 = prepared.base64,
                    selectedImageMimeType = prepared.mimeType,
                    imageAspectRatio = prepared.telemetry.aspectRatioLabel,
                    imageColorSummary = "${prepared.telemetry.colorTone} • ${prepared.telemetry.luminanceCategory}",
                    selectedImageTelemetry = prepared.telemetry,
                    imageSampleId = null,
                    isSaved = false
                )
                _userMessage.emit("🖼️ Image loaded! Ready to analyze.")
            } else {
                _generatorState.value = _generatorState.value.copy(
                    isGenerating = false,
                    errorMessage = "Could not process selected image. Try another photo."
                )
                _userMessage.emit("⚠️ Could not process image.")
            }
        }
    }

    fun selectSampleImage(context: Context, sampleId: String) {
        viewModelScope.launch {
            _generatorState.value = _generatorState.value.copy(isGenerating = true, errorMessage = null)
            val prepared = ImagePromptAnalyzer.prepareSampleImage(context, sampleId)
            _generatorState.value = _generatorState.value.copy(
                isGenerating = false,
                selectedImageUri = prepared.localFileUri,
                selectedImageBase64 = prepared.base64,
                selectedImageMimeType = prepared.mimeType,
                imageAspectRatio = prepared.telemetry.aspectRatioLabel,
                imageColorSummary = "${prepared.telemetry.colorTone} • ${prepared.telemetry.luminanceCategory}",
                selectedImageTelemetry = prepared.telemetry,
                imageSampleId = sampleId,
                isSaved = false
            )
            _userMessage.emit("🖼️ Sample image selected! Ready to analyze.")
        }
    }

    fun clearSelectedImage() {
        _generatorState.value = _generatorState.value.copy(
            selectedImageUri = null,
            selectedImageBase64 = null,
            imageAspectRatio = "",
            imageColorSummary = "",
            selectedImageTelemetry = null,
            imageSampleId = null,
            errorMessage = null
        )
    }

    fun analyzeUploadedImage(context: Context) {
        val state = _generatorState.value
        if (state.isGenerating || generateJob?.isActive == true) return

        val base64 = state.selectedImageBase64
        if (base64.isNullOrBlank()) {
            _generatorState.value = state.copy(errorMessage = "Please upload or select an image first")
            return
        }

        _generatorState.value = state.copy(isGenerating = true, errorMessage = null, isSaved = false)

        generateJob = viewModelScope.launch {
            try {
                // Use the real dynamically inspected telemetry from the image!
                val telemetry = state.selectedImageTelemetry ?: ImageTelemetry(
                    width = 1024,
                    height = 1024,
                    aspectRatioLabel = state.imageAspectRatio.ifBlank { "Square / Symmetrical (1:1)" },
                    dominantColorHex = "#3A7BD5",
                    colorTone = "Balanced Natural Tone",
                    luminanceCategory = "Balanced Natural",
                    estimatedSubjects = "Visual Scene",
                    lightingStyle = "Natural Ambient Illumination"
                )

                val factualFallback = ImagePromptAnalyzer.buildFactualDescriptivePrompt(
                    telemetry = telemetry,
                    sampleId = state.imageSampleId
                )

                val result = repository.analyzeImagePrompt(
                    imageBase64 = base64,
                    imageMimeType = state.selectedImageMimeType,
                    localFallbackPrompt = factualFallback
                )

                _generatorState.value = _generatorState.value.copy(
                    isGenerating = false,
                    generatedResult = result.promptText,
                    isGeminiPowered = result.isGemini
                )

                // Automatically cache prompt locally using Room for offline access
                launch {
                    val summaryTitle = if (state.imageSampleId != null) {
                        "Sample: ${state.imageSampleId}"
                    } else {
                        "Image: ${telemetry.aspectRatioLabel} • ${telemetry.colorTone}"
                    }
                    repository.cacheGeneratedPrompt(
                        topic = summaryTitle,
                        promptText = result.promptText,
                        targetAi = "Midjourney / Vision",
                        category = "Visual Art",
                        style = "Descriptive",
                        isGemini = result.isGemini,
                        mode = "IMAGE"
                    )
                }

                if (result.isGemini) {
                    _userMessage.emit("🤖 Gemini Vision AI analyzed the image!")
                } else {
                    _userMessage.emit("🔍 Image analyzed via Smart Vision Engine!")
                }
            } catch (e: CancellationException) {
                _generatorState.value = _generatorState.value.copy(isGenerating = false)
                throw e
            } catch (e: Exception) {
                // Never present a fabricated generic prompt as if the uploaded image
                // had been analyzed. Keep the result empty and show a useful error.
                val reason = e.localizedMessage
                    ?.takeIf { it.isNotBlank() }
                    ?: "Vision AI could not analyze this image."
                _generatorState.value = _generatorState.value.copy(
                    isGenerating = false,
                    generatedResult = "",
                    isGeminiPowered = false,
                    errorMessage = "Image analysis failed: $reason. Check your API key and internet connection, then try again."
                )
                _userMessage.emit("Image analysis failed. No generic prompt was substituted.")
            } finally {
                if (_generatorState.value.isGenerating) {
                    _generatorState.value = _generatorState.value.copy(isGenerating = false)
                }
            }
        }
    }

    fun updateTopicInput(input: String) {
        _generatorState.value = _generatorState.value.copy(
            topicInput = input,
            errorMessage = null,
            isSaved = false
        )
    }

    fun updateSelectedAi(ai: AiTool) {
        _generatorState.value = _generatorState.value.copy(selectedAi = ai)
    }

    fun updateSelectedCategory(cat: PromptCategory) {
        _generatorState.value = _generatorState.value.copy(selectedCategory = cat)
    }

    private var generateJob: Job? = null

    fun toggleTurboFastMode() {
        val current = _generatorState.value.isTurboFastMode
        _generatorState.value = _generatorState.value.copy(isTurboFastMode = !current)
        viewModelScope.launch {
            _userMessage.emit(if (!current) "⏩ Turbo Fast Mode active! Instant generation." else "🤖 Live AI Mode active.")
        }
    }

    fun updateSelectedStyle(style: String) {
        _generatorState.value = _generatorState.value.copy(selectedStyle = style)
    }

    fun generateCustomPrompt() {
        val state = _generatorState.value
        if (state.isGenerating || generateJob?.isActive == true) return

        val topic = state.topicInput.trim()
        if (topic.isBlank()) {
            _generatorState.value = state.copy(errorMessage = "Please enter an idea or topic first")
            return
        }

        // If user previously disliked this category, automatically unblock it since they explicitly requested generation now
        val disliked = dislikedTypes.value.map { it.category.lowercase() }
        if (state.selectedCategory.displayName.lowercase() in disliked) {
            viewModelScope.launch {
                repository.unblockCategory(state.selectedCategory.displayName)
            }
        }

        _generatorState.value = state.copy(isGenerating = true, errorMessage = null, isSaved = false)

        generateJob = viewModelScope.launch {
            try {
                val result = if (state.isTurboFastMode) {
                    // Instant Turbo Generation: Immediate master prompt crafting (<50ms)
                    val cleanTopic = topic.trim()
                    val effectiveCategory = if (state.selectedCategory == PromptCategory.CHAT_GPT || state.selectedCategory == PromptCategory.ALL) {
                        when {
                            cleanTopic.contains("girl", ignoreCase = true) ||
                                    cleanTopic.contains("woman", ignoreCase = true) ||
                                    cleanTopic.contains("ladki", ignoreCase = true) -> PromptCategory.GIRL.displayName
                            cleanTopic.contains("boy", ignoreCase = true) ||
                                    cleanTopic.contains("man", ignoreCase = true) -> PromptCategory.BOY.displayName
                            else -> state.selectedCategory.displayName
                        }
                    } else {
                        state.selectedCategory.displayName
                    }
                    val procedural = SmartPromptEngine.buildProceduralPrompt(
                        topic = cleanTopic,
                        targetAi = state.selectedAi.displayName,
                        category = effectiveCategory,
                        style = state.selectedStyle
                    )
                    PromptGenerationResult(
                        promptText = procedural,
                        isGemini = false
                    )
                } else {
                    repository.generatePrompt(
                        topic = topic,
                        targetAi = state.selectedAi.displayName,
                        category = state.selectedCategory.displayName,
                        style = state.selectedStyle
                    )
                }

                _generatorState.value = _generatorState.value.copy(
                    isGenerating = false,
                    generatedResult = result.promptText,
                    isGeminiPowered = result.isGemini,
                    errorMessage = null
                )

                // Automatically cache prompt locally using Room for offline access
                launch {
                    repository.cacheGeneratedPrompt(
                        topic = topic,
                        promptText = result.promptText,
                        targetAi = state.selectedAi.displayName,
                        category = state.selectedCategory.displayName,
                        style = state.selectedStyle,
                        isGemini = result.isGemini,
                        mode = "TEXT"
                    )
                }

                val isGirlTopic = topic.contains("girl", ignoreCase = true) ||
                        topic.contains("woman", ignoreCase = true) ||
                        topic.contains("ladki", ignoreCase = true)

                if (isGirlTopic) {
                    _userMessage.emit("✨ Beautiful girl prompt crafted successfully!")
                } else if (result.isGemini) {
                    _userMessage.emit("🤖 Prompt generated successfully!")
                } else if (result.errorNotice != null) {
                    val notice = when {
                        result.errorNotice.contains("not configured", ignoreCase = true) ->
                            "⚡ Smart Engine active (AI key not configured)"
                        result.errorNotice.contains("rate limit", ignoreCase = true) || result.errorNotice.contains("quota", ignoreCase = true) ->
                            "⚡ AI busy: Crafted via Smart Engine!"
                        result.errorNotice.contains("internet", ignoreCase = true) ->
                            "⚡ Offline: Crafted via Smart Engine!"
                        result.errorNotice.contains("timed out", ignoreCase = true) ->
                            "⚡ AI timeout: Crafted via Smart Engine!"
                        else ->
                            "⚡ Prompt crafted via Smart Engine!"
                    }
                    _userMessage.emit(notice)
                } else {
                    _userMessage.emit("⚡ Prompt crafted via Smart Engine!")
                }
            } catch (e: CancellationException) {
                _generatorState.value = _generatorState.value.copy(isGenerating = false)
                throw e
            } catch (e: Exception) {
                val fallback = SmartPromptEngine.buildProceduralPrompt(
                    topic = topic,
                    targetAi = state.selectedAi.displayName,
                    category = state.selectedCategory.displayName,
                    style = state.selectedStyle
                )
                _generatorState.value = _generatorState.value.copy(
                    isGenerating = false,
                    generatedResult = fallback,
                    isGeminiPowered = false
                )
                launch {
                    repository.cacheGeneratedPrompt(
                        topic = topic,
                        promptText = fallback,
                        targetAi = state.selectedAi.displayName,
                        category = state.selectedCategory.displayName,
                        style = state.selectedStyle,
                        isGemini = false,
                        mode = "TEXT"
                    )
                }
                _userMessage.emit("⚡ Prompt crafted via Smart Engine!")
            } finally {
                if (_generatorState.value.isGenerating) {
                    _generatorState.value = _generatorState.value.copy(isGenerating = false)
                }
            }
        }
    }

    fun saveGeneratedPrompt() {
        val state = _generatorState.value
        if (state.generatedResult.isBlank() || state.isSaving || state.isSaved) return

        _generatorState.value = state.copy(isSaving = true)
        viewModelScope.launch {
            try {
                repository.savePrompt(
                    title = state.topicInput.take(50).ifBlank { "Custom Prompt" },
                    promptText = state.generatedResult,
                    category = state.selectedCategory.displayName,
                    aiTool = state.selectedAi.displayName,
                    tags = "${state.selectedAi.displayName}, Custom, ${state.selectedStyle}"
                )
                _generatorState.value = _generatorState.value.copy(isSaving = false, isSaved = true)
                _userMessage.emit("⭐ Prompt saved to Library!")
            } catch (e: Exception) {
                _generatorState.value = _generatorState.value.copy(isSaving = false)
                _userMessage.emit("Could not save prompt")
            }
        }
    }

    fun savePrompt(title: String, promptText: String, category: String, aiTool: String) {
        viewModelScope.launch {
            try {
                repository.savePrompt(
                    title = title,
                    promptText = promptText,
                    category = category,
                    aiTool = aiTool
                )
                _userMessage.emit("⭐ Saved to Library!")
            } catch (e: Exception) {
                _userMessage.emit("Could not save prompt")
            }
        }
    }

    fun deleteGeneratedPrompt(id: Long) {
        viewModelScope.launch {
            repository.deleteGeneratedPrompt(id)
            _userMessage.emit("🗑️ Removed from recent history")
        }
    }

    fun clearGeneratedPrompt() {
        generateJob?.cancel()
        _generatorState.value = _generatorState.value.copy(
            generatedResult = "",
            isGenerating = false,
            isSaving = false,
            isSaved = false,
            isGeminiPowered = false,
            isEnhancing = false,
            errorMessage = null,
            lastOriginalTopic = null,
            lastEnhancedTopic = null
        )
        resetRecentlyCopied()
        viewModelScope.launch {
            _userMessage.emit("Prompt cleared! Ready to generate a new one.")
        }
    }

    fun clearGeneratedHistory() {
        viewModelScope.launch {
            repository.clearGeneratedHistory()
            _userMessage.emit("🗑️ Recent history cleared")
        }
    }

    fun loadHistoricalPrompt(item: GeneratedPromptEntity) {
        _generatorState.value = _generatorState.value.copy(
            topicInput = item.topic,
            generatedResult = item.promptText,
            isGeminiPowered = item.isGeminiPowered,
            isSaved = false,
            errorMessage = null,
            generatorMode = if (item.mode == "IMAGE") GeneratorMode.IMAGE else GeneratorMode.TEXT
        )
        viewModelScope.launch {
            _userMessage.emit("📋 Loaded prompt from history into editor!")
        }
    }

    fun updateScratchpadText(newText: String) {
        _scratchpadText.value = newText
    }

    fun loadIntoScratchpad(text: String) {
        _scratchpadText.value = text
        _currentTab.value = AppTab.SCRATCHPAD
        viewModelScope.launch {
            _userMessage.emit("Loaded prompt into scratchpad for editing!")
        }
    }

    fun pasteFromClipboard(context: Context, onPasted: (() -> Unit)? = null) {
        try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            val clip = clipboard?.primaryClip
            val pasted = if (clip != null && clip.itemCount > 0) {
                clip.getItemAt(0)?.text?.toString().orEmpty()
            } else ""
            if (pasted.isNotBlank()) {
                _scratchpadText.value = pasted
                onPasted?.invoke()
                viewModelScope.launch {
                    _userMessage.emit("📥 Pasted from clipboard!")
                }
            } else {
                viewModelScope.launch {
                    _userMessage.emit("Clipboard is empty")
                }
            }
        } catch (e: Exception) {
            viewModelScope.launch {
                _userMessage.emit("Could not read clipboard")
            }
        }
    }

    fun setWallpaperPreset(presetId: String, onComplete: (() -> Unit)? = null) {
        viewModelScope.launch {
            coverPhotoManager?.setPreset(presetId)
            val presetName = com.aistudio.dailyprompts.pkmnz.data.cover.WallpaperPresets.getPreset(presetId)?.name ?: "Preset"
            _userMessage.emit("🎨 '$presetName' wallpaper applied!")
            onComplete?.invoke()
        }
    }

    fun setWallpaperDimLevel(dimLevel: Float) {
        viewModelScope.launch {
            coverPhotoManager?.setDimLevel(dimLevel)
        }
    }

    fun setCoverPhoto(uri: Uri, onComplete: ((Boolean) -> Unit)? = null) {
        if (coverPhotoManager == null) {
            onComplete?.invoke(false)
            return
        }
        viewModelScope.launch {
            val result = coverPhotoManager.setCoverPhoto(uri)
            if (result.isSuccess) {
                _userMessage.emit("🖼️ Custom wallpaper applied!")
                onComplete?.invoke(true)
            } else {
                _userMessage.emit("Could not load image. Try another photo or preset.")
                onComplete?.invoke(false)
            }
        }
    }

    fun removeCoverPhoto(onComplete: (() -> Unit)? = null) {
        viewModelScope.launch {
            coverPhotoManager?.removeCoverPhoto()
            _userMessage.emit("Obsidian default background active.")
            onComplete?.invoke()
        }
    }

    private var magicEnhanceVariantIndex = 0

    fun magicEnhanceInput() {
        val state = _generatorState.value
        val currentInput = state.topicInput.trim()
        if (currentInput.isBlank()) {
            _generatorState.value = state.copy(errorMessage = "Please enter an idea to optimize first!")
            viewModelScope.launch {
                _userMessage.emit("Type or paste an idea first to enhance it with Magic AI!")
            }
            return
        }

        // Determine base core topic: if already enhanced or has original, use original or extracted core!
        val baseTopic = state.lastOriginalTopic
            ?.takeIf { it.isNotBlank() }
            ?: SmartPromptEngine.extractCoreTopic(currentInput)

        magicEnhanceVariantIndex++

        viewModelScope.launch {
            _generatorState.value = state.copy(isEnhancing = true, errorMessage = null)
            delay(120) // Snappy micro-interaction feel
            val enhanced = SmartPromptEngine.enhancePrompt(
                rawPrompt = baseTopic,
                targetAi = state.selectedAi.displayName,
                category = state.selectedCategory.displayName,
                style = state.selectedStyle,
                variant = magicEnhanceVariantIndex
            )
            _generatorState.value = _generatorState.value.copy(
                topicInput = enhanced,
                isEnhancing = false,
                lastOriginalTopic = baseTopic,
                lastEnhancedTopic = enhanced
            )
            val styleNum = (magicEnhanceVariantIndex % 3) + 1
            _userMessage.emit("🪄 Magic Prompt Enhanced! (Style #$styleNum)")
        }
    }

    fun undoMagicEnhance() {
        val state = _generatorState.value
        val original = state.lastOriginalTopic ?: return
        _generatorState.value = state.copy(
            topicInput = original,
            lastOriginalTopic = null,
            lastEnhancedTopic = null
        )
        viewModelScope.launch {
            _userMessage.emit("Reverted to original input.")
        }
    }

    fun magicEnhanceResult() {
        val state = _generatorState.value
        val currentResult = state.generatedResult.trim()
        if (currentResult.isBlank()) return

        val baseTopic = SmartPromptEngine.extractCoreTopic(currentResult)
        magicEnhanceVariantIndex++

        viewModelScope.launch {
            _generatorState.value = state.copy(isEnhancing = true)
            delay(150)
            val enhanced = SmartPromptEngine.enhancePrompt(
                rawPrompt = baseTopic,
                targetAi = state.selectedAi.displayName,
                category = state.selectedCategory.displayName,
                style = state.selectedStyle,
                variant = magicEnhanceVariantIndex
            )
            _generatorState.value = _generatorState.value.copy(
                generatedResult = enhanced,
                isEnhancing = false,
                isSaved = false
            )
            val styleNum = (magicEnhanceVariantIndex % 3) + 1
            _userMessage.emit("🪄 Prompt optimized to Master Standard #$styleNum!")
        }
    }

    fun enhanceScratchpadText() {
        val current = _scratchpadText.value.trim()
        if (current.isBlank()) {
            viewModelScope.launch {
                _userMessage.emit("Type or paste text into the scratchpad first!")
            }
            return
        }

        val baseTopic = SmartPromptEngine.extractCoreTopic(current)
        magicEnhanceVariantIndex++

        viewModelScope.launch {
            val enhanced = SmartPromptEngine.enhancePrompt(
                rawPrompt = baseTopic,
                targetAi = "ChatGPT",
                category = "General",
                style = "Professional & Clear",
                variant = magicEnhanceVariantIndex
            )
            _scratchpadText.value = enhanced
            _userMessage.emit("🪄 Scratchpad enhanced into Master Prompt!")
        }
    }

    class Factory(
        private val repository: PromptRepository,
        private val context: Context? = null,
        private val apiKeyManager: ApiKeyManager? = null
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return PromptViewModel(repository, context, apiKeyManager) as T
        }
    }
}
