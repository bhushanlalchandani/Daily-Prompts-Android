package com.aistudio.dailyprompts.pkmnz.ui.components

import android.content.Context
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.dailyprompts.pkmnz.data.local.PromptEntity
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedBorder
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedButtonSecondary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedCardContainer
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedCardSurface
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedOnPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedTextPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedTextSecondary
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppStrings

@Composable
fun DailyHeroCard(
    prompt: PromptEntity,
    isRecentlyCopied: Boolean,
    onCopy: (Context, String, Long) -> Unit,
    onShare: (Context, String, String) -> Unit,
    onDislike: ((PromptEntity) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val strings = LocalAppStrings.current

    val copyBg by animateColorAsState(
        targetValue = if (isRecentlyCopied) Color(0xFF00C853) else SophisticatedPrimary,
        animationSpec = tween(250),
        label = "heroCopyBg"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("daily_hero_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = SophisticatedCardSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(22.dp)
        ) {
            // Subtle ambient atmospheric blur in bottom corner
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .align(Alignment.BottomEnd)
                    .clip(CircleShape)
                    .background(SophisticatedPrimary.copy(alpha = 0.06f))
                    .blur(28.dp)
            )

            Column(modifier = Modifier.fillMaxWidth()) {
                // Top Tag: Lavender dot + "PROMPT OF THE DAY" tracking-widest + AI tool badge & Dislike
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Lavender dot
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(SophisticatedPrimary)
                        )
                        Text(
                            text = strings.promptOfTheDay,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.8.sp,
                            color = SophisticatedTextSecondary
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SophisticatedCardContainer,
                            border = androidx.compose.foundation.BorderStroke(1.dp, SophisticatedBorder)
                        ) {
                            Text(
                                text = prompt.aiTool,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = SophisticatedPrimary
                            )
                        }

                        if (onDislike != null) {
                            IconButton(
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    onDislike(prompt)
                                },
                                modifier = Modifier
                                    .size(32.dp)
                                    .testTag("hero_dislike_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.ThumbDown,
                                    contentDescription = "Dislike prompt and block this type",
                                    tint = SophisticatedTextSecondary,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Title
                Text(
                    text = prompt.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SophisticatedTextPrimary
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Prompt Text (Serif italic feeling with high legibility)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(SophisticatedCardContainer)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "\"${prompt.promptText}\"",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontFamily = FontFamily.Serif,
                            fontStyle = FontStyle.Italic,
                            lineHeight = 24.sp
                        ),
                        color = SophisticatedTextPrimary,
                        maxLines = 6
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Primary Copy Button (#D0BCFF with #381E72 text)
                    Button(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onCopy(context, prompt.promptText, prompt.id)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 52.dp)
                            .testTag("hero_copy_button"),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = copyBg,
                            contentColor = if (isRecentlyCopied) Color.White else SophisticatedOnPrimary
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        AnimatedCopyContent(
                            isCopied = isRecentlyCopied,
                            normalText = strings.copyToClipboardBtn,
                            copiedText = strings.copiedSuccess,
                            iconSize = 20.dp,
                            spacing = 8.dp,
                            style = MaterialTheme.typography.titleSmall,
                            contentColor = if (isRecentlyCopied) Color.White else SophisticatedOnPrimary
                        )
                    }

                    // Secondary Share Button (Entire button surface clickable)
                    Button(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onShare(context, prompt.promptText, prompt.title)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("hero_share_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SophisticatedButtonSecondary,
                            contentColor = SophisticatedTextPrimary
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = strings.shareToOtherApps,
                                tint = SophisticatedTextPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = strings.shareToOtherApps,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = SophisticatedTextPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}
