package com.aistudio.dailyprompts.pkmnz.data.remote.ai

/**
 * Manages AI prompt generation with primary provider (Google Gemini) and
 * Gemini-first prompt generation. An optional secondary provider is used only
 * for quota/rate-limit failures; configuration/model errors are returned as-is.
 */
class AIProviderManager(
    val geminiProvider: AIProvider = GeminiProvider(),
    val openAIProvider: AIProvider? = null
) {
    suspend fun generatePrompt(request: AIPromptRequest): AIProviderResult {
        val geminiResult = geminiProvider.generatePrompt(request)
        if (geminiResult is AIProviderResult.Success) {
            return geminiResult
        }

        val geminiError = (geminiResult as AIProviderResult.Failure).error
        // Do not hide invalid model IDs (404), bad requests, missing keys, or
        // network diagnostics behind an unrelated OpenAI error.
        val eligibleForFailover = geminiError.isQuotaOrRateLimit()

        if (eligibleForFailover && openAIProvider != null) {
            val openAIResult = openAIProvider.generatePrompt(request)
            if (openAIResult is AIProviderResult.Success) {
                return openAIResult
            }
            return openAIResult
        }

        return geminiResult
    }
}
