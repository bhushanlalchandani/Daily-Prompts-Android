package com.aistudio.dailyprompts.pkmnz.util

/**
 * Global application constants.
 */
object AppConstants {
    /**
     * Placeholder share URL that can be easily customized.
     */
    const val SHARE_APP_URL = "https://YOUR-LINK-HERE"

    /**
     * Default share message template referencing [SHARE_APP_URL].
     */
    const val SHARE_APP_MESSAGE = "Check out Daily Prompts! Discover daily mindfulness, personal growth, and creative inspiration: $SHARE_APP_URL"
}
