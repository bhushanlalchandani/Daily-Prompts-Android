package com.aistudio.dailyprompts.pkmnz.data.analyzer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Shader
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class ImageTelemetry(
    val width: Int,
    val height: Int,
    val aspectRatioLabel: String,
    val dominantColorHex: String,
    val colorTone: String,
    val luminanceCategory: String,
    val estimatedSubjects: String,
    val lightingStyle: String,
    val paletteHexes: List<String> = emptyList(),
    val colorNames: List<String> = emptyList(),
    val saturationLevel: String = "Balanced Saturation",
    val contrastLevel: String = "Medium Contrast",
    val visualPattern: String = "Organic & Natural",
    val compositionStyle: String = "Rule of Thirds",
    val detailDensity: String = "Sharp Fine Detail"
)

data class PreparedImage(
    val base64: String,
    val mimeType: String = "image/jpeg",
    val bitmap: Bitmap,
    val telemetry: ImageTelemetry,
    val localFileUri: Uri? = null,
    val sampleId: String? = null
)

object ImagePromptAnalyzer {

    /**
     * Safely reads an image Uri, downsizes to max 1024x1024 to prevent memory issues,
     * encodes to Base64 JPEG, and computes genuine visual telemetry.
     */
    suspend fun prepareImageFromUri(context: Context, uri: Uri): PreparedImage? = withContext(Dispatchers.IO) {
        try {
            val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, boundsOptions)
            }

            val origWidth = boundsOptions.outWidth
            val origHeight = boundsOptions.outHeight
            if (origWidth <= 0 || origHeight <= 0) return@withContext null

            val maxDimension = 1024
            var sampleSize = 1
            while ((origWidth / sampleSize) > maxDimension * 1.5 || (origHeight / sampleSize) > maxDimension * 1.5) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }

            val rawBitmap = context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOptions)
            } ?: return@withContext null

            var working: Bitmap = rawBitmap

            // Camera photos are stored sideways with an EXIF orientation flag. Without applying
            // it, Gemini receives a rotated picture and describes it wrongly.
            val rotation = readExifRotation(context, uri)
            if (rotation != 0) {
                val rotated = rotateBitmap(working, rotation)
                if (rotated !== working) {
                    working.recycle()
                    working = rotated
                }
            }

            val scaled = scaleBitmapToMax(working, maxDimension)
            if (scaled !== working) {
                working.recycle()
                working = scaled
            }

            // JPEG has no alpha channel: transparent PNG/WebP pixels would turn black.
            if (working.hasAlpha()) {
                val flat = flattenOnWhite(working)
                if (flat !== working) {
                    working.recycle()
                    working = flat
                }
            }
            val finalBitmap = working

            val outputStream = ByteArrayOutputStream()
            finalBitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
            val bytes = outputStream.toByteArray()
            val base64String = Base64.encodeToString(bytes, Base64.NO_WRAP)

            // Extract genuine visual telemetry from bitmap
            val telemetry = analyzeBitmapTelemetry(finalBitmap)

            PreparedImage(
                base64 = base64String,
                mimeType = "image/jpeg",
                bitmap = finalBitmap,
                telemetry = telemetry,
                localFileUri = uri,
                sampleId = null
            )
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Generates a realistic visual sample image so the user can test the Image-to-Prompt analyzer.
     */
    suspend fun prepareSampleImage(context: Context, sampleId: String): PreparedImage = withContext(Dispatchers.IO) {
        val width = 768
        val height = 1024
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        when (sampleId) {
            "golden_hour_portrait" -> {
                val bgPaint = Paint().apply {
                    shader = LinearGradient(
                        0f, 0f, 0f, height.toFloat(),
                        intArrayOf(Color.parseColor("#FFE0B2"), Color.parseColor("#FFB74D"), Color.parseColor("#E65100")),
                        null,
                        Shader.TileMode.CLAMP
                    )
                }
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

                val subjectPaint = Paint().apply {
                    isAntiAlias = true
                    color = Color.parseColor("#4A2810")
                }
                canvas.drawCircle(width / 2f, height * 0.38f, 160f, subjectPaint)
                canvas.drawOval(
                    width * 0.15f, height * 0.52f,
                    width * 0.85f, height * 1.1f,
                    subjectPaint
                )

                val blindShadowPaint = Paint().apply {
                    color = Color.argb(90, 30, 15, 0)
                    strokeWidth = 28f
                }
                val blindLightPaint = Paint().apply {
                    color = Color.argb(120, 255, 235, 180)
                    strokeWidth = 26f
                }
                var y = 100f
                while (y < height) {
                    canvas.drawLine(0f, y, width.toFloat(), y, blindShadowPaint)
                    canvas.drawLine(0f, y + 28f, width.toFloat(), y + 28f, blindLightPaint)
                    y += 70f
                }
            }
            "wildflower_meadow" -> {
                val bgPaint = Paint().apply {
                    shader = LinearGradient(
                        0f, 0f, 0f, height.toFloat(),
                        intArrayOf(Color.parseColor("#81D4FA"), Color.parseColor("#C8E6C9"), Color.parseColor("#388E3C")),
                        null,
                        Shader.TileMode.CLAMP
                    )
                }
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
            }
            else -> {
                val bgPaint = Paint().apply {
                    shader = LinearGradient(
                        0f, 0f, 0f, height.toFloat(),
                        intArrayOf(Color.parseColor("#1A237E"), Color.parseColor("#4A148C"), Color.parseColor("#FF6F00")),
                        null,
                        Shader.TileMode.CLAMP
                    )
                }
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
            }
        }

        val cacheFile = File(context.cacheDir, "sample_$sampleId.jpg")
        FileOutputStream(cacheFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 88, out)
        }
        val fileUri = Uri.fromFile(cacheFile)

        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
        val base64String = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
        val telemetry = analyzeBitmapTelemetry(bitmap)

        PreparedImage(
            base64 = base64String,
            mimeType = "image/jpeg",
            bitmap = bitmap,
            telemetry = telemetry,
            localFileUri = fileUri,
            sampleId = sampleId
        )
    }

    /**
     * Builds a comprehensive, factual descriptive prompt based on the visual inspection of the image.
     * Dynamically inspects the uploaded image (colors, shapes, patterns, composition, lighting,
     * and detail density) rather than returning fixed preset templates.
     */
     fun buildFactualDescriptivePrompt(telemetry: ImageTelemetry, sampleId: String? = null): String {
        val framing = "${telemetry.compositionStyle} framing in ${telemetry.aspectRatioLabel} aspect ratio (${telemetry.width}x${telemetry.height} px)"

        val paletteDetails = if (telemetry.paletteHexes.isNotEmpty()) {
            "defined by dominant tone ${telemetry.dominantColorHex} alongside ${telemetry.paletteHexes.joinToString(", ")} (${telemetry.colorNames.joinToString(", ")})"
        } else {
            "anchored by primary tone ${telemetry.dominantColorHex} with balanced tonal transitions"
        }

        val arTag = when {
            telemetry.aspectRatioLabel.contains("9:16") -> "--ar 9:16"
            telemetry.aspectRatioLabel.contains("4:5") || telemetry.aspectRatioLabel.contains("Portrait") -> "--ar 4:5"
            telemetry.aspectRatioLabel.contains("16:9") -> "--ar 16:9"
            telemetry.aspectRatioLabel.contains("4:3") || telemetry.aspectRatioLabel.contains("Landscape") -> "--ar 4:3"
            else -> "--ar 1:1"
        }

        val lensType = when {
            telemetry.aspectRatioLabel.contains("16:9") || telemetry.aspectRatioLabel.contains("Landscape") -> "cinematic wide-angle 24mm lens with deep horizontal perspective"
            telemetry.aspectRatioLabel.contains("Portrait") || telemetry.aspectRatioLabel.contains("4:5") -> "prime 85mm lens with shallow focal plane and creamy background falloff"
            telemetry.aspectRatioLabel.contains("9:16") -> "focused 50mm portrait lens with vertical composition balance"
            else -> "balanced 35mm optical lens with natural spatial proportions"
        }

        val subjectStructure = if (telemetry.estimatedSubjects.isNotBlank() && telemetry.estimatedSubjects != "Visual Scene") {
            "Focal elements: The frame features ${telemetry.estimatedSubjects.lowercase()}, organized with ${telemetry.compositionStyle.lowercase()}."
        } else {
            "Composition structure: Structured with ${telemetry.compositionStyle.lowercase()} and clean focal depth."
        }

        return """A high-resolution photograph with $framing.

$subjectStructure

Chromatic composition: The color palette is characterized by ${telemetry.colorTone}, $paletteDetails. Saturation is rendered with ${telemetry.saturationLevel.lowercase()}, preserving authentic chromatic balance, subtle hue gradations, and ambient bounce light.

Lighting dynamics: The scene is illuminated by ${telemetry.lightingStyle}, featuring ${telemetry.contrastLevel.lowercase()} with natural highlight roll-off and smooth shadow gradations across visible planes.

Texture and spatial fidelity: The composition exhibits ${telemetry.visualPattern.lowercase()} with ${telemetry.detailDensity.lowercase()}. Clear focal separation delineates foreground subjects and surfaces from ambient background elements, exhibiting authentic optical clarity.

Master photographic rendering: Photographed on a $lensType, true-to-life focal depth, crisp textural fidelity, natural exposure latitude, 8k resolution $arTag --style raw"""
    }

    private fun readExifRotation(context: Context, uri: Uri): Int {
        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val exif = android.media.ExifInterface(stream)
                when (exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL)) {
                    android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90
                    android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180
                    android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270
                    else -> 0
                }
            } ?: 0
        } catch (_: Throwable) {
            0
        }
    }

    private fun rotateBitmap(bitmap: Bitmap, degrees: Int): Bitmap {
        return try {
            val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        } catch (_: Throwable) {
            bitmap
        }
    }

    private fun flattenOnWhite(bitmap: Bitmap): Bitmap {
        return try {
            val result = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(result)
            canvas.drawColor(Color.WHITE)
            canvas.drawBitmap(bitmap, 0f, 0f, null)
            result
        } catch (_: Throwable) {
            bitmap
        }
    }

    private fun scaleBitmapToMax(bitmap: Bitmap, maxDim: Int): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= maxDim && h <= maxDim) return bitmap

        val scale = min(maxDim.toFloat() / w, maxDim.toFloat() / h)
        val targetW = max(1, (w * scale).toInt())
        val targetH = max(1, (h * scale).toInt())
        return Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
    }

    /**
     * Inspects the pixels of the provided bitmap across a multi-region grid to measure
     * real colors, luminance distribution, contrast, edge density, patterns, and composition.
     */
    fun analyzeBitmapTelemetry(bitmap: Bitmap): ImageTelemetry {
        val w = bitmap.width
        val h = bitmap.height

        val ratio = w.toFloat() / h.toFloat()
        val aspectLabel = when {
            h >= w * 1.55f -> "Vertical Story (9:16)"
            h >= w * 1.15f -> "Portrait (4:5 / 3:4)"
            w >= h * 1.55f -> "Cinematic Widescreen (16:9)"
            w >= h * 1.15f -> "Landscape (4:3 / 3:2)"
            else -> "Square / Symmetrical (1:1)"
        }

        val gridSteps = 24
        val stepX = max(1, w / gridSteps)
        val stepY = max(1, h / gridSteps)

        var totalR = 0L
        var totalG = 0L
        var totalB = 0L
        var totalLuminance = 0.0
        var totalSaturation = 0.0
        var sampleCount = 0

        var minLum = 255.0
        var maxLum = 0.0
        val lumSamples = ArrayList<Double>(gridSteps * gridSteps)

        var topLumSum = 0.0
        var topSampleCount = 0
        var bottomLumSum = 0.0
        var bottomSampleCount = 0
        var centerLumSum = 0.0
        var centerSampleCount = 0
        var edgeLumSum = 0.0
        var edgeSampleCount = 0

        var totalEdgeGradient = 0L
        var edgeCount = 0
        var centerEdgeGradient = 0L
        var centerEdgeCount = 0
        var outerEdgeGradient = 0L
        var outerEdgeCount = 0

        // Color bucket aggregation: Red, Orange, Amber/Yellow, Green, Cyan/Teal, Blue, Purple, Pink, Neutral/Gray, White, Black
        class ColorBin(val name: String) {
            var count = 0
            var sumR = 0L
            var sumG = 0L
            var sumB = 0L
        }

        val bins = mapOf(
            "Warm Amber" to ColorBin("Warm Amber"),
            "Golden Honey" to ColorBin("Golden Honey"),
            "Crimson Red" to ColorBin("Crimson Red"),
            "Botanical Green" to ColorBin("Botanical Green"),
            "Vibrant Teal" to ColorBin("Vibrant Teal"),
            "Cobalt Blue" to ColorBin("Cobalt Blue"),
            "Violet Purple" to ColorBin("Violet Purple"),
            "Soft Rose" to ColorBin("Soft Rose"),
            "Earthy Terracotta" to ColorBin("Earthy Terracotta"),
            "Slate Charcoal" to ColorBin("Slate Charcoal"),
            "Crisp White" to ColorBin("Crisp White")
        )

        for (x in 0 until w step stepX) {
            for (y in 0 until h step stepY) {
                val pixel = bitmap.getPixel(x, y)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)

                totalR += r
                totalG += g
                totalB += b

                val lum = 0.299 * r + 0.587 * g + 0.114 * b
                totalLuminance += lum
                lumSamples.add(lum)
                if (lum < minLum) minLum = lum
                if (lum > maxLum) maxLum = lum

                val maxC = max(r, max(g, b))
                val minC = min(r, min(g, b))
                val sat = if (maxC > 0) (maxC - minC).toDouble() / maxC else 0.0
                totalSaturation += sat

                // Spatial luminance tracking
                val isTop = y < h * 0.33
                val isBottom = y > h * 0.66
                val isCenter = (x in (w * 0.25).toInt()..(w * 0.75).toInt()) && (y in (h * 0.25).toInt()..(h * 0.75).toInt())
                val isEdge = !isCenter

                if (isTop) { topLumSum += lum; topSampleCount++ }
                if (isBottom) { bottomLumSum += lum; bottomSampleCount++ }
                if (isCenter) { centerLumSum += lum; centerSampleCount++ }
                if (isEdge) { edgeLumSum += lum; edgeSampleCount++ }

                // Edge gradient computation
                if (x + stepX < w && y + stepY < h) {
                    val rightPixel = bitmap.getPixel(x + stepX, y)
                    val downPixel = bitmap.getPixel(x, y + stepY)

                    val gradH = abs(r - Color.red(rightPixel)) + abs(g - Color.green(rightPixel)) + abs(b - Color.blue(rightPixel))
                    val gradV = abs(r - Color.red(downPixel)) + abs(g - Color.green(downPixel)) + abs(b - Color.blue(downPixel))
                    val grad = (gradH + gradV) / 2

                    totalEdgeGradient += grad
                    edgeCount++

                    if (isCenter) {
                        centerEdgeGradient += grad
                        centerEdgeCount++
                    } else {
                        outerEdgeGradient += grad
                        outerEdgeCount++
                    }
                }

                // Color classification into bins
                val targetBin = when {
                    sat < 0.12 && lum > 200 -> bins["Crisp White"]
                    sat < 0.15 -> bins["Slate Charcoal"]
                    else -> {
                        // Hue calculation in degrees
                        val hue = calculateHue(r, g, b)
                        when {
                            hue in 15f..45f && sat < 0.65 && lum < 120 -> bins["Earthy Terracotta"]
                            hue in 15f..42f -> bins["Warm Amber"]
                            hue in 42f..70f -> bins["Golden Honey"]
                            hue in 70f..165f -> bins["Botanical Green"]
                            hue in 165f..200f -> bins["Vibrant Teal"]
                            hue in 200f..260f -> bins["Cobalt Blue"]
                            hue in 260f..310f -> bins["Violet Purple"]
                            hue in 310f..345f -> bins["Soft Rose"]
                            else -> bins["Crimson Red"]
                        }
                    }
                }

                targetBin?.let { bin ->
                    bin.count++
                    bin.sumR += r
                    bin.sumG += g
                    bin.sumB += b
                }

                sampleCount++
            }
        }

        val safeSampleCount = max(1, sampleCount)
        val avgR = (totalR / safeSampleCount).toInt()
        val avgG = (totalG / safeSampleCount).toInt()
        val avgB = (totalB / safeSampleCount).toInt()
        val avgLum = totalLuminance / safeSampleCount
        val avgSat = totalSaturation / safeSampleCount

        val dominantHex = String.format("#%02X%02X%02X", avgR, avgG, avgB)

        // Calculate contrast standard deviation
        var varianceSum = 0.0
        for (sample in lumSamples) {
            val diff = sample - avgLum
            varianceSum += diff * diff
        }
        val lumStdDev = sqrt(varianceSum / safeSampleCount)

        // Top 3-4 dominant color clusters
        val sortedBins = bins.values.filter { it.count > 0 }.sortedByDescending { it.count }
        val paletteHexes = sortedBins.take(4).map { bin ->
            val bR = (bin.sumR / max(1, bin.count)).toInt()
            val bG = (bin.sumG / max(1, bin.count)).toInt()
            val bB = (bin.sumB / max(1, bin.count)).toInt()
            String.format("#%02X%02X%02X", bR, bG, bB)
        }
        val paletteNames = sortedBins.take(4).map { it.name }

        // Determine descriptive color tone
        val primaryBinName = sortedBins.firstOrNull()?.name ?: "Harmonious Multitone"
        val colorTone = when (primaryBinName) {
            "Botanical Green" -> "Lush Botanical Green & Earth"
            "Cobalt Blue", "Vibrant Teal" -> "Cool Cobalt & Teal Indigo"
            "Warm Amber", "Golden Honey" -> "Warm Amber & Golden Honey"
            "Crimson Red", "Soft Rose" -> "Vibrant Rose & Crimson"
            "Earthy Terracotta" -> "Earthy Terracotta & Warm Ochre"
            "Violet Purple" -> "Atmospheric Violet & Amethyst"
            "Slate Charcoal", "Crisp White" -> if (lumStdDev > 50) "High-Contrast Monochrome & Charcoal" else "Clean Neutral Minimalist"
            else -> "Harmonious Balanced Multitone"
        }

        // Saturation level
        val saturationLevel = when {
            avgSat > 0.55 -> "Vibrant Rich Saturation"
            avgSat > 0.25 -> "Natural True-to-Life Saturation"
            avgSat > 0.10 -> "Soft Muted Pastel Saturation"
            else -> "Desaturated Monochromatic Saturation"
        }

        // Contrast level
        val contrastLevel = when {
            lumStdDev > 55 || (maxLum - minLum > 210) -> "High Dynamic Contrast"
            lumStdDev > 35 -> "Balanced Natural Contrast"
            else -> "Soft Diffused Low Contrast"
        }

        // Lighting style analysis
        val avgTopLum = if (topSampleCount > 0) topLumSum / topSampleCount else avgLum
        val avgBottomLum = if (bottomSampleCount > 0) bottomLumSum / bottomSampleCount else avgLum
        val avgCenterLum = if (centerSampleCount > 0) centerLumSum / centerSampleCount else avgLum
        val avgEdgeLum = if (edgeSampleCount > 0) edgeLumSum / edgeSampleCount else avgLum

        val lightingStyle = when {
            avgLum > 175 -> "Bright High-Key Diffused Ambient Daylight"
            avgLum < 70 -> "Low-Key Atmospheric Chiaroscuro Lighting"
            avgTopLum > avgBottomLum + 40 -> "Overhead Ambient Lighting with Downward Shadow Modeling"
            avgCenterLum > avgEdgeLum + 35 -> "Central Spotlight Focus with Gentle Ambient Vignette Falloff"
            colorTone.contains("Amber") || colorTone.contains("Warm") -> "Directional Warm Golden-Hour Sunset Light"
            colorTone.contains("Blue") || colorTone.contains("Teal") -> "Cool Atmospheric Twilight Ambient Light"
            else -> "Balanced Natural Ambient Illumination"
        }

        val lumCategory = when {
            avgLum > 175 -> "Bright / High-Key"
            avgLum < 75 -> "Moody / Low-Key"
            colorTone.contains("Amber") || colorTone.contains("Warm") -> "Golden / Warm"
            else -> "Balanced Natural"
        }

        // Edge density and visual patterns
        val avgEdge = if (edgeCount > 0) totalEdgeGradient.toDouble() / edgeCount else 40.0
        val avgCenterEdge = if (centerEdgeCount > 0) centerEdgeGradient.toDouble() / centerEdgeCount else avgEdge
        val avgOuterEdge = if (outerEdgeCount > 0) outerEdgeGradient.toDouble() / outerEdgeCount else avgEdge

        val detailDensity = when {
            avgEdge > 75 -> "High-Frequency Textural Detail and Defined Edges"
            avgEdge > 35 -> "Clean Defined Edges with Natural Surface Textures"
            else -> "Smooth Ambient Transitions with Gentle Gradient Falloff"
        }

        val visualPattern = when {
            avgCenterEdge > avgOuterEdge * 1.6 -> "Isolated Focal Subject with Soft Ambient Depth of Field"
            avgEdge > 75 -> "Intricate Structural Patterns and Layered Geometric Textures"
            ratio > 1.25 -> "Horizontal Layering with Natural Horizon Depth"
            ratio < 0.8 -> "Vertical Columnar Elements with Upright Alignment"
            else -> "Balanced Organic Shapes with Natural Surface Flow"
        }

        // Composition style
        val compositionStyle = when {
            avgCenterEdge > avgOuterEdge * 1.5 -> "Central Focal Point with Background Separation"
            ratio > 1.4 -> "Expansive Wide-Angle Landscape Composition"
            ratio < 0.75 -> "Vertical Upright Structural Framing"
            abs(avgCenterLum - avgEdgeLum) < 15 -> "Evenly Distributed Balanced Composition"
            else -> "Dynamic Rule-of-Thirds Composition"
        }

        val estimatedSubject = when {
            avgCenterEdge > avgOuterEdge * 1.6 -> "Prominent Focal Subject"
            ratio > 1.25 && colorTone.contains("Green") -> "Natural Landscape & Environment"
            ratio > 1.25 && colorTone.contains("Blue") -> "Coastal / Oceanic Scenery"
            avgEdge > 75 -> "Detailed Architecture or Geometric Scene"
            else -> "Visual Scene & Environment"
        }

        return ImageTelemetry(
            width = w,
            height = h,
            aspectRatioLabel = aspectLabel,
            dominantColorHex = dominantHex,
            colorTone = colorTone,
            luminanceCategory = lumCategory,
            estimatedSubjects = estimatedSubject,
            lightingStyle = lightingStyle,
            paletteHexes = paletteHexes,
            colorNames = paletteNames,
            saturationLevel = saturationLevel,
            contrastLevel = contrastLevel,
            visualPattern = visualPattern,
            compositionStyle = compositionStyle,
            detailDensity = detailDensity
        )
    }

    private fun calculateHue(r: Int, g: Int, b: Int): Float {
        val minVal = min(r, min(g, b)).toFloat()
        val maxVal = max(r, max(g, b)).toFloat()
        val delta = maxVal - minVal
        if (delta == 0f) return 0f

        var hue = when {
            r.toFloat() == maxVal -> (g - b) / delta
            g.toFloat() == maxVal -> 2f + (b - r) / delta
            else -> 4f + (r - g) / delta
        } * 60f

        if (hue < 0f) hue += 360f
        return hue
    }
}
