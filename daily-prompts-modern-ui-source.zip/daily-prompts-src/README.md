<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/e9e5684e-4acc-46d2-8263-737c4902f915

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.


## Maintenance notes

- API key settings now reject blank or obviously invalid keys consistently with the app's key-status state.
- Prompt enhancement no longer uses a Kotlin non-null assertion for the original topic.
- Debug builds use Android Gradle Plugin's default debug signing; release signing is enabled only when release keystore environment variables are supplied.
- Private signing keystores and local `.env` files must not be committed or shared. The keystore present in the uploaded archive was excluded from this revised source package.
- This environment did not include the Gradle wrapper scripts/JAR or an Android SDK, so a compiled APK and device tests could not be produced here. Open the project in Android Studio, sync Gradle, then run unit tests and build a debug APK.


## UI refresh

- New installs now use the existing Purple palette as the modern default; saved theme preferences remain respected.
- The home greeting uses a cleaner, bold sans-serif type treatment and refined spacing.
- Purple is available at the top of the theme picker.
