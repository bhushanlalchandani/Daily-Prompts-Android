package com.aistudio.dailyprompts.pkmnz.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [PromptEntity::class, DislikedTypeEntity::class, GeneratedPromptEntity::class], version = 3, exportSchema = false)
abstract class PromptDatabase : RoomDatabase() {
    abstract fun promptDao(): PromptDao

    companion object {
        @Volatile
        private var INSTANCE: PromptDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Safely alter prompts table to add isDisliked column only if not already present
                val cursor = db.query("PRAGMA table_info(prompts)")
                var hasIsDisliked = false
                try {
                    while (cursor.moveToNext()) {
                        val nameIndex = cursor.getColumnIndex("name")
                        if (nameIndex != -1 && cursor.getString(nameIndex) == "isDisliked") {
                            hasIsDisliked = true
                            break
                        }
                    }
                } finally {
                    cursor.close()
                }

                if (!hasIsDisliked) {
                    db.execSQL("ALTER TABLE prompts ADD COLUMN isDisliked INTEGER NOT NULL DEFAULT 0")
                }

                // Safely create disliked_types table
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS disliked_types (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        category TEXT NOT NULL,
                        tagOrKeyword TEXT NOT NULL,
                        promptTitle TEXT NOT NULL,
                        timestamp INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS generated_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        topic TEXT NOT NULL,
                        promptText TEXT NOT NULL,
                        targetAi TEXT NOT NULL DEFAULT 'ChatGPT',
                        category TEXT NOT NULL DEFAULT 'General',
                        style TEXT NOT NULL DEFAULT 'Professional',
                        isGeminiPowered INTEGER NOT NULL DEFAULT 0,
                        mode TEXT NOT NULL DEFAULT 'TEXT',
                        createdAt INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        fun getInstance(context: Context): PromptDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PromptDatabase::class.java,
                    "daily_prompts_db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .fallbackToDestructiveMigrationOnDowngrade(dropAllTables = true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
