package com.aistudio.dailyprompts.pkmnz.data.remote.ai

/**
 * Manages AI prompt generation with primary provider (Google Gemini) and
 * automatic fallback to OpenAI/ChatGPT on quota exhaustion or rate limits.
 */
class AIProviderManager(
    val geminiProvider: AIProvider = GeminiProvider(),
    val openAIProvider: AIProvider? = null,
    val preferredProviderProvider: () -> String = { "gemini" }
) {
    suspend fun generatePrompt(request: AIPromptRequest): AIProviderResult {
        val preferred = preferredProviderProvider().trim().lowercase()
        val (primary, secondary) = if ((preferred.contains("chatgpt") || preferred.contains("openai")) && openAIProvider != null) {
            openAIProvider to geminiProvider
        } else {
            geminiProvider to openAIProvider
        }

        // 1. Execute Primary Provider
        val primaryResult = primary.generatePrompt(request)
        if (primaryResult is AIProviderResult.Success) {
            return primaryResult
        }

        val primaryError = (primaryResult as AIProviderResult.Failure).error

        // If secondary provider is unavailable or identical, return primary failure
        if (secondary == null || secondary == primary) {
            return primaryResult
        }

        // 2. Check if eligible for automatic fallback:
        // Quota/rate-limit (HTTP 429 / RESOURCE_EXHAUSTED), server error (5xx), network error, or missing primary key
        val eligibleForFailover = primaryError.isQuotaOrRateLimit() ||
                primaryError is AIProviderError.ServerError ||
                primaryError is AIProviderError.NetworkError ||
                primaryError is AIProviderError.KeyMissing

        if (!eligibleForFailover) {
            // Unrecoverable errors like policy refusals or invalid syntax do not trigger failover
            return primaryResult
        }

        // 3. Execute Secondary Provider (e.g. OpenAI Vision fallback)
        val secondaryResult = secondary.generatePrompt(request)
        if (secondaryResult is AIProviderResult.Success) {
            return secondaryResult
        }

        val secondaryError = (secondaryResult as AIProviderResult.Failure).error

        // 4. Construct clear, user-facing composite diagnostic error
        val compositeMessage = buildCompositeErrorMessage(
            primaryName = primary.name,
            primaryError = primaryError,
            secondaryName = secondary.name,
            secondaryError = secondaryError,
            isImageAnalysis = !request.imageBase64.isNullOrBlank()
        )

        return AIProviderResult.Failure(
            AIProviderError.GeneralError(
                provider = "${primary.name} & ${secondary.name}",
                message = compositeMessage
            )
        )
    }

    private fun buildCompositeErrorMessage(
        primaryName: String,
        primaryError: AIProviderError,
        secondaryName: String,
        secondaryError: AIProviderError,
        isImageAnalysis: Boolean
    ): String {
        val operation = if (isImageAnalysis) "Image Analysis" else "Prompt generation"
        return when {
            primaryError is AIProviderError.KeyMissing && secondaryError is AIProviderError.KeyMissing ->
                "Both $primaryName and $secondaryName API keys are unconfigured. Go to Settings > AI Keys to add your API key for live $operation."

            primaryError.isQuotaOrRateLimit() && secondaryError is AIProviderError.KeyMissing ->
                "$primaryName quota exhausted (429 RESOURCE_EXHAUSTED). Automatic fallback to $secondaryName skipped because $secondaryName API key is not configured in Settings."

            primaryError.isQuotaOrRateLimit() && secondaryError.isQuotaOrRateLimit() ->
                "Both $primaryName and $secondaryName quota/rate limits reached (429 RESOURCE_EXHAUSTED). Using offline Smart Vision Engine."

            primaryError is AIProviderError.NetworkError && secondaryError is AIProviderError.NetworkError ->
                "Network connection failed for both $primaryName and $secondaryName. Please check your internet connection."

            else ->
                "Primary $primaryName failed (${primaryError.message}). Fallback $secondaryName failed (${secondaryError.message})."
        }
    }
}
