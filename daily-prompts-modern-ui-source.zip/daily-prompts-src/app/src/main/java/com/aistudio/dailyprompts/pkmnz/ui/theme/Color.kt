package com.aistudio.dailyprompts.pkmnz.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// =========================================================================
// Dynamic "Daily Prompts" Palette (Yellow, Peach, Rose, Mint + Dark Modes)
// All colors dynamically respond to the user's selected theme and dark mode.
// =========================================================================

// Backgrounds & Surfaces
val WarmBackground: Color
    @Composable get() = LocalAppThemeColors.current.background

val WarmBackgroundSecondary: Color
    @Composable get() = LocalAppThemeColors.current.backgroundSecondary

val WarmCardSurface: Color
    @Composable get() = LocalAppThemeColors.current.cardSurface

val WarmCardSurfaceTinted: Color
    @Composable get() = LocalAppThemeColors.current.cardSurfaceTinted

val WarmCardBorder: Color
    @Composable get() = LocalAppThemeColors.current.cardBorder

val WarmCardBorderSubtle: Color
    @Composable get() = LocalAppThemeColors.current.cardBorderSubtle

// Primary Accents
val WarmYellow: Color
    @Composable get() = LocalAppThemeColors.current.primary

val WarmYellowDark: Color
    @Composable get() = LocalAppThemeColors.current.primaryDark

val WarmYellowLight: Color
    @Composable get() = LocalAppThemeColors.current.primaryLight

val WarmYellowSurface: Color
    @Composable get() = LocalAppThemeColors.current.primarySurface

val OnWarmYellow: Color
    @Composable get() = LocalAppThemeColors.current.onPrimary

// Secondary Accents
val SoftPeach: Color
    @Composable get() = LocalAppThemeColors.current.secondary

val SoftPeachBorder: Color
    @Composable get() = LocalAppThemeColors.current.cardBorder

val SoftPink: Color
    @Composable get() = LocalAppThemeColors.current.secondaryContainer

val SoftPinkBadge: Color
    @Composable get() = LocalAppThemeColors.current.secondaryContainer

val SoftPinkContainer: Color
    @Composable get() = LocalAppThemeColors.current.secondaryContainer

val AccentHeartPink: Color = Color(0xFFFF4D6D)        // Romantic vibrant heart pink

// Typography with high-contrast tones matching active theme & mode
val WarmTextPrimary: Color
    @Composable get() = LocalAppThemeColors.current.textPrimary

val WarmTextSecondary: Color
    @Composable get() = LocalAppThemeColors.current.textSecondary

val WarmTextTertiary: Color
    @Composable get() = LocalAppThemeColors.current.textTertiary

val WarmTextLabel: Color
    @Composable get() = LocalAppThemeColors.current.textLabel

// Category Circular Pastel Colors (Fixed aesthetic palette for categories)
val CatMotivationBg: Color = Color(0xFFFEF3C7)
val CatMotivationIcon: Color = Color(0xFFD97706)

val CatSelfCareBg: Color = Color(0xFFDCFCE7)
val CatSelfCareIcon: Color = Color(0xFF059669)

val CatProductivityBg: Color = Color(0xFFEDE9FE)
val CatProductivityIcon: Color = Color(0xFF7C3AED)

val CatCreativityBg: Color = Color(0xFFFCE7F3)
val CatCreativityIcon: Color = Color(0xFFDB2777)

val CatRelationshipsBg: Color = Color(0xFFFFE4E6)
val CatRelationshipsIcon: Color = Color(0xFFE11D48)

val CatMindfulnessBg: Color = Color(0xFFE0E7FF)
val CatMindfulnessIcon: Color = Color(0xFF4F46E5)

val CatHealthBg: Color = Color(0xFFFFEDD5)
val CatHealthIcon: Color = Color(0xFFEA580C)

val CatAllCategoriesBg: Color = Color(0xFFFEF9C3)
val CatAllCategoriesIcon: Color = Color(0xFFCA8A04)

val CatLifestyleBg: Color = Color(0xFFD1FAE5)
val CatLifestyleIcon: Color = Color(0xFF0D9488)

// Compatibility aliases mapped to dynamic theme
val SophisticatedBackground: Color
    @Composable get() = LocalAppThemeColors.current.background

val SophisticatedSurface: Color
    @Composable get() = LocalAppThemeColors.current.background

val SophisticatedCardSurface: Color
    @Composable get() = LocalAppThemeColors.current.cardSurface

val SophisticatedCardContainer: Color
    @Composable get() = LocalAppThemeColors.current.cardSurfaceTinted

val SophisticatedBorder: Color
    @Composable get() = LocalAppThemeColors.current.cardBorder

val SophisticatedPrimary: Color
    @Composable get() = LocalAppThemeColors.current.primary

val SophisticatedOnPrimary: Color
    @Composable get() = LocalAppThemeColors.current.onPrimary

val SophisticatedPrimaryContainer: Color
    @Composable get() = LocalAppThemeColors.current.primaryLight

val SophisticatedOnPrimaryContainer: Color
    @Composable get() = LocalAppThemeColors.current.onPrimary

val SophisticatedSecondary: Color
    @Composable get() = LocalAppThemeColors.current.secondary

val SophisticatedOnSecondary: Color
    @Composable get() = LocalAppThemeColors.current.textPrimary

val SophisticatedSecondaryContainer: Color
    @Composable get() = LocalAppThemeColors.current.secondaryContainer

val SophisticatedOnSecondaryContainer: Color
    @Composable get() = LocalAppThemeColors.current.textPrimary

val SophisticatedTextPrimary: Color
    @Composable get() = LocalAppThemeColors.current.textPrimary

val SophisticatedTextSecondary: Color
    @Composable get() = LocalAppThemeColors.current.textSecondary

val SophisticatedTextLabel: Color
    @Composable get() = LocalAppThemeColors.current.textLabel

val SophisticatedButtonSecondary: Color
    @Composable get() = if (LocalAppThemeColors.current.isDark) LocalAppThemeColors.current.chipContainer else LocalAppThemeColors.current.secondaryContainer

val SophisticatedButtonSecondaryActive: Color
    @Composable get() = if (LocalAppThemeColors.current.isDark) LocalAppThemeColors.current.cardSurfaceTinted else LocalAppThemeColors.current.secondary

// AI tool badge accents
val ChatGPTBadge: Color = Color(0xFF10A37F)
val MidjourneyBadge: Color = Color(0xFF9333EA)
val ClaudeBadge: Color = Color(0xFFD97706)
val GeminiBadge: Color = Color(0xFF2563EB)
