package com.aistudio.dailyprompts.pkmnz.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "generated_history")
data class GeneratedPromptEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val topic: String,
    val promptText: String,
    val targetAi: String = "ChatGPT",
    val category: String = "General",
    val style: String = "Professional",
    val isGeminiPowered: Boolean = false,
    val mode: String = "TEXT", // "TEXT" or "IMAGE"
    val createdAt: Long = System.currentTimeMillis()
)
