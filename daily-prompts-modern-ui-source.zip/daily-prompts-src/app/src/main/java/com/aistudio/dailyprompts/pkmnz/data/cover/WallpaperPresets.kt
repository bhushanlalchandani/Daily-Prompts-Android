package com.aistudio.dailyprompts.pkmnz.data.cover

import androidx.compose.ui.graphics.Color

enum class WallpaperType {
    DEFAULT,
    PRESET,
    CUSTOM
}

data class WallpaperPreset(
    val id: String,
    val name: String,
    val subtitle: String,
    val gradientColors: List<Color>,
    val accentColor: Color
)

data class WallpaperState(
    val type: WallpaperType = WallpaperType.DEFAULT,
    val presetId: String = "",
    val customPhotoPath: String? = null,
    val dimLevel: Float = 0.55f, // 0.20f (very clear) to 0.85f (dark moody)
    val updateTimestamp: Long = 0L
)

object WallpaperPresets {
    val PRESETS = listOf(
        WallpaperPreset(
            id = "obsidian_twilight",
            name = "Obsidian Twilight",
            subtitle = "Deep cosmic violet & indigo",
            gradientColors = listOf(
                Color(0xFF0D0E15),
                Color(0xFF1E1035),
                Color(0xFF331654),
                Color(0xFF130D24)
            ),
            accentColor = Color(0xFFD0BCFF)
        ),
        WallpaperPreset(
            id = "neon_cyberpunk",
            name = "Neon Cyberpunk",
            subtitle = "Electric magenta & cyan night",
            gradientColors = listOf(
                Color(0xFF090D16),
                Color(0xFF2E0D2E),
                Color(0xFF0B2B38),
                Color(0xFF071220)
            ),
            accentColor = Color(0xFF00E5FF)
        ),
        WallpaperPreset(
            id = "golden_dusk",
            name = "Golden Dusk",
            subtitle = "Warm amber & twilight horizon",
            gradientColors = listOf(
                Color(0xFF140D0A),
                Color(0xFF381C0D),
                Color(0xFF281108),
                Color(0xFF160B1C)
            ),
            accentColor = Color(0xFFFFB74D)
        ),
        WallpaperPreset(
            id = "midnight_forest",
            name = "Midnight Forest",
            subtitle = "Deep emerald mist & moss",
            gradientColors = listOf(
                Color(0xFF07120D),
                Color(0xFF0D281C),
                Color(0xFF0A2218),
                Color(0xFF05100C)
            ),
            accentColor = Color(0xFF69F0AE)
        ),
        WallpaperPreset(
            id = "nordic_aurora",
            name = "Nordic Aurora",
            subtitle = "Borealis teal & night veil",
            gradientColors = listOf(
                Color(0xFF080D14),
                Color(0xFF0D2E30),
                Color(0xFF201338),
                Color(0xFF091424)
            ),
            accentColor = Color(0xFF80CBC4)
        ),
        WallpaperPreset(
            id = "cosmic_starlight",
            name = "Cosmic Starlight",
            subtitle = "Deep nebula & stellar glow",
            gradientColors = listOf(
                Color(0xFF060710),
                Color(0xFF111E48),
                Color(0xFF251240),
                Color(0xFF0C1328)
            ),
            accentColor = Color(0xFF90CAF9)
        ),
        WallpaperPreset(
            id = "deep_ocean",
            name = "Deep Ocean",
            subtitle = "Abyssal cyan & luminous depths",
            gradientColors = listOf(
                Color(0xFF040C16),
                Color(0xFF072436),
                Color(0xFF092C3C),
                Color(0xFF030910)
            ),
            accentColor = Color(0xFF4DD0E1)
        )
    )

    fun getPreset(id: String): WallpaperPreset? {
        return PRESETS.firstOrNull { it.id == id }
    }
}
