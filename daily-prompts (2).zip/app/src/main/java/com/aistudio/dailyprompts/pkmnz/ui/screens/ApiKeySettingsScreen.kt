package com.aistudio.dailyprompts.pkmnz.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aistudio.dailyprompts.pkmnz.data.local.ApiKeyManager
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIModels
import com.aistudio.dailyprompts.pkmnz.ui.theme.AppTheme
import com.aistudio.dailyprompts.pkmnz.ui.theme.OnWarmYellow
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmBackground
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardBorder
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardBorderSubtle
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardSurface
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextSecondary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellow
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellowDark
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.PromptViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiKeySettingsScreen(
    viewModel: PromptViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    val hasKey by viewModel.hasApiKey.collectAsStateWithLifecycle()
    val hasOpenAIKey by viewModel.hasOpenAIKey.collectAsStateWithLifecycle()
    val preferredProvider by viewModel.preferredProvider.collectAsStateWithLifecycle()
    var inputKey by remember { mutableStateOf("") }
    var inputOpenAIKey by remember { mutableStateOf("") }
    var isKeyVisible by remember { mutableStateOf(false) }
    var isOpenAIKeyVisible by remember { mutableStateOf(false) }
    var showRemoveDialog by remember { mutableStateOf(false) }
    var showRemoveOpenAIDialog by remember { mutableStateOf(false) }
    var isTestingConnection by remember { mutableStateOf(false) }
    var testResultStatus by remember { mutableStateOf<String?>(null) }
    var testResultIsSuccess by remember { mutableStateOf<Boolean?>(null) }
    var isTestingOpenAIConnection by remember { mutableStateOf(false) }
    var testOpenAIResultStatus by remember { mutableStateOf<String?>(null) }
    var testOpenAIResultIsSuccess by remember { mutableStateOf<Boolean?>(null) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = WarmBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "AI Keys & Providers",
                        fontWeight = FontWeight.Bold,
                        color = WarmTextPrimary,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("api_key_screen_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = WarmTextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = WarmBackground)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Status Banner Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("api_key_status_card"),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (hasKey) {
                        if (AppTheme.colors.isDark) Color(0xFF1B3320) else Color(0xFFE8F5E9)
                    } else {
                        if (AppTheme.colors.isDark) Color(0xFF2C2518) else Color(0xFFFFF8E1)
                    }
                ),
                border = BorderStroke(
                    1.dp,
                    if (hasKey) Color(0xFF81C784) else Color(0xFFFFD54F)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                if (hasKey) Color(0xFF2E7D32) else Color(0xFFF57F17)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (hasKey) Icons.Default.CheckCircle else Icons.Default.Key,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (hasKey || hasOpenAIKey) "AI Active & Encrypted" else "Offline Smart Engine Active",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = if (hasKey || hasOpenAIKey) {
                                if (AppTheme.colors.isDark) Color(0xFFA5D6A7) else Color(0xFF1B5E20)
                            } else {
                                if (AppTheme.colors.isDark) Color(0xFFFFE082) else Color(0xFFE65100)
                            }
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = when {
                                hasKey && hasOpenAIKey ->
                                    "Primary: Google Gemini (${AIModels.GEMINI_PRIMARY})\nBackup: OpenAI (${AIModels.OPENAI_DEFAULT})\nInstant Offline Engine ready."
                                hasKey ->
                                    "Primary: Google Gemini (${AIModels.GEMINI_PRIMARY})\nBackup: Offline Smart Prompt Engine."
                                hasOpenAIKey ->
                                    "Primary: OpenAI (${AIModels.OPENAI_DEFAULT})\nBackup: Offline Smart Prompt Engine."
                                else ->
                                    "Daily Prompts is running on the offline Smart Engine. Paste your Gemini or OpenAI key below to enable live cloud AI."
                            },
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                            color = WarmTextSecondary
                        )
                    }
                }
            }

            // 1b. Preferred AI Provider Selection Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("preferred_ai_provider_card"),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = WarmCardSurface),
                border = BorderStroke(1.dp, WarmCardBorderSubtle)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Preferred AI Engine",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = WarmTextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Choose which AI provider is used primarily for prompt synthesis. Multimodal Image Analysis is handled exclusively by Gemini.",
                        fontSize = 12.sp,
                        color = WarmTextSecondary,
                        lineHeight = 16.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        val isGemini = preferredProvider == "gemini"
                        FilterChip(
                            selected = isGemini,
                            onClick = {
                                viewModel.setPreferredProvider("gemini")
                            },
                            label = { Text("Google Gemini") },
                            leadingIcon = if (isGemini) {
                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                            } else null,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("preferred_gemini_chip")
                        )
                        val isOpenAI = preferredProvider == "chatgpt" || preferredProvider == "openai"
                        FilterChip(
                            selected = isOpenAI,
                            onClick = {
                                viewModel.setPreferredProvider("chatgpt")
                            },
                            label = { Text("ChatGPT (OpenAI)") },
                            leadingIcon = if (isOpenAI) {
                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                            } else null,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("preferred_openai_chip")
                        )
                    }
                }
            }

            // 2. Key Input Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("api_key_input_card"),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = WarmCardSurface),
                border = BorderStroke(1.dp, WarmCardBorderSubtle)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Text(
                        text = if (hasKey) "Update Your Gemini API Key" else "Enter Gemini API Key",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = WarmTextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Paste your personal key from Google AI Studio. It will be encrypted with AES-256 on device.",
                        fontSize = 13.sp,
                        color = WarmTextSecondary,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = inputKey,
                        onValueChange = {
                            inputKey = it
                            testResultStatus = null
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("gemini_api_key_input_field"),
                        placeholder = {
                            Text(
                                text = if (hasKey) "Key is saved (paste to replace)..." else "AIzaSy...",
                                color = WarmTextSecondary.copy(alpha = 0.6f)
                            )
                        },
                        visualTransformation = if (isKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (inputKey.isNotEmpty()) {
                                    IconButton(onClick = { inputKey = "" }) {
                                        Icon(
                                            imageVector = Icons.Default.Clear,
                                            contentDescription = "Clear input",
                                            tint = WarmTextSecondary
                                        )
                                    }
                                }
                                IconButton(onClick = { isKeyVisible = !isKeyVisible }) {
                                    Icon(
                                        imageVector = if (isKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = if (isKeyVisible) "Hide key" else "Show key",
                                        tint = WarmTextSecondary
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = WarmYellowDark,
                            unfocusedBorderColor = WarmCardBorder,
                            focusedTextColor = WarmTextPrimary,
                            unfocusedTextColor = WarmTextPrimary,
                            focusedContainerColor = WarmBackground,
                            unfocusedContainerColor = WarmBackground
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Paste Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = {
                                val text = clipboardManager.getText()?.text?.trim().orEmpty()
                                if (text.isNotBlank()) {
                                    inputKey = text
                                    Toast.makeText(context, "Pasted from clipboard", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Clipboard is empty", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("paste_api_key_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentPaste,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Paste from Clipboard", fontSize = 13.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Save Key Button
                    Button(
                        onClick = {
                            val clean = inputKey.trim()
                            if (clean.isBlank()) {
                                Toast.makeText(context, "Please enter or paste a valid API key", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (!ApiKeyManager.isKeyFormatValid(clean)) {
                                Toast.makeText(context, "Key looks incomplete (must be at least 10 chars)", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            viewModel.saveGeminiApiKey(clean)
                            inputKey = ""
                            testResultStatus = null
                            Toast.makeText(context, "✨ Gemini API Key saved securely!", Toast.LENGTH_LONG).show()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("save_api_key_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = WarmYellow,
                            contentColor = OnWarmYellow
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (hasKey) "Update & Save Key" else "Save Key Securely",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    // Remove Key Button if set
                    if (hasKey) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { showRemoveDialog = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("remove_api_key_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444))
                        ) {
                            Text(
                                text = "Remove Saved API Key",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }

            // 3. Test Connection Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = WarmCardSurface),
                border = BorderStroke(1.dp, WarmCardBorderSubtle)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Text(
                        text = "Verify Connection",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = WarmTextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Send a lightweight test ping to Google Gemini to verify authorization.",
                        fontSize = 13.sp,
                        color = WarmTextSecondary
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = {
                            val keyToTest = inputKey.trim().ifBlank { viewModel.getGeminiApiKey() }
                            if (keyToTest.isBlank()) {
                                Toast.makeText(context, "Please enter or save a key first", Toast.LENGTH_SHORT).show()
                                return@OutlinedButton
                            }
                            isTestingConnection = true
                            testResultStatus = null

                            scope.launch {
                                val result = withContext(Dispatchers.IO) {
                                    testGeminiPing(keyToTest)
                                }
                                isTestingConnection = false
                                testResultStatus = result.first
                                testResultIsSuccess = result.second
                            }
                        },
                        enabled = !isTestingConnection && (inputKey.isNotBlank() || hasKey),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("test_gemini_connection_button"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        if (isTestingConnection) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Testing Gemini Ping...", fontSize = 14.sp)
                        } else {
                            Text("Test Gemini Connection ⚡", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    if (testResultStatus != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (testResultIsSuccess == true) {
                                    if (AppTheme.colors.isDark) Color(0xFF1B3320) else Color(0xFFE8F5E9)
                                } else {
                                    if (AppTheme.colors.isDark) Color(0xFF3B1E1E) else Color(0xFFFFEBEE)
                                }
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (testResultIsSuccess == true) Color(0xFF81C784) else Color(0xFFE57373)
                            )
                        ) {
                            Text(
                                text = testResultStatus.orEmpty(),
                                modifier = Modifier.padding(12.dp),
                                fontSize = 13.sp,
                                color = if (testResultIsSuccess == true) {
                                    if (AppTheme.colors.isDark) Color(0xFFA5D6A7) else Color(0xFF2E7D32)
                                } else {
                                    if (AppTheme.colors.isDark) Color(0xFFFFCDD2) else Color(0xFFC62828)
                                }
                            )
                        }
                    }
                }
            }

            // 3b. Backup Provider: OpenAI / ChatGPT
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("openai_api_key_card"),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = WarmCardSurface),
                border = BorderStroke(1.dp, WarmCardBorderSubtle)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Backup: OpenAI / ChatGPT",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = WarmTextPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Model: ${AIModels.OPENAI_DEFAULT} (Optional Failover)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = WarmYellowDark
                            )
                        }
                        if (hasOpenAIKey) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF2E7D32).copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "READY",
                                    color = Color(0xFF2E7D32),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "If Google Gemini encounters a quota limit (429) or temporary server unavailability, Daily Prompts automatically attempts OpenAI before falling back to the offline engine.",
                        fontSize = 13.sp,
                        color = WarmTextSecondary,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = inputOpenAIKey,
                        onValueChange = {
                            inputOpenAIKey = it
                            testOpenAIResultStatus = null
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("openai_api_key_input_field"),
                        placeholder = {
                            Text(
                                text = if (hasOpenAIKey) "OpenAI key saved (paste to replace)..." else "sk-...",
                                color = WarmTextSecondary.copy(alpha = 0.6f)
                            )
                        },
                        visualTransformation = if (isOpenAIKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (inputOpenAIKey.isNotEmpty()) {
                                    IconButton(onClick = { inputOpenAIKey = "" }) {
                                        Icon(
                                            imageVector = Icons.Default.Clear,
                                            contentDescription = "Clear input",
                                            tint = WarmTextSecondary
                                        )
                                    }
                                }
                                IconButton(onClick = { isOpenAIKeyVisible = !isOpenAIKeyVisible }) {
                                    Icon(
                                        imageVector = if (isOpenAIKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = if (isOpenAIKeyVisible) "Hide key" else "Show key",
                                        tint = WarmTextSecondary
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = WarmYellowDark,
                            unfocusedBorderColor = WarmCardBorder,
                            focusedTextColor = WarmTextPrimary,
                            unfocusedTextColor = WarmTextPrimary,
                            focusedContainerColor = WarmBackground,
                            unfocusedContainerColor = WarmBackground
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = {
                                val text = clipboardManager.getText()?.text?.trim().orEmpty()
                                if (text.isNotBlank()) {
                                    inputOpenAIKey = text
                                    Toast.makeText(context, "Pasted from clipboard", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Clipboard is empty", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("paste_openai_api_key_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentPaste,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Paste from Clipboard", fontSize = 13.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val clean = inputOpenAIKey.trim()
                            if (clean.isBlank()) {
                                Toast.makeText(context, "Please enter or paste a valid OpenAI key", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (!ApiKeyManager.isKeyFormatValid(clean)) {
                                Toast.makeText(context, "Key looks incomplete (must be at least 10 chars)", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            viewModel.saveOpenAIApiKey(clean)
                            inputOpenAIKey = ""
                            testOpenAIResultStatus = null
                            Toast.makeText(context, "✨ OpenAI API Key saved securely!", Toast.LENGTH_LONG).show()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("save_openai_api_key_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = WarmYellow,
                            contentColor = OnWarmYellow
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (hasOpenAIKey) "Update & Save OpenAI Key" else "Save OpenAI Key",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    if (hasOpenAIKey) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { showRemoveOpenAIDialog = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("remove_openai_api_key_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444))
                        ) {
                            Text(
                                text = "Remove OpenAI Key",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = {
                            val keyToTest = inputOpenAIKey.trim().ifBlank { viewModel.getOpenAIApiKey() }
                            if (keyToTest.isBlank()) {
                                Toast.makeText(context, "Please enter or save an OpenAI key first", Toast.LENGTH_SHORT).show()
                                return@OutlinedButton
                            }
                            isTestingOpenAIConnection = true
                            testOpenAIResultStatus = null

                            scope.launch {
                                val result = withContext(Dispatchers.IO) {
                                    testOpenAIPing(keyToTest)
                                }
                                isTestingOpenAIConnection = false
                                testOpenAIResultStatus = result.first
                                testOpenAIResultIsSuccess = result.second
                            }
                        },
                        enabled = !isTestingOpenAIConnection && (inputOpenAIKey.isNotBlank() || hasOpenAIKey),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("test_openai_connection_button"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        if (isTestingOpenAIConnection) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Testing OpenAI Ping...", fontSize = 14.sp)
                        } else {
                            Text("Test OpenAI Connection ⚡", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    if (testOpenAIResultStatus != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (testOpenAIResultIsSuccess == true) {
                                    if (AppTheme.colors.isDark) Color(0xFF1B3320) else Color(0xFFE8F5E9)
                                } else {
                                    if (AppTheme.colors.isDark) Color(0xFF3B1E1E) else Color(0xFFFFEBEE)
                                }
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (testOpenAIResultIsSuccess == true) Color(0xFF81C784) else Color(0xFFE57373)
                            )
                        ) {
                            Text(
                                text = testOpenAIResultStatus.orEmpty(),
                                modifier = Modifier.padding(12.dp),
                                fontSize = 13.sp,
                                color = if (testOpenAIResultIsSuccess == true) {
                                    if (AppTheme.colors.isDark) Color(0xFFA5D6A7) else Color(0xFF2E7D32)
                                } else {
                                    if (AppTheme.colors.isDark) Color(0xFFFFCDD2) else Color(0xFFC62828)
                                }
                            )
                        }
                    }
                }
            }

            // 4. Instructions / Link to get key
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(
                    containerColor = WarmBackground
                ),
                border = BorderStroke(1.dp, WarmCardBorderSubtle)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Text(
                        text = "How to get a free Gemini API key:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = WarmTextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "1. Visit Google AI Studio\n2. Sign in with your Google Account\n3. Click 'Create API Key' (free tier is available)\n4. Copy and paste your key here",
                        fontSize = 13.sp,
                        lineHeight = 20.sp,
                        color = WarmTextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            try {
                                uriHandler.openUri("https://aistudio.google.com/app/apikey")
                            } catch (_: Exception) {
                                Toast.makeText(context, "https://aistudio.google.com/app/apikey", Toast.LENGTH_LONG).show()
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = WarmCardSurface,
                            contentColor = WarmYellowDark
                        ),
                        border = BorderStroke(1.dp, WarmYellowDark.copy(alpha = 0.5f))
                    ) {
                        Text("Open Google AI Studio ↗", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // 5. Security & Privacy Guarantee
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = WarmCardSurface),
                border = BorderStroke(1.dp, WarmCardBorderSubtle)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = Color(0xFF10B981),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Security & Privacy First",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = WarmTextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• Zero hardcoded keys in this application.\n• Stored with AES-256 GCM using Android Keystore.\n• Sent directly to Google's API via secure HTTPS headers.\n• Never logged or shared with third parties.",
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        color = WarmTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    if (showRemoveDialog) {
        AlertDialog(
            onDismissRequest = { showRemoveDialog = false },
            title = {
                Text(
                    text = "Remove Gemini API Key?",
                    fontWeight = FontWeight.Bold,
                    color = WarmTextPrimary
                )
            },
            text = {
                Text(
                    text = "Your API key will be deleted from secure storage. Daily Prompts will continue crafting prompts via the offline Smart Engine.",
                    color = WarmTextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearGeminiApiKey()
                        showRemoveDialog = false
                        Toast.makeText(context, "API Key removed", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("Remove", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRemoveDialog = false }) {
                    Text("Cancel", color = WarmTextSecondary)
                }
            },
            containerColor = WarmCardSurface,
            shape = RoundedCornerShape(20.dp)
        )
    }
    if (showRemoveOpenAIDialog) {
        AlertDialog(
            onDismissRequest = { showRemoveOpenAIDialog = false },
            title = {
                Text(
                    text = "Remove OpenAI API Key?",
                    fontWeight = FontWeight.Bold,
                    color = WarmTextPrimary
                )
            },
            text = {
                Text(
                    text = "Your OpenAI API key will be deleted from secure storage. Daily Prompts will use Gemini and the offline Smart Engine.",
                    color = WarmTextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearOpenAIApiKey()
                        showRemoveOpenAIDialog = false
                        Toast.makeText(context, "OpenAI API Key removed", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("Remove", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRemoveOpenAIDialog = false }) {
                    Text("Cancel", color = WarmTextSecondary)
                }
            },
            containerColor = WarmCardSurface,
            shape = RoundedCornerShape(20.dp)
        )
    }
}

/**
 * Lightweight test ping to Google Gemini endpoint to verify key authorization.
 */
private suspend fun testGeminiPing(apiKey: String): Pair<String, Boolean> {
    return try {
        val client = OkHttpClient.Builder()
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build()

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", "Say 'OK' in one word.")
                        })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("maxOutputTokens", 5)
            })
        }

        val requestBody = jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/${AIModels.GEMINI_PRIMARY}:generateContent")
            .addHeader("x-goog-api-key", apiKey.trim())
            .post(requestBody)
            .build()

        client.newCall(request).execute().use { response ->
            val code = response.code
            val body = response.body?.string().orEmpty()
            if (response.isSuccessful) {
                Pair("✅ Success! Gemini connection verified successfully.", true)
            } else if (code == 400 && body.contains("API_KEY_INVALID")) {
                Pair("❌ API Key Invalid: Please check that you copied the complete key from Google AI Studio.", false)
            } else if (code == 401 || code == 403) {
                Pair("❌ Unauthorized ($code): The API key is rejected or expired.", false)
            } else if (code == 429) {
                Pair("⚠️ Quota Reached ($code): The key is valid, but the free tier rate limit was reached.", true)
            } else {
                Pair("⚠️ Server responded with code $code: ${body.take(100)}", false)
            }
        }
    } catch (e: Exception) {
        Pair("❌ Network error: Could not reach Gemini servers (${e.localizedMessage ?: "timeout"})", false)
    }
}

/**
 * Lightweight test ping to OpenAI chat completion endpoint to verify key authorization.
 */
private suspend fun testOpenAIPing(apiKey: String): Pair<String, Boolean> {
    return try {
        val client = OkHttpClient.Builder()
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build()

        val jsonBody = JSONObject().apply {
            put("model", AIModels.OPENAI_DEFAULT)
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", "Say OK")
                })
            })
            put("max_tokens", 5)
        }

        val requestBody = jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer ${apiKey.trim()}")
            .post(requestBody)
            .build()

        client.newCall(request).execute().use { response ->
            val code = response.code
            val body = response.body?.string().orEmpty()
            if (response.isSuccessful) {
                Pair("✅ Success! OpenAI connection verified successfully.", true)
            } else if (code == 401) {
                Pair("❌ API Key Invalid: OpenAI rejected the provided API key.", false)
            } else if (code == 429) {
                Pair("⚠️ Quota/Rate Limit ($code): Key is authorized, but credit or rate limit reached.", true)
            } else {
                Pair("⚠️ OpenAI responded with code $code: ${body.take(100)}", false)
            }
        }
    } catch (e: Exception) {
        Pair("❌ Network error: Could not reach OpenAI servers (${e.localizedMessage ?: "timeout"})", false)
    }
}
