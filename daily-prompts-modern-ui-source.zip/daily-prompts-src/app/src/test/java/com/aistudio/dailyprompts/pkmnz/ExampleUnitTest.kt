package com.aistudio.dailyprompts.pkmnz

import com.aistudio.dailyprompts.pkmnz.ui.i18n.AppStrings
import com.aistudio.dailyprompts.pkmnz.ui.theme.getThemeColors
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun testAll12Themes_lightAndDarkMode() {
        val themeNames = listOf(
            "Yellow", "Peach", "Rose", "Mint",
            "Blue", "Red", "Purple", "Teal",
            "Lavender", "Sky Blue", "Emerald Green", "Coral"
        )

        for (theme in themeNames) {
            val lightColors = getThemeColors(theme, isDark = false)
            assertNotNull("Light colors for $theme should not be null", lightColors)
            assertEquals("Theme name should match", theme, lightColors.name)
            assertTrue("isDark should be false", !lightColors.isDark)

            val darkColors = getThemeColors(theme, isDark = true)
            assertNotNull("Dark colors for $theme should not be null", darkColors)
            assertEquals("Theme name should match", theme, darkColors.name)
            assertTrue("isDark should be true", darkColors.isDark)
        }
    }

    @Test
    fun testAll12Themes_translations() {
        val themeNames = listOf(
            "Yellow", "Peach", "Rose", "Mint",
            "Blue", "Red", "Purple", "Teal",
            "Lavender", "Sky Blue", "Emerald Green", "Coral"
        )
        val languages = listOf("Spanish", "French", "German")

        for (theme in themeNames) {
            for (lang in languages) {
                val translated = AppStrings.translate(theme, lang)
                assertTrue(
                    "Translation of $theme to $lang should not be empty",
                    translated.isNotBlank()
                )
            }
        }
    }
}
