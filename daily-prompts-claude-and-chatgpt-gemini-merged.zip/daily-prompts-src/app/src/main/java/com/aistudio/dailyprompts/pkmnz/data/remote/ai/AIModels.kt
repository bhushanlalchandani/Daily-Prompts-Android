package com.aistudio.dailyprompts.pkmnz.data.remote.ai

/** Central model IDs used by Gemini requests. Keep aligned with the Gemini API model list. */
object AIModels {
    // Stable current Flash model for text and image-to-prompt requests.
    const val GEMINI_PRIMARY = "gemini-3.8-flash"

    // Supported lightweight fallback for projects where the primary model is unavailable.
    const val GEMINI_FALLBACK = "gemini-3.5-flash-lite"
    const val OPENAI_DEFAULT = "gpt-4o-mini"

    val GEMINI_MODELS = listOf(GEMINI_PRIMARY, GEMINI_FALLBACK).distinct()
}
