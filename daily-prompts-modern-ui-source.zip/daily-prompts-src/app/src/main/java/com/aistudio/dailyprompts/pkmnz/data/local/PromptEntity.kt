package com.aistudio.dailyprompts.pkmnz.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "prompts")
data class PromptEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val promptText: String,
    val category: String,
    val aiTool: String = "ChatGPT",
    val tags: String = "",
    val isDaily: Boolean = false,
    val isFavorite: Boolean = false,
    val isDisliked: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
