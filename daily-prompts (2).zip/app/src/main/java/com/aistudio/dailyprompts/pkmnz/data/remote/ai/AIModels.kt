package com.aistudio.dailyprompts.pkmnz.data.remote.ai

/**
 * Centralized constant definitions for all AI models utilized in the application.
 *
 * Supported models:
 * - Gemini Primary: "gemini-3.8-flash" (latest high-performance fast model)
 * - Gemini Fallback: "gemini-flash-latest" (stable fallback model)
 * - OpenAI Default: "gpt-4o-mini" (efficient chat/prompt model)
 */
object AIModels {
    const val GEMINI_PRIMARY = "gemini-3.8-flash"
    const val GEMINI_FALLBACK = "gemini-flash-latest"
    const val OPENAI_DEFAULT = "gpt-4o-mini"

    /**
     * Priority list of Gemini models to attempt in order.
     */
    val GEMINI_MODELS = listOf(GEMINI_PRIMARY, GEMINI_FALLBACK)
}
