# Daily Prompts Android

A lightweight native Android app that shows a daily creative prompt, includes a prompt library, and supports copying and sharing prompts.

## Build APK on GitHub Actions

1. Upload this ZIP (`Daily-Prompts-Android-Complete-Source.zip`) to the root of your `Daily-Prompts-Android` GitHub repository.
2. Commit directly to `main`.
3. Open the repository's **Actions** tab.
4. Select **Build Daily Prompts APK** and open the latest run.
5. When the run succeeds, open its **Artifacts** section and download `Daily-Prompts-debug-APK`.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`.

The workflow uses Java 17 and Gradle 8.9, compatible with Android Gradle Plugin 8.7.3. It finds the Android project inside the uploaded source ZIP instead of relying on hard-coded ZIP names.

## Project layout

- `settings.gradle.kts` — project modules and repositories
- `build.gradle.kts` — Android and Kotlin plugin versions
- `app/build.gradle.kts` — Android app configuration
- `app/src/main/` — app manifest, theme, and Kotlin source
- `.github/workflows/main.yml` — GitHub Actions APK build
