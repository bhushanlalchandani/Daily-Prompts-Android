package com.aistudio.dailyprompts.pkmnz.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.Text
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.aistudio.dailyprompts.pkmnz.data.model.UserProfile
import com.aistudio.dailyprompts.pkmnz.ui.theme.AccentHeartPink
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatCreativityBg
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatHealthBg
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatLifestyleBg
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatMindfulnessBg
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatMotivationBg
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatProductivityBg
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatRelationshipsBg
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatSelfCareBg
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellow
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellowDark

/**
 * Custom high-fidelity illustrations matching the reference design for Daily Prompts.
 * Includes the featured mountain sunset hero, category artwork thumbnails, and avatar.
 */

@Composable
fun SunsetHeroIllustration(
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        // 1. Sky Gradient - Golden Sunset
        val skyBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFFFFDFB0),
                Color(0xFFFFB885),
                Color(0xFFFF8E5E),
                Color(0xFFE56B6F)
            ),
            startY = 0f,
            endY = height * 0.75f
        )
        drawRect(brush = skyBrush, size = size)

        // 2. Glowing Sun Corona & Rays
        val sunCenter = Offset(width * 0.72f, height * 0.38f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0xFFFFFFFF),
                    Color(0xFFFFF3B0),
                    Color(0x80FFD166),
                    Color(0x00FF8E5E)
                ),
                center = sunCenter,
                radius = width * 0.32f
            ),
            center = sunCenter,
            radius = width * 0.32f
        )
        drawCircle(
            color = Color(0xFFFFFFFF),
            center = sunCenter,
            radius = width * 0.08f
        )

        // 3. Far Mountain Silhouette
        val farMountainPath = Path().apply {
            moveTo(0f, height * 0.52f)
            lineTo(width * 0.25f, height * 0.42f)
            lineTo(width * 0.5f, height * 0.48f)
            lineTo(width * 0.78f, height * 0.39f)
            lineTo(width, height * 0.46f)
            lineTo(width, height)
            lineTo(0f, height)
            close()
        }
        drawPath(
            path = farMountainPath,
            color = Color(0x998B5D6B)
        )

        // 4. Mid Mountain Silhouette
        val midMountainPath = Path().apply {
            moveTo(0f, height * 0.60f)
            lineTo(width * 0.35f, height * 0.50f)
            lineTo(width * 0.65f, height * 0.58f)
            lineTo(width * 0.88f, height * 0.48f)
            lineTo(width, height * 0.55f)
            lineTo(width, height)
            lineTo(0f, height)
            close()
        }
        drawPath(
            path = midMountainPath,
            color = Color(0xCC614051)
        )

        // 5. Foreground Hill Silhouette
        val foregroundHill = Path().apply {
            moveTo(0f, height * 0.75f)
            cubicTo(
                width * 0.25f, height * 0.70f,
                width * 0.55f, height * 0.78f,
                width, height * 0.66f
            )
            lineTo(width, height)
            lineTo(0f, height)
            close()
        }
        drawPath(
            path = foregroundHill,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF4A2F3D), Color(0xFF2E1C27)),
                startY = height * 0.66f,
                endY = height
            )
        )

        // 6. Silhouette of Woman with Yellow Dress & Straw Hat facing sunset
        val figureCenterX = width * 0.75f
        val figureBaseY = height * 0.88f
        val figureScale = height * 0.0032f

        // Yellow Dress Silhouette
        val dressPath = Path().apply {
            moveTo(figureCenterX - 28f * figureScale, figureBaseY)
            lineTo(figureCenterX + 28f * figureScale, figureBaseY)
            lineTo(figureCenterX + 16f * figureScale, figureBaseY - 55f * figureScale)
            lineTo(figureCenterX - 16f * figureScale, figureBaseY - 55f * figureScale)
            close()
        }
        drawPath(
            path = dressPath,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFFD54F), Color(0xFFF59E0B)),
                startY = figureBaseY - 55f * figureScale,
                endY = figureBaseY
            )
        )

        // Torso / Shoulders (Yellow)
        drawCircle(
            color = Color(0xFFFFD54F),
            center = Offset(figureCenterX, figureBaseY - 60f * figureScale),
            radius = 14f * figureScale
        )

        // Straw Hat (Brim & Crown)
        drawOval(
            color = Color(0xFFD97706),
            topLeft = Offset(figureCenterX - 22f * figureScale, figureBaseY - 80f * figureScale),
            size = Size(44f * figureScale, 12f * figureScale)
        )
        drawCircle(
            color = Color(0xFFB45309),
            center = Offset(figureCenterX, figureBaseY - 78f * figureScale),
            radius = 10f * figureScale
        )
    }
}

/**
 * Category Thumbnail Art based on category name.
 */
@Composable
fun CategoryArtThumbnail(
    category: String,
    modifier: Modifier = Modifier
) {
    val cleanCat = category.lowercase().trim()
    when {
        cleanCat.contains("motivation") -> MotivationArt(modifier)
        cleanCat.contains("self") || cleanCat.contains("care") -> SelfCareArt(modifier)
        cleanCat.contains("product") || cleanCat.contains("tech") || cleanCat.contains("code") -> ProductivityArt(modifier)
        cleanCat.contains("creat") || cleanCat.contains("art") -> CreativityArt(modifier)
        cleanCat.contains("relat") || cleanCat.contains("love") -> RelationshipsArt(modifier)
        cleanCat.contains("mind") || cleanCat.contains("zen") -> MindfulnessArt(modifier)
        cleanCat.contains("health") || cleanCat.contains("fit") -> HealthArt(modifier)
        cleanCat.contains("life") -> LifestyleArt(modifier)
        else -> SunsetHeroIllustration(modifier)
    }
}

@Composable
fun MotivationArt(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Sunrise sky
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFED7AA), Color(0xFFFDBA74), Color(0xFFFB923C)),
                startY = 0f,
                endY = h
            )
        )
        // Radiant Sun
        val sunCenter = Offset(w * 0.5f, h * 0.45f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White, Color(0x99FDE047), Color(0x00FB923C)),
                center = sunCenter,
                radius = w * 0.4f
            ),
            center = sunCenter,
            radius = w * 0.4f
        )
        drawCircle(Color.White, center = sunCenter, radius = w * 0.12f)

        // Mountain Summit
        val peakPath = Path().apply {
            moveTo(0f, h)
            lineTo(w * 0.5f, h * 0.52f)
            lineTo(w, h)
            close()
        }
        drawPath(peakPath, color = Color(0xFF431407))

        // Hiker Silhouette reaching summit
        drawCircle(Color(0xFF270E05), center = Offset(w * 0.5f, h * 0.44f), radius = w * 0.035f)
        drawLine(
            color = Color(0xFF270E05),
            start = Offset(w * 0.5f, h * 0.47f),
            end = Offset(w * 0.5f, h * 0.52f),
            strokeWidth = w * 0.035f
        )
    }
}

@Composable
fun SelfCareArt(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Soft pastel pink/cream background
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFFF1F2), Color(0xFFFFE4E6), Color(0xFFFECDD3))
            )
        )

        // Saucer
        drawOval(
            color = Color(0xFFE2E8F0),
            topLeft = Offset(w * 0.22f, h * 0.65f),
            size = Size(w * 0.56f, h * 0.18f)
        )
        drawOval(
            color = Color(0xFFCBD5E1),
            topLeft = Offset(w * 0.26f, h * 0.67f),
            size = Size(w * 0.48f, h * 0.14f)
        )

        // Tea Cup
        val cupPath = Path().apply {
            moveTo(w * 0.32f, h * 0.44f)
            lineTo(w * 0.68f, h * 0.44f)
            cubicTo(w * 0.68f, h * 0.68f, w * 0.32f, h * 0.68f, w * 0.32f, h * 0.44f)
            close()
        }
        drawPath(cupPath, color = Color(0xFFF472B6))

        // Cup Handle
        drawArc(
            color = Color(0xFFEC4899),
            startAngle = 270f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(w * 0.62f, h * 0.47f),
            size = Size(w * 0.15f, h * 0.14f),
            style = Stroke(width = w * 0.03f)
        )

        // Steam trails
        val steamPath = Path().apply {
            moveTo(w * 0.45f, h * 0.38f)
            cubicTo(w * 0.42f, h * 0.30f, w * 0.48f, h * 0.26f, w * 0.45f, h * 0.18f)
            moveTo(w * 0.55f, h * 0.38f)
            cubicTo(w * 0.52f, h * 0.30f, w * 0.58f, h * 0.26f, w * 0.55f, h * 0.18f)
        }
        drawPath(steamPath, color = Color(0x66F43F5E), style = Stroke(width = w * 0.02f))
    }
}

@Composable
fun ProductivityArt(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Clean desk background
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFEDE9FE), Color(0xFFDDD6FE), Color(0xFFC4B5FD))
            )
        )

        // Laptop Base
        drawRoundRect(
            color = Color(0xFF475569),
            topLeft = Offset(w * 0.2f, h * 0.62f),
            size = Size(w * 0.6f, h * 0.08f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
        )

        // Laptop Screen
        drawRoundRect(
            color = Color(0xFF1E293B),
            topLeft = Offset(w * 0.26f, h * 0.32f),
            size = Size(w * 0.48f, h * 0.30f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
        )

        // Display Glow
        drawRoundRect(
            color = Color(0xFF38BDF8),
            topLeft = Offset(w * 0.29f, h * 0.35f),
            size = Size(w * 0.42f, h * 0.24f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
        )

        // Coffee mug on desk
        drawCircle(Color(0xFFF97316), center = Offset(w * 0.82f, h * 0.65f), radius = w * 0.06f)
    }
}

@Composable
fun CreativityArt(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Soft lavender pink studio
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFDF4FF), Color(0xFFFAE8FF), Color(0xFFF5D0FE))
            )
        )

        // Artist Wooden Palette
        val palettePath = Path().apply {
            moveTo(w * 0.2f, h * 0.5f)
            cubicTo(w * 0.15f, h * 0.2f, w * 0.85f, h * 0.2f, w * 0.8f, h * 0.5f)
            cubicTo(w * 0.75f, h * 0.85f, w * 0.4f, h * 0.85f, w * 0.3f, h * 0.7f)
            cubicTo(w * 0.25f, h * 0.6f, w * 0.15f, h * 0.6f, w * 0.2f, h * 0.5f)
            close()
        }
        drawPath(palettePath, color = Color(0xFFE2A76F))

        // Color Paint Dabs on Palette
        val colors = listOf(
            Color(0xFFEF4444), // Red
            Color(0xFFF59E0B), // Yellow/Orange
            Color(0xFF10B981), // Green
            Color(0xFF3B82F6), // Blue
            Color(0xFF8B5CF6)  // Purple
        )
        val positions = listOf(
            Offset(w * 0.35f, h * 0.35f),
            Offset(w * 0.50f, h * 0.30f),
            Offset(w * 0.65f, h * 0.35f),
            Offset(w * 0.70f, h * 0.50f),
            Offset(w * 0.55f, h * 0.62f)
        )
        for (i in colors.indices) {
            drawCircle(colors[i], center = positions[i], radius = w * 0.055f)
        }
    }
}

@Composable
fun RelationshipsArt(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Romantic golden sunset
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFFEDD5), Color(0xFFFED7AA), Color(0xFFFB7185))
            )
        )

        // Sun Glow in middle of heart
        val heartCenter = Offset(w * 0.5f, h * 0.5f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White, Color(0x99FDE047), Color(0x00FB7185)),
                center = heartCenter,
                radius = w * 0.3f
            ),
            center = heartCenter,
            radius = w * 0.3f
        )

        // Hands making Heart Silhouette
        val heartPath = Path().apply {
            moveTo(w * 0.5f, h * 0.68f)
            cubicTo(w * 0.25f, h * 0.52f, w * 0.25f, h * 0.35f, w * 0.4f, h * 0.35f)
            cubicTo(w * 0.48f, h * 0.35f, w * 0.5f, h * 0.42f, w * 0.5f, h * 0.45f)
            cubicTo(w * 0.5f, h * 0.42f, w * 0.52f, h * 0.35f, w * 0.6f, h * 0.35f)
            cubicTo(w * 0.75f, h * 0.35f, w * 0.75f, h * 0.52f, w * 0.5f, h * 0.68f)
            close()
        }
        drawPath(heartPath, color = AccentHeartPink, style = Stroke(width = w * 0.04f))
    }
}

@Composable
fun MindfulnessArt(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Calm water twilight gradient
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFE0E7FF), Color(0xFFC7D2FE), Color(0xFFA5B4FC))
            )
        )

        // Water ripples
        for (y in listOf(h * 0.75f, h * 0.82f, h * 0.90f)) {
            drawLine(
                color = Color(0x66FFFFFF),
                start = Offset(w * 0.15f, y),
                end = Offset(w * 0.85f, y),
                strokeWidth = 2f
            )
        }

        // Stacked Zen River Stones (Smooth, balanced)
        // Base Stone
        drawOval(
            color = Color(0xFF334155),
            topLeft = Offset(w * 0.28f, h * 0.66f),
            size = Size(w * 0.44f, h * 0.12f)
        )
        // Middle Stone
        drawOval(
            color = Color(0xFF475569),
            topLeft = Offset(w * 0.33f, h * 0.54f),
            size = Size(w * 0.34f, h * 0.11f)
        )
        // Top Stone
        drawOval(
            color = Color(0xFF64748B),
            topLeft = Offset(w * 0.39f, h * 0.43f),
            size = Size(w * 0.22f, h * 0.10f)
        )
        // Smallest Stone on top
        drawOval(
            color = Color(0xFF94A3B8),
            topLeft = Offset(w * 0.43f, h * 0.34f),
            size = Size(w * 0.14f, h * 0.08f)
        )
    }
}

@Composable
fun HealthArt(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Sunrise beach gradient
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFFEDD5), Color(0xFFFED7AA), Color(0xFFFDBA74))
            )
        )

        // Sun
        drawCircle(Color.White, center = Offset(w * 0.5f, h * 0.45f), radius = w * 0.14f)

        // Ocean shoreline
        drawRect(
            color = Color(0xFF0284C7),
            topLeft = Offset(0f, h * 0.72f),
            size = Size(w, h * 0.28f)
        )
        drawRect(
            color = Color(0xFFFCD34D),
            topLeft = Offset(0f, h * 0.84f),
            size = Size(w, h * 0.16f)
        )

        // Yoga Meditating Silhouette
        val yogaCenter = Offset(w * 0.5f, h * 0.68f)
        drawCircle(Color(0xFF431407), center = Offset(yogaCenter.x, yogaCenter.y - h * 0.14f), radius = w * 0.045f)
        // Cross legged base
        drawOval(
            color = Color(0xFF431407),
            topLeft = Offset(yogaCenter.x - w * 0.18f, yogaCenter.y - h * 0.02f),
            size = Size(w * 0.36f, h * 0.08f)
        )
        // Torso
        drawLine(
            color = Color(0xFF431407),
            start = Offset(yogaCenter.x, yogaCenter.y - h * 0.10f),
            end = Offset(yogaCenter.x, yogaCenter.y),
            strokeWidth = w * 0.05f
        )
    }
}

@Composable
fun LifestyleArt(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Sunlit warm room
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFFFBEB), Color(0xFFFEF3C7), Color(0xFFFDE68A))
            )
        )

        // Window Frame
        drawRoundRect(
            color = Color(0xFFF59E0B),
            topLeft = Offset(w * 0.18f, h * 0.2f),
            size = Size(w * 0.36f, h * 0.4f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f),
            style = Stroke(width = w * 0.025f)
        )

        // Plant Pot on Table
        drawRect(
            color = Color(0xFFD97706),
            topLeft = Offset(0f, h * 0.7f),
            size = Size(w, h * 0.3f)
        )
        drawRoundRect(
            color = Color(0xFFEA580C),
            topLeft = Offset(w * 0.62f, h * 0.62f),
            size = Size(w * 0.22f, h * 0.16f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
        )

        // Green Leaves
        drawCircle(Color(0xFF16A34A), center = Offset(w * 0.68f, h * 0.52f), radius = w * 0.08f)
        drawCircle(Color(0xFF22C55E), center = Offset(w * 0.78f, h * 0.54f), radius = w * 0.07f)
        drawCircle(Color(0xFF15803D), center = Offset(w * 0.72f, h * 0.46f), radius = w * 0.06f)
    }
}

/**
 * Modern circular profile avatar of the Daily Prompts character in yellow top.
 */
@Composable
fun DailyPromptsAvatar(
    modifier: Modifier = Modifier,
    sizeDp: Dp = 44.dp,
    profile: UserProfile? = null
) {
    val customPath = profile?.customAvatarPath
    if (customPath != null && java.io.File(customPath).exists()) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(java.io.File(customPath))
                .crossfade(true)
                .build(),
            contentDescription = "Profile Photo",
            contentScale = ContentScale.Crop,
            modifier = modifier
                .size(sizeDp)
                .clip(CircleShape)
        )
        return
    }

    if (profile?.avatarType == UserProfile.AVATAR_LOTUS) {
        Box(
            modifier = modifier
                .size(sizeDp)
                .clip(CircleShape)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFFFEF3C7),
                            Color(0xFFFFE082),
                            Color(0xFFFFB300)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            GoldenLotusLogo(sizeDp = sizeDp * 0.65f)
        }
        return
    }

    if (profile?.avatarType == UserProfile.AVATAR_SUNSET) {
        Box(
            modifier = modifier
                .size(sizeDp)
                .clip(CircleShape)
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFFFF8A65),
                            Color(0xFFFF5252),
                            Color(0xFF7E57C2)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "✨",
                fontSize = (sizeDp.value * 0.42f).sp
            )
        }
        return
    }

    if (profile?.avatarType == UserProfile.AVATAR_MINT) {
        Box(
            modifier = modifier
                .size(sizeDp)
                .clip(CircleShape)
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFFA7F3D0),
                            Color(0xFF34D399),
                            Color(0xFF059669)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "🌿",
                fontSize = (sizeDp.value * 0.42f).sp
            )
        }
        return
    }

    if (profile?.avatarType == UserProfile.AVATAR_ROSE) {
        Box(
            modifier = modifier
                .size(sizeDp)
                .clip(CircleShape)
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFFFCE7F3),
                            Color(0xFFF472B6),
                            Color(0xFFDB2777)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "🌸",
                fontSize = (sizeDp.value * 0.42f).sp
            )
        }
        return
    }

    Box(
        modifier = modifier
            .size(sizeDp)
            .clip(CircleShape)
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFFEF3C7),
                        Color(0xFFFFD54F),
                        Color(0xFFF59E0B)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Hair
            drawCircle(
                color = Color(0xFF5C3826),
                center = Offset(w * 0.5f, h * 0.46f),
                radius = w * 0.36f
            )

            // Face (gentle skin tone)
            drawCircle(
                color = Color(0xFFFFDFC4),
                center = Offset(w * 0.5f, h * 0.48f),
                radius = w * 0.26f
            )

            // Front soft bangs
            drawArc(
                color = Color(0xFF5C3826),
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = true,
                topLeft = Offset(w * 0.24f, h * 0.26f),
                size = Size(w * 0.52f, h * 0.32f)
            )

            // Playful wink / eyes
            // Left eye (open sparkle)
            drawCircle(
                color = Color(0xFF332015),
                center = Offset(w * 0.41f, h * 0.47f),
                radius = w * 0.035f
            )
            // Right eye (playful wink curve)
            drawArc(
                color = Color(0xFF332015),
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = false,
                topLeft = Offset(w * 0.54f, h * 0.44f),
                size = Size(w * 0.09f, h * 0.06f),
                style = Stroke(width = w * 0.03f)
            )

            // Rosy cheeks
            drawCircle(
                color = Color(0x66FF6B81),
                center = Offset(w * 0.36f, h * 0.53f),
                radius = w * 0.045f
            )
            drawCircle(
                color = Color(0x66FF6B81),
                center = Offset(w * 0.64f, h * 0.53f),
                radius = w * 0.045f
            )

            // Gentle smile
            drawArc(
                color = Color(0xFF991B1B),
                startAngle = 0f,
                sweepAngle = 180f,
                useCenter = false,
                topLeft = Offset(w * 0.44f, h * 0.55f),
                size = Size(w * 0.12f, h * 0.06f),
                style = Stroke(width = w * 0.025f)
            )

            // Yellow off-shoulder knit sweater
            drawOval(
                brush = Brush.verticalGradient(
                    listOf(Color(0xFFFFD54F), Color(0xFFF59E0B)),
                    startY = h * 0.70f,
                    endY = h
                ),
                topLeft = Offset(w * 0.12f, h * 0.72f),
                size = Size(w * 0.76f, h * 0.50f)
            )
        }
    }
}

/**
 * Blooming Golden Lotus Icon (matching the brand logo).
 */
@Composable
fun GoldenLotusLogo(
    modifier: Modifier = Modifier,
    sizeDp: Dp = 40.dp
) {
    Canvas(modifier = modifier.size(sizeDp)) {
        val w = size.width
        val h = size.height

        // Center Petal
        val centerPetal = Path().apply {
            moveTo(w * 0.5f, h * 0.2f)
            cubicTo(w * 0.38f, h * 0.45f, w * 0.38f, h * 0.68f, w * 0.5f, h * 0.8f)
            cubicTo(w * 0.62f, h * 0.68f, w * 0.62f, h * 0.45f, w * 0.5f, h * 0.2f)
            close()
        }
        drawPath(
            path = centerPetal,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFFE082), Color(0xFFFFB300)),
                startY = h * 0.2f,
                endY = h * 0.8f
            )
        )

        // Left Petal
        val leftPetal = Path().apply {
            moveTo(w * 0.25f, h * 0.35f)
            cubicTo(w * 0.18f, h * 0.58f, w * 0.32f, h * 0.76f, w * 0.48f, h * 0.8f)
            cubicTo(w * 0.36f, h * 0.68f, w * 0.34f, h * 0.50f, w * 0.25f, h * 0.35f)
            close()
        }
        drawPath(
            path = leftPetal,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFFD54F), Color(0xFFFFA000)),
                startY = h * 0.35f,
                endY = h * 0.8f
            )
        )

        // Right Petal
        val rightPetal = Path().apply {
            moveTo(w * 0.75f, h * 0.35f)
            cubicTo(w * 0.82f, h * 0.58f, w * 0.68f, h * 0.76f, w * 0.52f, h * 0.8f)
            cubicTo(w * 0.64f, h * 0.68f, w * 0.66f, h * 0.50f, w * 0.75f, h * 0.35f)
            close()
        }
        drawPath(
            path = rightPetal,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFFD54F), Color(0xFFFFA000)),
                startY = h * 0.35f,
                endY = h * 0.8f
            )
        )
    }
}
