package com.aistudio.dailyprompts.pkmnz.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aistudio.dailyprompts.pkmnz.data.model.PromptCategory
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedBorder
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedCardSurface
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedOnPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedTextLabel
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedTextSecondary

@Composable
fun CategoryFilterBar(
    selectedCategory: PromptCategory,
    onSelectCategory: (PromptCategory) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val scrollState = rememberScrollState()

    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        PromptCategory.values().forEach { category ->
            val isSelected = category == selectedCategory
            FilterChip(
                selected = isSelected,
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onSelectCategory(category)
                },
                shape = RoundedCornerShape(12.dp),
                border = if (!isSelected) BorderStroke(1.dp, SophisticatedBorder) else null,
                label = {
                    Text(
                        text = "${category.icon} ${category.displayName}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = SophisticatedPrimary,
                    selectedLabelColor = SophisticatedOnPrimary,
                    containerColor = SophisticatedCardSurface,
                    labelColor = SophisticatedTextLabel
                ),
                modifier = Modifier.testTag("filter_chip_${category.name}")
            )
        }
    }
}
