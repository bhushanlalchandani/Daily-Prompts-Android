package com.aistudio.dailyprompts.pkmnz.data.remote.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

class GeminiProvider(
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build(),
    private val apiKeyProvider: () -> String = { "" },
    private val baseUrl: String = "https://generativelanguage.googleapis.com/"
) : AIProvider {

    override val name: String = "Gemini"

    override suspend fun generatePrompt(request: AIPromptRequest): AIProviderResult = withContext(Dispatchers.IO) {
        val apiKey = apiKeyProvider().trim()
        if (!isKeyValid(apiKey)) {
            return@withContext AIProviderResult.Failure(
                AIProviderError.KeyMissing(name, "Gemini API key is not set. Add your key in Settings > API Key to unlock AI features.")
            )
        }

        val relevantDislikes = request.dislikedTypes.filter { disliked ->
            !request.topic.contains(disliked, ignoreCase = true) &&
                    !request.category.contains(disliked, ignoreCase = true)
        }

        val negativeConstraint = if (relevantDislikes.isNotEmpty()) {
            "\nCRITICAL USER PREFERENCE: The user has disliked and blocked the following types/categories: ${relevantDislikes.joinToString(", ")}. NEVER generate a prompt belonging to or resembling these blocked categories or styles."
        } else ""

        val systemPrompt = request.systemPrompt ?: """
            You are an elite Prompt Engineer. Your task is to generate a single, master-crafted, copy-paste ready prompt for ${request.targetAi}.
            The prompt must be exceptionally detailed, effective, and ready for the user to copy directly into ${request.targetAi} to get top-tier results.
            For portrait, beauty, fashion, character, or people prompts (such as 'beautiful girl', aesthetic portraits, models, creative characters), generate tasteful, respectful, artistic, and cinematic prompts detailing lighting, camera lenses (e.g. 85mm f/1.2), composition, color grading, and textures.
            Do not include conversational filler like 'Here is your prompt' or 'Sure!'.
            Return ONLY the exact prompt text ready to be copied and pasted.
            Category: ${request.category}
            Style / Tone: ${request.style}$negativeConstraint
        """.trimIndent()

        val userMessage = if (request.imageBase64.isNullOrBlank()) {
            "Create an advanced, high-performing prompt for: ${request.topic}"
        } else {
            request.topic
        }

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        if (!request.imageBase64.isNullOrBlank()) {
                            put(JSONObject().apply {
                                put("inlineData", JSONObject().apply {
                                    put("mimeType", request.imageMimeType ?: "image/jpeg")
                                    put("data", request.imageBase64)
                                })
                            })
                        }
                        put(JSONObject().apply {
                            put("text", "$systemPrompt\n\n$userMessage")
                        })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", request.temperature)
                put("maxOutputTokens", request.maxTokens)
            })
            put("safetySettings", JSONArray().apply {
                listOf(
                    "HARM_CATEGORY_HARASSMENT",
                    "HARM_CATEGORY_HATE_SPEECH",
                    "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                    "HARM_CATEGORY_DANGEROUS_CONTENT"
                ).forEach { harmCategory ->
                    put(JSONObject().apply {
                        put("category", harmCategory)
                        put("threshold", "BLOCK_ONLY_HIGH")
                    })
                }
            })
        }

        val mediaType = "application/json; charset=utf-8".toMediaType()
        val requestBody = jsonBody.toString().toRequestBody(mediaType)

        val models = AIModels.GEMINI_MODELS
        var lastError: AIProviderError? = null
        val cleanBase = baseUrl.trimEnd('/')

        for (model in models) {
            val endpoint = "$cleanBase/v1beta/models/$model:generateContent?key=$apiKey"
            val httpRequest = Request.Builder()
                .url(endpoint)
                .addHeader("x-goog-api-key", apiKey)
                .addHeader("Content-Type", "application/json; charset=utf-8")
                .post(requestBody)
                .build()

            try {
                httpClient.newCall(httpRequest).execute().use { response ->
                    val code = response.code
                    val rawBody = response.body?.string().orEmpty()
                    val lowerBody = rawBody.lowercase()

                    val retryAfter = response.header("Retry-After") ?: response.header("retry-after")
                    val retryNotice = if (!retryAfter.isNullOrBlank()) " (Retry-After: ${retryAfter}s)" else ""

                    val extractedErrorMsg = try {
                        JSONObject(rawBody).optJSONObject("error")?.optString("message")?.ifBlank { null }
                    } catch (_: Exception) { null } ?: rawBody.take(160)

                    // --- 1. Detect Gemini Quota & Rate Limit Errors ---
                    val isQuotaOrRateLimit = code == 429 ||
                            lowerBody.contains("resource_exhausted") ||
                            lowerBody.contains("quota_exceeded") ||
                            lowerBody.contains("rate_limit_exceeded") ||
                            lowerBody.contains("too_many_requests") ||
                            lowerBody.contains("quota exceeded") ||
                            lowerBody.contains("exceeded your current quota") ||
                            lowerBody.contains("rate limit")

                    if (isQuotaOrRateLimit) {
                        return@withContext AIProviderResult.Failure(
                            AIProviderError.QuotaExhausted(name, "Gemini quota or rate limit reached (429 RESOURCE_EXHAUSTED): $extractedErrorMsg$retryNotice")
                        )
                    }

                    // --- 2. Handle HTTP Errors ---
                    if (!response.isSuccessful) {
                        if (code == 401 || code == 403) {
                            if (lowerBody.contains("api_key") || lowerBody.contains("invalid") || lowerBody.contains("unauthorized") || lowerBody.contains("forbidden")) {
                                return@withContext AIProviderResult.Failure(
                                    AIProviderError.InvalidApiKey(name, "Gemini API key is unauthorized or invalid: $extractedErrorMsg")
                                )
                            }
                        }

                        if (code == 400) {
                            if (lowerBody.contains("api_key") || lowerBody.contains("key_invalid")) {
                                return@withContext AIProviderResult.Failure(
                                    AIProviderError.InvalidApiKey(name, "Gemini API key is invalid.")
                                )
                            }
                            return@withContext AIProviderResult.Failure(
                                AIProviderError.InvalidRequest(name, "Malformed Gemini request: $rawBody")
                            )
                        }

                        if (code == 404) {
                            // Model not found, try fallback model in list
                            lastError = AIProviderError.ServerError(name, code, "Model $model not found")
                            return@use
                        }

                        if (code in 500..599) {
                            lastError = AIProviderError.ServerError(name, code, "Gemini server error ($code)")
                            return@use
                        }

                        return@withContext AIProviderResult.Failure(
                            AIProviderError.GeneralError(name, "Gemini API error ($code): $rawBody")
                        )
                    }

                    // --- 3. Parse Successful Response ---
                    if (rawBody.isBlank()) {
                        return@withContext AIProviderResult.Failure(
                            AIProviderError.GeneralError(name, "Empty response body from Gemini.")
                        )
                    }

                    val json = JSONObject(rawBody)

                    // Check for safety/policy refusal
                    val promptFeedback = json.optJSONObject("promptFeedback")
                    val blockReason = promptFeedback?.optString("blockReason")
                    if (!blockReason.isNullOrBlank() && blockReason != "BLOCK_REASON_UNSPECIFIED") {
                        return@withContext AIProviderResult.Failure(
                            AIProviderError.PolicyRefusal(name, "Gemini blocked response: $blockReason")
                        )
                    }

                    val candidates = json.optJSONArray("candidates")
                    if (candidates != null && candidates.length() > 0) {
                        val firstCandidate = candidates.getJSONObject(0)
                        val finishReason = firstCandidate.optString("finishReason")
                        if (finishReason.equals("SAFETY", ignoreCase = true) || finishReason.equals("RECITATION", ignoreCase = true)) {
                            return@withContext AIProviderResult.Failure(
                                AIProviderError.PolicyRefusal(name, "Gemini generation refused due to policy ($finishReason)")
                            )
                        }

                        val content = firstCandidate.optJSONObject("content")
                        val parts = content?.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            val text = parts.getJSONObject(0).optString("text")
                            if (text.isNotBlank()) {
                                return@withContext AIProviderResult.Success(text.trim(), name)
                            }
                        }
                    }

                    return@withContext AIProviderResult.Failure(
                        AIProviderError.GeneralError(name, "No valid content candidates returned by Gemini.")
                    )
                }
            } catch (e: UnknownHostException) {
                return@withContext AIProviderResult.Failure(AIProviderError.NetworkError(name, "No internet connection: ${e.message}"))
            } catch (e: ConnectException) {
                return@withContext AIProviderResult.Failure(AIProviderError.NetworkError(name, "Could not connect to Gemini: ${e.message}"))
            } catch (e: SocketTimeoutException) {
                lastError = AIProviderError.NetworkError(name, "Gemini request timed out.")
            } catch (e: IOException) {
                val msg = e.message.orEmpty().lowercase()
                if (msg.contains("reset") || msg.contains("broken pipe") || msg.contains("connection")) {
                    return@withContext AIProviderResult.Failure(AIProviderError.NetworkError(name, "Network connection interrupted."))
                }
                lastError = AIProviderError.NetworkError(name, e.message ?: "Network I/O error")
            } catch (e: Exception) {
                return@withContext AIProviderResult.Failure(AIProviderError.GeneralError(name, e.message ?: "Unexpected error"))
            }
        }

        AIProviderResult.Failure(lastError ?: AIProviderError.GeneralError(name, "Unable to generate prompt via Gemini."))
    }

    private fun isKeyValid(key: String): Boolean {
        return key.isNotBlank() &&
                !key.contains("NOT_SET") &&
                !key.startsWith("MY_") &&
                !key.contains("placeholder", ignoreCase = true) &&
                key.length >= 15
    }
}
