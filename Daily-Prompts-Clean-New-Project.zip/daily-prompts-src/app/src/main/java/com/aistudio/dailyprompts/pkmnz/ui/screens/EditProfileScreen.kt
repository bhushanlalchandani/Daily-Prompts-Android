package com.aistudio.dailyprompts.pkmnz.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SentimentSatisfiedAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aistudio.dailyprompts.pkmnz.data.model.UserProfile
import com.aistudio.dailyprompts.pkmnz.ui.components.DailyPromptsAvatar
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmBackground
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardSurface
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardBorderSubtle
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextSecondary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextTertiary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellow
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellowDark
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.PromptViewModel
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppLanguage
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppStrings

private data class AvatarPresetOption(
    val id: String,
    val title: String
)

private val AVATAR_PRESETS = listOf(
    AvatarPresetOption(UserProfile.AVATAR_DEFAULT, "Classic Girl"),
    AvatarPresetOption(UserProfile.AVATAR_LOTUS, "Golden Lotus"),
    AvatarPresetOption(UserProfile.AVATAR_SUNSET, "Sunset Glow"),
    AvatarPresetOption(UserProfile.AVATAR_MINT, "Mint Zen"),
    AvatarPresetOption(UserProfile.AVATAR_ROSE, "Rose Bloom")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProfileScreen(
    viewModel: PromptViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val strings = LocalAppStrings.current
    val currentLanguage = LocalAppLanguage.current
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()

    // Local mutable state for editing — initialized from currently saved profile
    var nameText by remember(userProfile.name) { mutableStateOf(userProfile.name) }
    var bioText by remember(userProfile.bio) { mutableStateOf(userProfile.bio) }
    var emailText by remember(userProfile.email) { mutableStateOf(userProfile.email) }
    var selectedAvatarType by remember(userProfile.avatarType) { mutableStateOf(userProfile.avatarType) }
    var customPhotoPath by remember(userProfile.customAvatarPath) { mutableStateOf(userProfile.customAvatarPath) }
    var nameError by remember { mutableStateOf<String?>(null) }

    // Intercept hardware/gesture Back to discard unsaved changes
    BackHandler {
        onBack()
    }

    // Photo picker launcher (zero-permission standard Photo Picker)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            viewModel.saveCustomAvatarPhoto(uri) { success ->
                if (success) {
                    selectedAvatarType = UserProfile.AVATAR_CUSTOM
                }
            }
        }
    }

    val previewProfile = remember(nameText, bioText, emailText, selectedAvatarType, customPhotoPath, userProfile) {
        UserProfile(
            name = nameText.ifEmpty { "Daily Prompts" },
            bio = bioText,
            email = emailText,
            avatarType = if (userProfile.customAvatarPath != null && selectedAvatarType == UserProfile.AVATAR_CUSTOM) {
                UserProfile.AVATAR_CUSTOM
            } else {
                selectedAvatarType
            },
            customAvatarPath = userProfile.customAvatarPath
        )
    }

    val handleSave = {
        val trimmed = nameText.trim()
        if (trimmed.isBlank()) {
            nameError = "Profile name cannot be empty"
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        } else {
            nameError = null
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            val success = viewModel.saveUserProfile(
                name = trimmed,
                bio = bioText.trim(),
                email = emailText.trim(),
                avatarType = selectedAvatarType,
                customAvatarPath = userProfile.customAvatarPath,
                onSaved = {
                    onBack()
                }
            )
            if (success) {
                onBack()
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = WarmBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = strings.editProfileTitle,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            color = WarmTextPrimary
                        )
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onBack()
                        },
                        modifier = Modifier.testTag("edit_profile_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = strings.back,
                            tint = WarmTextPrimary
                        )
                    }
                },
                actions = {
                    TextButton(
                        onClick = { handleSave() },
                        modifier = Modifier.testTag("edit_profile_top_save_button")
                    ) {
                        Text(
                            text = strings.save,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = WarmYellowDark
                            )
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = WarmBackground
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Avatar Preview & Photo Action Controls
            item {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        contentAlignment = Alignment.BottomEnd,
                        modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(104.dp)
                                .shadow(elevation = 8.dp, shape = CircleShape, ambientColor = Color(0x22000000))
                                .border(3.dp, Color.White, CircleShape)
                        ) {
                            DailyPromptsAvatar(
                                sizeDp = 104.dp,
                                profile = previewProfile
                            )
                        }

                        // Photo Picker Floating Badge
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(WarmYellow, shape = CircleShape)
                                .clip(CircleShape)
                                .clickable {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                                .testTag("edit_profile_change_photo_badge"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddAPhoto,
                                contentDescription = "Change Photo",
                                tint = WarmTextPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Photo Action Buttons
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            shape = RoundedCornerShape(20.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = WarmTextPrimary
                            ),
                            modifier = Modifier.testTag("edit_profile_pick_photo_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddAPhoto,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = WarmYellowDark
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = strings.uploadPhotoBtn,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        if (userProfile.customAvatarPath != null) {
                            OutlinedButton(
                                onClick = {
                                    viewModel.removeCustomAvatarPhoto()
                                    selectedAvatarType = UserProfile.AVATAR_DEFAULT
                                },
                                shape = RoundedCornerShape(20.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Color(0xFFDC2626)
                                ),
                                modifier = Modifier.testTag("edit_profile_remove_photo_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = strings.delete,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }

            // 2. Avatar Style Preset Selector
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = WarmCardSurface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = strings.chooseAvatar,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = WarmTextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Select a themed character or upload your own above",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = WarmTextSecondary
                            )
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(AVATAR_PRESETS) { preset ->
                                val isSelected = selectedAvatarType == preset.id && userProfile.customAvatarPath == null
                                val dummyProfile = UserProfile(avatarType = preset.id, customAvatarPath = null)

                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable {
                                            selectedAvatarType = preset.id
                                            if (userProfile.customAvatarPath != null) {
                                                viewModel.removeCustomAvatarPhoto()
                                            }
                                        }
                                        .padding(4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(52.dp)
                                            .border(
                                                width = if (isSelected) 3.dp else 1.dp,
                                                color = if (isSelected) WarmYellowDark else Color(0x33000000),
                                                shape = CircleShape
                                            )
                                    ) {
                                        DailyPromptsAvatar(
                                            sizeDp = 52.dp,
                                            profile = dummyProfile
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        text = preset.title,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) WarmYellowDark else WarmTextSecondary
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 3. Profile Information Form
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = WarmCardSurface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Account Information",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = WarmTextPrimary
                            )
                        )

                        // Name Field
                        Column {
                            OutlinedTextField(
                                value = nameText,
                                onValueChange = {
                                    nameText = it
                                    if (it.trim().isNotBlank()) {
                                        nameError = null
                                    }
                                },
                                label = { Text(strings.fullNameLabel) },
                                placeholder = { Text("e.g., Alex or Daily Prompts") },
                                isError = nameError != null,
                                singleLine = true,
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = WarmYellowDark
                                    )
                                },
                                trailingIcon = {
                                    if (nameText.isNotEmpty()) {
                                        IconButton(onClick = { nameText = "" }) {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Clear name",
                                                tint = WarmTextTertiary
                                            )
                                        }
                                    }
                                },
                                keyboardOptions = KeyboardOptions(
                                    capitalization = KeyboardCapitalization.Words,
                                    imeAction = ImeAction.Next
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    // Explicit high-contrast colors: Material defaults were nearly white
                                    // on the cream input surface, making saved profile text unreadable.
                                    focusedTextColor = Color(0xFF172B3A),
                                    unfocusedTextColor = Color(0xFF172B3A),
                                    disabledTextColor = Color(0xFF64748B),
                                    focusedPlaceholderColor = Color(0xFF64748B),
                                    unfocusedPlaceholderColor = Color(0xFF64748B),
                                    focusedLabelColor = Color(0xFF176B8A),
                                    unfocusedLabelColor = Color(0xFF36546A),
                                    cursorColor = Color(0xFF0EA5E9),
                                    focusedBorderColor = Color(0xFF0EA5E9),
                                    unfocusedBorderColor = Color(0xFF94A3B8),
                                    unfocusedContainerColor = Color(0xFFFBF8F2),
                                    focusedContainerColor = Color.White
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("edit_profile_name_input")
                            )

                            if (nameError != null) {
                                Text(
                                    text = nameError ?: "",
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier
                                        .padding(start = 12.dp, top = 4.dp)
                                        .testTag("edit_profile_name_error")
                                )
                            }
                        }

                        // Tagline / Bio Field
                        OutlinedTextField(
                            value = bioText,
                            onValueChange = { bioText = it },
                            label = { Text(strings.bioLabel) },
                            placeholder = { Text("A better you, every day ❤️") },
                            maxLines = 3,
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.SentimentSatisfiedAlt,
                                    contentDescription = null,
                                    tint = WarmYellowDark
                                )
                            },
                            trailingIcon = {
                                if (bioText.isNotEmpty()) {
                                    IconButton(onClick = { bioText = "" }) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Clear bio",
                                            tint = WarmTextTertiary
                                        )
                                    }
                                }
                            },
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.Sentences,
                                imeAction = ImeAction.Next
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                // Keep typed values and hints readable on the light input surface.
                                focusedTextColor = Color(0xFF172B3A),
                                unfocusedTextColor = Color(0xFF172B3A),
                                disabledTextColor = Color(0xFF64748B),
                                focusedPlaceholderColor = Color(0xFF64748B),
                                unfocusedPlaceholderColor = Color(0xFF64748B),
                                focusedLabelColor = Color(0xFF176B8A),
                                unfocusedLabelColor = Color(0xFF36546A),
                                cursorColor = Color(0xFF0EA5E9),
                                focusedBorderColor = Color(0xFF0EA5E9),
                                unfocusedBorderColor = Color(0xFF94A3B8),
                                unfocusedContainerColor = Color(0xFFFBF8F2),
                                focusedContainerColor = Color.White
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("edit_profile_bio_input")
                        )

                        // Email Field (Account identifier)
                        OutlinedTextField(
                            value = emailText,
                            onValueChange = { emailText = it },
                            label = { Text(strings.emailLabel) },
                            placeholder = { Text("daily.prompts@mindful.me") },
                            singleLine = true,
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Email,
                                    contentDescription = null,
                                    tint = WarmYellowDark
                                )
                            },
                            keyboardOptions = KeyboardOptions(
                                imeAction = ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = { handleSave() }
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                // Keep typed values and hints readable on the light input surface.
                                focusedTextColor = Color(0xFF172B3A),
                                unfocusedTextColor = Color(0xFF172B3A),
                                disabledTextColor = Color(0xFF64748B),
                                focusedPlaceholderColor = Color(0xFF64748B),
                                unfocusedPlaceholderColor = Color(0xFF64748B),
                                focusedLabelColor = Color(0xFF176B8A),
                                unfocusedLabelColor = Color(0xFF36546A),
                                cursorColor = Color(0xFF0EA5E9),
                                focusedBorderColor = Color(0xFF0EA5E9),
                                unfocusedBorderColor = Color(0xFF94A3B8),
                                unfocusedContainerColor = Color(0xFFFBF8F2),
                                focusedContainerColor = Color.White
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("edit_profile_email_input")
                        )
                    }
                }
            }

            // 4. Action Buttons (Save Changes & Cancel)
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { handleSave() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("edit_profile_save_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = WarmYellowDark,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = strings.saveChangesBtn,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onBack()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("edit_profile_cancel_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = WarmTextSecondary
                        )
                    ) {
                        Text(
                            text = strings.cancel,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}
