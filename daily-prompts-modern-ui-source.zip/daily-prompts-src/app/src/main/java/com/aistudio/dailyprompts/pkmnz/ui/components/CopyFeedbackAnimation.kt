package com.aistudio.dailyprompts.pkmnz.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Animated icon that bounces and transforms between the copy icon and checkmark
 * when the copy state changes.
 */
@Composable
fun AnimatedCopyIcon(
    isCopied: Boolean,
    modifier: Modifier = Modifier,
    iconSize: Dp = 18.dp,
    normalIcon: ImageVector = Icons.Default.ContentCopy,
    copiedIcon: ImageVector = Icons.Default.Check,
    normalTint: Color = LocalContentColor.current,
    copiedTint: Color = LocalContentColor.current
) {
    val scaleAnim by animateFloatAsState(
        targetValue = if (isCopied) 1.15f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "icon_scale_anim"
    )

    AnimatedContent(
        targetState = isCopied,
        transitionSpec = {
            if (targetState) {
                (scaleIn(
                    initialScale = 0.3f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessMedium
                    )
                ) + fadeIn(animationSpec = tween(180)))
                    .togetherWith(scaleOut(targetScale = 0.5f, animationSpec = tween(120)) + fadeOut(animationSpec = tween(120)))
            } else {
                (scaleIn(
                    initialScale = 0.6f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioNoBouncy,
                        stiffness = Spring.StiffnessMedium
                    )
                ) + fadeIn(animationSpec = tween(180)))
                    .togetherWith(scaleOut(targetScale = 0.6f, animationSpec = tween(120)) + fadeOut(animationSpec = tween(120)))
            }
        },
        modifier = modifier.scale(scaleAnim),
        label = "AnimatedCopyIcon"
    ) { copied ->
        if (copied) {
            Icon(
                imageVector = copiedIcon,
                contentDescription = "Copied",
                tint = copiedTint,
                modifier = Modifier.size(iconSize)
            )
        } else {
            Icon(
                imageVector = normalIcon,
                contentDescription = "Copy",
                tint = normalTint,
                modifier = Modifier.size(iconSize)
            )
        }
    }
}

/**
 * Animated text that slides and fades between the standard copy label
 * and the success feedback label.
 */
@Composable
fun AnimatedCopyText(
    isCopied: Boolean,
    modifier: Modifier = Modifier,
    normalText: String = "Copy Prompt",
    copiedText: String = "Copied to Clipboard!",
    style: TextStyle = MaterialTheme.typography.labelLarge,
    fontWeight: FontWeight = FontWeight.Bold,
    color: Color = LocalContentColor.current
) {
    AnimatedContent(
        targetState = isCopied,
        transitionSpec = {
            (fadeIn(animationSpec = tween(220)) + slideInVertically(
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMedium
                )
            ) { it / 2 })
                .togetherWith(fadeOut(animationSpec = tween(160)) + slideOutVertically(animationSpec = tween(160)) { -it / 2 })
        },
        modifier = modifier,
        label = "AnimatedCopyText"
    ) { copied ->
        Text(
            text = if (copied) copiedText else normalText,
            style = style,
            fontWeight = fontWeight,
            color = color,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/**
 * Standard composite animated content for copy buttons with icon and text.
 */
@Composable
fun AnimatedCopyContent(
    isCopied: Boolean,
    modifier: Modifier = Modifier,
    normalText: String = "Copy Prompt",
    copiedText: String = "Copied to Clipboard!",
    iconSize: Dp = 18.dp,
    spacing: Dp = 8.dp,
    style: TextStyle = MaterialTheme.typography.titleSmall,
    fontWeight: FontWeight = FontWeight.Bold,
    contentColor: Color = LocalContentColor.current
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        AnimatedCopyIcon(
            isCopied = isCopied,
            iconSize = iconSize,
            normalTint = contentColor,
            copiedTint = contentColor
        )
        Spacer(modifier = Modifier.width(spacing))
        AnimatedCopyText(
            isCopied = isCopied,
            normalText = normalText,
            copiedText = copiedText,
            style = style,
            fontWeight = fontWeight,
            color = contentColor
        )
    }
}
