package com.aistudio.dailyprompts.pkmnz.data.remote.ai

/** Central model IDs used by Gemini requests. */
object AIModels {
    // Primary: Gemini 4 Argon, matching the model ID shown in Google AI Studio.
    const val GEMINI_PRIMARY = "gemini-4-argon"
    // Fallback: Gemini 2.5 Flash, used if the primary model is unavailable.
    const val GEMINI_FALLBACK = "gemini-2.5-flash"
    const val OPENAI_DEFAULT = "gpt-4o-mini"

    val GEMINI_MODELS = listOf(GEMINI_PRIMARY, GEMINI_FALLBACK)
}
