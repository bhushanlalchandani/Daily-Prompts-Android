package com.aistudio.dailyprompts.pkmnz

import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIPromptRequest
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIProviderError
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIProviderResult
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.GeminiProvider
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class EndToEndFailoverIntegrationTest {

    private val testRequest = AIPromptRequest(
        topic = "Create an executive morning briefing summary",
        targetAi = "ChatGPT",
        category = "Productivity",
        style = "Executive",
        maxTokens = 200
    )

    @Test
    fun testGeminiProviderWithoutKeyReturnsKeyMissingGracefully() = runBlocking {
        val provider = GeminiProvider(apiKeyProvider = { "" })
        val result = provider.generatePrompt(testRequest)

        assertNotNull(result)
        assertTrue(result is AIProviderResult.Failure)
        val failure = result as AIProviderResult.Failure
        assertTrue(failure.error is AIProviderError.KeyMissing)
        assertEquals("Gemini", failure.error.provider)
    }

    @Test
    fun testGeminiProviderWithDummyKeyFailsGracefullyWithoutCrashing() = runBlocking {
        val provider = GeminiProvider(apiKeyProvider = { "AIzaSyFakeKeyForTestOnly12345" })
        val result = provider.generatePrompt(testRequest)

        assertNotNull(result)
        assertTrue(result is AIProviderResult.Failure)
    }
}
