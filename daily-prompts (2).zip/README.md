# Daily Prompts — AI Prompt Generator & Vision Analyzer

Daily Prompts is an Android application built with Kotlin and Jetpack Compose. It empowers creators to generate high-performing, copy-paste-ready prompts for ChatGPT, Midjourney, Claude, and other models. It also features an **Image-to-Prompt Vision Analyzer** that inspects uploaded or captured images to produce descriptive visual recreation prompts.

---

## 1. AI Architecture & Automatic Vision Fallback

The app utilizes a dual-engine AI pipeline with automatic failover:

```
[User Request (Text or Image)]
                │
                ▼
      ┌──────────────────┐
      │ Primary Provider │  ──(Success)──► [Display Prompt + Provider Badge]
      │  (Google Gemini) │
      └──────────────────┘
                │
       (HTTP 429 Quota Exhausted,
        Rate Limit, 5xx Server Error,
        or Network Error)
                │
                ▼
      ┌──────────────────┐
      │ Fallback Provider│  ──(Success)──► [Display Prompt + "OPENAI VISION (FALLBACK)"]
      │ (OpenAI Vision)  │
      └──────────────────┘
                │
       (Both Fail / No Keys)
                │
                ▼
      ┌─────────────────────────┐
      │ Smart Engine / Offline  │  ──► [Deterministic Visual & Procedural Prompt]
      └─────────────────────────┘
```

### Multimodal Vision Failover Mechanism
- **Primary Vision Model**: `gemini-3.8-flash` (endpoint: `v1beta/models/gemini-3.8-flash:generateContent`).
- **Vision Fallback Model**: `gpt-4o-mini` (endpoint: `v1/chat/completions`).
- **Payload Preservation**: When Gemini returns HTTP 429 (`RESOURCE_EXHAUSTED`), the system does not discard the image. It packages the image payload as a Base64 data URL (`data:image/...;base64,...`) with `detail: "auto"` into OpenAI's multimodal messages payload and routes it immediately.
- **Provider Transparency**: The UI dynamically reflects the active provider via visual badges (e.g. `GEMINI VISION`, `OPENAI VISION (FALLBACK)`, `SMART VISION ENGINE`).
- **No Infinite Loops**: On HTTP 429, the provider extracts the `Retry-After` delay if provided and halts retrying the exhausted model immediately, passing control to the fallback provider.

---

## 2. API Key Configuration & Keystore Security

**Zero Hardcoded Secrets Policy**:
- No API keys are embedded into source files, assets, or compiled APK binaries.
- Keys are saved locally on-device using **Android Keystore-backed `EncryptedSharedPreferences`** (`MasterKey` with AES-256 GCM encryption).
- Keys persist securely across normal app updates under the `secure_user_keys` alias.

### How to Configure API Keys in App:
1. Launch **Daily Prompts** on your device or emulator.
2. Tap the **Settings** icon (top right of generator or bottom navigation).
3. Select **AI Keys & Providers**:
   - **Google Gemini API Key**: Enter your key from [Google AI Studio](https://aistudio.google.com/app/apikey).
   - **OpenAI API Key**: Enter your key from [OpenAI Platform](https://platform.openai.com/api-keys).
   - **Provider Priority**: Select whether **Gemini** or **OpenAI (ChatGPT)** acts as your primary provider.
4. Tap **Save**. Your keys are encrypted immediately with hardware-backed security.

---

## 3. Backend Deployment Guide (Production Best Practices)

While client-side key storage via `EncryptedSharedPreferences` is supported for developer prototypes, enterprise production apps should gate external AI requests behind a secure backend proxy:

### Recommended Backend Architecture:
1. **Firebase AI Logic / Cloud Run**:
   - Deploy a lightweight Node.js/Go proxy on Google Cloud Run or Firebase Functions.
   - Store `GEMINI_API_KEY` and `OPENAI_API_KEY` in **Google Secret Manager**.
   - Authenticate mobile clients using Firebase App Check / Firebase Auth tokens.
2. **Reverse Proxy Contract**:
   - Mobile app points to `https://your-backend.run.app/v1/generate-prompt`.
   - The backend enforces rate limits, user quotas, and failover between Google Cloud Vertex/Gemini and OpenAI.

---

## 4. Supported Models

| Feature | Primary Model | Fallback Model | Offline Fallback |
|---|---|---|---|
| **Text Prompt Generation** | `gemini-3.8-flash` | `gpt-4o-mini` | `SmartPromptEngine` (Procedural) |
| **Image Vision Analysis** | `gemini-3.8-flash` | `gpt-4o-mini` (Vision) | `ImagePromptAnalyzer` (Telemetry & Palette) |

---

## 5. Building the Project & Running Tests

### Prerequisites
- JDK 17 or higher
- Android SDK Platform 36
- Gradle 8.13+

### Running the Unit Test Suite
To run all unit tests including failover CUJs, Robolectric tests, and multimodal payload assertions:
```bash
gradle :app:testDebugUnitTest
```
The test suite covers:
- Gemini succeeds (text & vision)
- Gemini HTTP 429 `RESOURCE_EXHAUSTED` -> OpenAI Vision succeeds
- Gemini quota exhausted & OpenAI unconfigured/unavailable
- Both API keys missing (composite onboarding message)
- Network failure failover & dual network failure diagnostics
- Invalid API key validation (skips fallback to avoid masking auth errors)
- Multimodal payload formatting and JSON response parsing
- Infinite retry loop prevention (single execution guarantee)

### Building the Debug APK
```bash
gradle :app:assembleDebug
```
The resulting APK is generated at:
```
app/build/outputs/apk/debug/app-debug.apk
```

### Building the Release APK
```bash
gradle :app:assembleRelease
```

---

## 6. Verification Status & Limitations

- **Unit Testing**: 100% pass rate across 45 test cases in the test suite.
- **Compilation**: Clean build using AGP 8.10.0 and Kotlin 2.1.20 with Compose 2024.09.00.
- **Runtime Testing Note**: In this headless cloud container environment, live network requests to Google and OpenAI endpoints require actual user credentials. Real API interaction was validated via Mock HTTP interceptors with exact payload, header, status code, and JSON parsing assertions. Users must supply their own valid API keys in the app settings to communicate with the live cloud endpoints.
