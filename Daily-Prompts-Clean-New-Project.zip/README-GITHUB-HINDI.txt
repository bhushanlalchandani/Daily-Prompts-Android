Daily Prompts — revised source project

GitHub mobile steps:
1. Download and extract this ZIP.
2. Upload the folder contents so that `daily-prompts-src` and `.github` are at the repository root.
3. Commit the changes.
4. Open the repository's Actions tab, select “Build Daily Prompts APK”, and run the workflow if it did not start automatically.
5. If the workflow succeeds, open its run and download the artifact named “Daily-Prompts-debug-APK”.

Important: this is source code, not an APK. The Gemini model and repeated-image flow have not yet been compiled or tested on a phone. The API key is not included; enter it inside the app. Do not upload API keys to GitHub.
