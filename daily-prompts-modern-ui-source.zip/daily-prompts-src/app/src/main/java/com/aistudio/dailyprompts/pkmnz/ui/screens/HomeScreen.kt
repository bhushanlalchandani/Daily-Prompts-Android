package com.aistudio.dailyprompts.pkmnz.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GridView
import com.aistudio.dailyprompts.pkmnz.ui.i18n.AppStrings
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppLanguage
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppStrings
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aistudio.dailyprompts.pkmnz.data.model.PromptCategory
import com.aistudio.dailyprompts.pkmnz.ui.components.CategoryArtThumbnail
import com.aistudio.dailyprompts.pkmnz.ui.components.DailyPromptsAvatar
import com.aistudio.dailyprompts.pkmnz.ui.components.SunsetHeroIllustration
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatAllCategoriesBg
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatAllCategoriesIcon
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatCreativityBg
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatCreativityIcon
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatHealthBg
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatHealthIcon
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatMindfulnessBg
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatMindfulnessIcon
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatMotivationBg
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatMotivationIcon
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatProductivityBg
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatProductivityIcon
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatRelationshipsBg
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatRelationshipsIcon
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatSelfCareBg
import com.aistudio.dailyprompts.pkmnz.ui.theme.CatSelfCareIcon
import com.aistudio.dailyprompts.pkmnz.ui.theme.AccentHeartPink
import com.aistudio.dailyprompts.pkmnz.ui.theme.OnWarmYellow
import com.aistudio.dailyprompts.pkmnz.ui.theme.SoftPeach
import com.aistudio.dailyprompts.pkmnz.ui.theme.SoftPink
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmBackground
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardBorder
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardBorderSubtle
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardSurface
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextSecondary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextTertiary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellow
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellowDark
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellowLight
import com.aistudio.dailyprompts.pkmnz.ui.theme.AppTheme
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.AppTab
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.PromptViewModel
import kotlinx.coroutines.launch

data class HomeCategoryShortcut(
    val name: String,
    val emoji: String,
    val bgColor: Color,
    val iconColor: Color,
    val category: PromptCategory?
)

@Composable
fun HomeScreen(
    viewModel: PromptViewModel,
    modifier: Modifier = Modifier
) {
    val dailyFeatured by viewModel.dailyFeaturedPrompt.collectAsStateWithLifecycle()
    val dailyPrompts by viewModel.dailyPrompts.collectAsStateWithLifecycle()
    val favoritePrompts by viewModel.favoritePrompts.collectAsStateWithLifecycle()
    val allPrompts by viewModel.allPrompts.collectAsStateWithLifecycle()
    val recentPrompts by viewModel.recentGeneratedPrompts.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val strings = LocalAppStrings.current
    val currentLanguage = LocalAppLanguage.current

    val categoryShortcuts = remember {
        listOf(
            HomeCategoryShortcut("Girl & Aesthetics", "👧", Color(0xFFFCE4EC), Color(0xFFD81B60), PromptCategory.GIRL),
            HomeCategoryShortcut("Boy & Style", "👦", Color(0xFFE8EAF6), Color(0xFF3949AB), PromptCategory.BOY),
            HomeCategoryShortcut("AI Art", "🎨", CatCreativityBg, CatCreativityIcon, PromptCategory.AI_ART),
            HomeCategoryShortcut("Motivation", "⚡", CatMotivationBg, CatMotivationIcon, PromptCategory.MOTIVATION),
            HomeCategoryShortcut("Self Care", "🌿", CatSelfCareBg, CatSelfCareIcon, PromptCategory.SELF_CARE),
            HomeCategoryShortcut("Productivity", "💻", CatProductivityBg, CatProductivityIcon, PromptCategory.PRODUCTIVITY),
            HomeCategoryShortcut("Creativity", "🎨", CatCreativityBg, CatCreativityIcon, PromptCategory.CREATIVITY),
            HomeCategoryShortcut("Relationships", "❤️", CatRelationshipsBg, CatRelationshipsIcon, PromptCategory.RELATIONSHIPS),
            HomeCategoryShortcut("Mindfulness", "🧘", CatMindfulnessBg, CatMindfulnessIcon, PromptCategory.MINDFULNESS),
            HomeCategoryShortcut("Health", "🏃", CatHealthBg, CatHealthIcon, PromptCategory.HEALTH),
            HomeCategoryShortcut("All Categories", "▦", CatAllCategoriesBg, CatAllCategoriesIcon, null)
        )
    }

    val carouselPrompts = remember(dailyPrompts) {
        if (dailyPrompts.isNotEmpty()) dailyPrompts else listOf(dailyFeatured)
    }
    val pagerState = rememberPagerState(
        initialPage = 0,
        pageCount = { carouselPrompts.size }
    )

    LaunchedEffect(pagerState.currentPage) {
        carouselPrompts.getOrNull(pagerState.currentPage)?.let {
            viewModel.setDailyFeatured(it)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmBackground)
            .testTag("home_screen"),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // 1. Welcoming Header ("Hello 👋", "Ready for a better day?", Profile avatar)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = strings.greetingHello,
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontFamily = FontFamily.Default,
                            fontSize = 27.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = WarmTextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = strings.readyForBetterDay,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 15.sp,
                            color = WarmTextSecondary
                        )
                    )
                }

                // Profile Avatar with click -> Profile tab
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            viewModel.setTab(AppTab.PROFILE)
                        }
                        .testTag("home_profile_avatar_button")
                ) {
                    DailyPromptsAvatar(
                        sizeDp = 48.dp,
                        profile = userProfile
                    )
                }
            }
        }

        // 2. Search Bar ("Search prompts...")
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = {
                        viewModel.setSearchQuery(it)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(elevation = 2.dp, shape = RoundedCornerShape(24.dp), ambientColor = Color(0x1A000000))
                        .testTag("home_search_field"),
                    placeholder = {
                        Text(
                            text = strings.searchPromptsPlaceholder,
                            color = WarmTextTertiary,
                            fontSize = 14.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = WarmTextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    viewModel.setSearchQuery("")
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear search",
                                    tint = WarmTextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = WarmCardSurface,
                        unfocusedContainerColor = WarmCardSurface,
                        focusedBorderColor = WarmYellow,
                        unfocusedBorderColor = WarmCardBorder,
                        focusedTextColor = WarmTextPrimary,
                        unfocusedTextColor = WarmTextPrimary
                    )
                )
            }
        }

        if (searchQuery.isNotBlank()) {
            // Search Results Mode on Home
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Results for \"$searchQuery\" (${allPrompts.size})",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = WarmTextPrimary
                        )
                    )
                    TextButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            viewModel.setSearchQuery("")
                        }
                    ) {
                        Text(
                            text = "Clear",
                            color = WarmYellowDark,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (allPrompts.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 36.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "🔍", fontSize = 40.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "No prompts found",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = WarmTextPrimary,
                                    fontSize = 18.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "No prompts matched \"$searchQuery\". Try a different search term or clear the search.",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = WarmTextSecondary,
                                    fontSize = 14.sp
                                ),
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    viewModel.setSearchQuery("")
                                },
                                shape = RoundedCornerShape(20.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = WarmYellow,
                                    contentColor = OnWarmYellow
                                )
                            ) {
                                Text(
                                    text = strings.clearSearch,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            } else {
                items(allPrompts, key = { it.id }) { prompt ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp)
                            .shadow(elevation = 2.dp, shape = RoundedCornerShape(20.dp), ambientColor = Color(0x14000000))
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                viewModel.openPromptDetail(prompt)
                            }
                            .testTag("home_search_result_${prompt.id}"),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = WarmCardSurface),
                        border = BorderStroke(1.dp, WarmCardBorderSubtle)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(RoundedCornerShape(16.dp))
                            ) {
                                CategoryArtThumbnail(category = prompt.category)
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = WarmYellowLight
                                ) {
                                    Text(
                                        text = prompt.category,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = WarmYellowDark,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 10.sp
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = prompt.title,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = WarmTextPrimary
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = prompt.promptText,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 12.sp,
                                        color = WarmTextSecondary,
                                        lineHeight = 16.sp
                                    ),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    viewModel.toggleFavorite(prompt.id, prompt.isFavorite)
                                }
                            ) {
                                Icon(
                                    imageVector = if (prompt.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                                    contentDescription = "Favorite",
                                    tint = if (prompt.isFavorite) AccentHeartPink else WarmTextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // 3. Large "Today's Prompt" Horizontal Pager Carousel
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("todays_prompt_carousel")
                ) {
                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("todays_prompt_pager"),
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        pageSpacing = 14.dp,
                        userScrollEnabled = true
                    ) { page ->
                        val prompt = carouselPrompts.getOrElse(page) { dailyFeatured }
                        val isFav = favoritePrompts.any { it.id == prompt.id || (prompt.id == 0L && it.title == prompt.title) }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .shadow(elevation = 4.dp, shape = RoundedCornerShape(24.dp), ambientColor = Color(0x14000000))
                                .testTag(if (page == 0) "featured_prompt_card" else "featured_prompt_card_$page"),
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = WarmCardSurface),
                            border = BorderStroke(1.dp, WarmCardBorderSubtle)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                // Header Inside Card: Tag & Badge
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 18.dp, vertical = 14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = WarmYellowLight
                                    ) {
                                        Text(
                                            text = strings.todayFeatured,
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                color = WarmYellowDark,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            ),
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                        )
                                    }

                                    // Favorite Icon
                                    IconButton(
                                        onClick = {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            viewModel.toggleFavoritePrompt(prompt)
                                        },
                                        modifier = Modifier
                                            .size(36.dp)
                                            .testTag("favorite_button_$page")
                                    ) {
                                        Icon(
                                            imageVector = if (isFav) Icons.Filled.Favorite else Icons.Outlined.BookmarkBorder,
                                            contentDescription = if (isFav) "Favorited" else "Save",
                                            tint = if (isFav) Color(0xFFFF4D6D) else WarmTextSecondary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                // Beautiful Illustration area (Woman in yellow dress facing mountain sunset)
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(160.dp)
                                        .padding(horizontal = 18.dp)
                                        .clip(RoundedCornerShape(18.dp))
                                ) {
                                    SunsetHeroIllustration()
                                }

                                // Prompt Text
                                Text(
                                    text = "“${prompt.promptText}”",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontFamily = FontFamily.Serif,
                                        fontSize = 18.sp,
                                        lineHeight = 26.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = WarmTextPrimary
                                    ),
                                    maxLines = 3,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp)
                                )

                                // Action Row: Theme-colored "View Prompt" button + Roll button
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(start = 18.dp, end = 18.dp, bottom = 18.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Button(
                                        onClick = {
                                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                            viewModel.openPromptDetail(prompt)
                                        },
                                        shape = RoundedCornerShape(20.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = WarmYellow,
                                            contentColor = OnWarmYellow
                                        ),
                                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
                                        modifier = Modifier.testTag("view_prompt_button")
                                    ) {
                                        Text(
                                            text = strings.tapToExplore,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }

                                    // Secondary roll new prompt button
                                    IconButton(
                                        onClick = {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            viewModel.rollFreshPrompts()
                                            coroutineScope.launch {
                                                pagerState.animateScrollToPage(0)
                                            }
                                        },
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(WarmYellowLight, shape = CircleShape)
                                            .testTag("roll_prompt_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Refresh,
                                            contentDescription = "Roll new daily prompt",
                                            tint = WarmYellowDark,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Dot Carousel Indicators
                    if (carouselPrompts.size > 1) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 10.dp)
                                .testTag("carousel_page_indicator"),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            carouselPrompts.indices.forEach { index ->
                                val isSelected = pagerState.currentPage == index
                                val dotWidth by animateDpAsState(
                                    targetValue = if (isSelected) 18.dp else 6.dp,
                                    label = "dotWidth_$index"
                                )
                                val dotColor by animateColorAsState(
                                    targetValue = if (isSelected) WarmYellowDark else (if (AppTheme.colors.isDark) Color(0xFF443B33) else Color(0xFFE2D8CC)),
                                    label = "dotColor_$index"
                                )

                                Box(
                                    modifier = Modifier
                                        .height(6.dp)
                                        .width(dotWidth)
                                        .background(dotColor, shape = CircleShape)
                                        .clickable {
                                            coroutineScope.launch {
                                                pagerState.animateScrollToPage(index)
                                            }
                                        }
                                        .testTag("carousel_dot_$index")
                                )

                                if (index < carouselPrompts.size - 1) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                }
                            }
                        }
                    }
                }
            }

        // 4. Category Shortcuts in Rounded Circular Icons
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.categoriesTitle,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = WarmTextPrimary
                        )
                    )
                    Text(
                        text = strings.seeAll,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = WarmYellowDark,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        ),
                        modifier = Modifier
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                viewModel.openCategories()
                            }
                            .padding(4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Horizontal scrollable category icons matching the reference design with no clipping
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(categoryShortcuts) { item ->
                        val translatedCategoryName = AppStrings.translate(item.name, currentLanguage)
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .width(74.dp)
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null
                                ) {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    if (item.category == null) {
                                        viewModel.openCategories()
                                    } else {
                                        viewModel.setCategory(item.category)
                                        viewModel.setTab(AppTab.EXPLORE)
                                    }
                                }
                                .padding(vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .shadow(elevation = 2.dp, shape = CircleShape, ambientColor = Color(0x14000000))
                                    .background(item.bgColor, shape = CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                if (item.category == null) {
                                    Icon(
                                        imageVector = Icons.Default.GridView,
                                        contentDescription = translatedCategoryName,
                                        tint = item.iconColor,
                                        modifier = Modifier.size(22.dp)
                                    )
                                } else {
                                    Text(
                                        text = item.emoji,
                                        fontSize = 22.sp
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = translatedCategoryName,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = WarmTextPrimary
                                ),
                                textAlign = TextAlign.Center,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // 5. Quick Action Banners (Preserving AI Generator & Scratchpad tools cleanly!)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // AI Prompt Studio Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            viewModel.setGeneratorMode(com.aistudio.dailyprompts.pkmnz.ui.viewmodel.GeneratorMode.TEXT)
                            viewModel.setTab(AppTab.GENERATOR)
                        },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = SoftPeach),
                    border = BorderStroke(1.dp, WarmCardBorderSubtle)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(WarmYellow, shape = CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "AI Generator",
                                tint = OnWarmYellow,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "✨ ${strings.createPrompt}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = WarmTextPrimary
                            )
                            Text(
                                text = "Generate personalized prompts for writing, art & wellness",
                                fontSize = 12.sp,
                                color = WarmTextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                // Image to Prompt Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            viewModel.setGeneratorMode(com.aistudio.dailyprompts.pkmnz.ui.viewmodel.GeneratorMode.IMAGE)
                            viewModel.setTab(AppTab.GENERATOR)
                        }
                        .testTag("home_image_to_prompt_card"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE0F2FE)),
                    border = BorderStroke(1.dp, Color(0xFFBAE6FD))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(Color(0xFF0284C7), shape = CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Image,
                                contentDescription = "Image to Prompt",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "🖼️ ${strings.tabImageToPrompt}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = WarmTextPrimary
                            )
                            Text(
                                text = "Upload photos to generate rich, factual descriptive prompts",
                                fontSize = 12.sp,
                                color = WarmTextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                // Scratchpad Clipboard Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            viewModel.setTab(AppTab.SCRATCHPAD)
                        },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF3E8FF)),
                    border = BorderStroke(1.dp, Color(0xFFE9D5FF))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(Color(0xFF8B5CF6), shape = CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentPaste,
                                contentDescription = strings.scratchpadTitle,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "📋 ${strings.scratchpadTitle}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = WarmTextPrimary
                            )
                            Text(
                                text = "Paste, tweak and copy prompts directly with haptic feedback",
                                fontSize = 12.sp,
                                color = WarmTextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                // Recent History Offline Cache Banner (visible when user has generated prompts)
                if (recentPrompts.isNotEmpty()) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                viewModel.setTab(AppTab.GENERATOR)
                            }
                            .testTag("home_recent_history_card"),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFDCFCE7)),
                        border = BorderStroke(1.dp, Color(0xFFBBF7D0))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .background(Color(0xFF16A34A), shape = CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CloudDone,
                                    contentDescription = strings.recentGenerations,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "📁 ${strings.recentGenerations}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = WarmTextPrimary
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = Color(0xFF16A34A).copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = "${recentPrompts.size} Cached Offline",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF15803D),
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Latest: \"${recentPrompts.first().topic}\"",
                                    fontSize = 12.sp,
                                    color = WarmTextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
        }
    }
}
