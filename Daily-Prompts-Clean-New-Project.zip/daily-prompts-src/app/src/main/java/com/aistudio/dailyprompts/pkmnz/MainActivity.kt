package com.aistudio.dailyprompts.pkmnz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.aistudio.dailyprompts.pkmnz.data.cover.WallpaperType
import com.aistudio.dailyprompts.pkmnz.data.local.ApiKeyManager
import com.aistudio.dailyprompts.pkmnz.data.local.PromptDatabase
import com.aistudio.dailyprompts.pkmnz.data.remote.GeminiPromptService
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIProviderManager
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.GeminiProvider
import com.aistudio.dailyprompts.pkmnz.data.repository.PromptRepository
import com.aistudio.dailyprompts.pkmnz.ui.components.WallpaperBackground
import com.aistudio.dailyprompts.pkmnz.ui.i18n.AppStrings
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppLanguage
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppStrings
import com.aistudio.dailyprompts.pkmnz.ui.screens.ApiKeySettingsScreen
import com.aistudio.dailyprompts.pkmnz.ui.screens.CategoriesScreen
import com.aistudio.dailyprompts.pkmnz.ui.screens.ClipboardScratchpadScreen
import com.aistudio.dailyprompts.pkmnz.ui.screens.EditProfileScreen
import com.aistudio.dailyprompts.pkmnz.ui.screens.ExploreScreen
import com.aistudio.dailyprompts.pkmnz.ui.screens.FavoritesScreen
import com.aistudio.dailyprompts.pkmnz.ui.screens.HomeScreen
import com.aistudio.dailyprompts.pkmnz.ui.screens.ProfileScreen
import com.aistudio.dailyprompts.pkmnz.ui.screens.PromptDetailScreen
import com.aistudio.dailyprompts.pkmnz.ui.screens.PromptGeneratorScreen
import com.aistudio.dailyprompts.pkmnz.ui.screens.SettingsScreen
import com.aistudio.dailyprompts.pkmnz.ui.theme.DailyPromptsTheme
import com.aistudio.dailyprompts.pkmnz.ui.theme.OnWarmYellow
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmBackground
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardBorderSubtle
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardSurface
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextSecondary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellow
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellowDark
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.AppTab
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.PromptViewModel
import kotlinx.coroutines.flow.collectLatest
import java.io.File

class MainActivity : ComponentActivity() {

    private val viewModel: PromptViewModel by viewModels {
        val db = PromptDatabase.getInstance(applicationContext)
        val apiKeyManager = ApiKeyManager(applicationContext)
        val geminiService = GeminiPromptService(
            aiProviderManager = AIProviderManager(
                geminiProvider = GeminiProvider(
                    apiKeyProvider = { apiKeyManager.getGeminiApiKey() }
                ),
                // Keep image/text prompt generation on Gemini. Do not silently route
                // requests to OpenAI, which can surface unrelated OpenAI quota errors.
                openAIProvider = null
            )
        )
        val repository = PromptRepository(db.promptDao(), geminiService)
        PromptViewModel.Factory(repository, applicationContext, apiKeyManager)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val darkMode by viewModel.darkMode.collectAsStateWithLifecycle()
            val selectedTheme by viewModel.selectedTheme.collectAsStateWithLifecycle()
            val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
            val appStrings = remember(selectedLanguage) { AppStrings.forLanguage(selectedLanguage) }

            CompositionLocalProvider(
                LocalAppStrings provides appStrings,
                LocalAppLanguage provides selectedLanguage
            ) {
                DailyPromptsTheme(
                    darkTheme = darkMode,
                    themeName = selectedTheme
                ) {
                    val snackbarHostState = remember { SnackbarHostState() }
                    val haptic = LocalHapticFeedback.current
                    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
                    val recentlyCopiedId by viewModel.recentlyCopiedId.collectAsStateWithLifecycle()
                    val wallpaperState by viewModel.wallpaperState.collectAsStateWithLifecycle()
                    val isWallpaperActive = (wallpaperState.type != WallpaperType.DEFAULT)
                    val isRootTab = currentTab in listOf(
                        AppTab.HOME,
                        AppTab.EXPLORE,
                        AppTab.FAVORITES,
                        AppTab.PROFILE
                    )

                    BackHandler(enabled = currentTab != AppTab.HOME || viewModel.canNavigateBack()) {
                        if (!viewModel.navigateBack()) {
                            if (currentTab != AppTab.HOME) {
                                viewModel.setTab(AppTab.HOME)
                            }
                        }
                    }

                    // Collect user feedback messages
                    LaunchedEffect(Unit) {
                        viewModel.userMessage.collectLatest { msg ->
                            snackbarHostState.showSnackbar(message = msg)
                        }
                    }

                    Box(
                        modifier = Modifier.fillMaxSize()
                    ) {
                        WallpaperBackground(
                            wallpaperState = wallpaperState,
                            modifier = Modifier.fillMaxSize()
                        )

                        Scaffold(
                            modifier = Modifier.fillMaxSize(),
                            containerColor = Color.Transparent,
                            contentWindowInsets = WindowInsets.safeDrawing,
                            snackbarHost = { SnackbarHost(snackbarHostState) },
                            bottomBar = {
                                if (isRootTab) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(WarmCardSurface)
                                            .navigationBarsPadding()
                                    ) {
                                        HorizontalDivider(
                                            color = WarmCardBorderSubtle,
                                            thickness = 1.dp
                                        )
                                        NavigationBar(
                                            modifier = Modifier.testTag("main_navigation_bar"),
                                            containerColor = WarmCardSurface,
                                            tonalElevation = 0.dp,
                                            windowInsets = WindowInsets(0, 0, 0, 0)
                                        ) {
                                            // 1. Home
                                            NavigationBarItem(
                                                selected = (currentTab == AppTab.HOME),
                                                alwaysShowLabel = true,
                                                onClick = {
                                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                    viewModel.setTab(AppTab.HOME)
                                                },
                                                icon = {
                                                    Icon(
                                                        imageVector = if (currentTab == AppTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                                                        contentDescription = appStrings.navHome
                                                    )
                                                },
                                                label = {
                                                    Text(
                                                        appStrings.navHome,
                                                        fontWeight = if (currentTab == AppTab.HOME) FontWeight.Bold else FontWeight.Normal,
                                                        fontSize = 11.sp
                                                    )
                                                },
                                                colors = NavigationBarItemDefaults.colors(
                                                    selectedIconColor = OnWarmYellow,
                                                    selectedTextColor = WarmYellowDark,
                                                    unselectedIconColor = WarmTextSecondary,
                                                    unselectedTextColor = WarmTextSecondary,
                                                    indicatorColor = WarmYellow
                                                ),
                                                modifier = Modifier.testTag("nav_tab_home")
                                            )

                                            // 2. Explore
                                            NavigationBarItem(
                                                selected = (currentTab == AppTab.EXPLORE),
                                                alwaysShowLabel = true,
                                                onClick = {
                                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                    viewModel.setTab(AppTab.EXPLORE)
                                                },
                                                icon = {
                                                    Icon(
                                                        imageVector = if (currentTab == AppTab.EXPLORE) Icons.Filled.Search else Icons.Outlined.Search,
                                                        contentDescription = appStrings.navExplore
                                                    )
                                                },
                                                label = {
                                                    Text(
                                                        appStrings.navExplore,
                                                        fontWeight = if (currentTab == AppTab.EXPLORE) FontWeight.Bold else FontWeight.Normal,
                                                        fontSize = 11.sp
                                                    )
                                                },
                                                colors = NavigationBarItemDefaults.colors(
                                                    selectedIconColor = OnWarmYellow,
                                                    selectedTextColor = WarmYellowDark,
                                                    unselectedIconColor = WarmTextSecondary,
                                                    unselectedTextColor = WarmTextSecondary,
                                                    indicatorColor = WarmYellow
                                                ),
                                                modifier = Modifier.testTag("nav_tab_explore")
                                            )

                                            // 3. Favorites
                                            NavigationBarItem(
                                                selected = (currentTab == AppTab.FAVORITES),
                                                alwaysShowLabel = true,
                                                onClick = {
                                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                    viewModel.setTab(AppTab.FAVORITES)
                                                },
                                                icon = {
                                                    Icon(
                                                        imageVector = if (currentTab == AppTab.FAVORITES) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                                                        contentDescription = appStrings.navFavorites
                                                    )
                                                },
                                                label = {
                                                    Text(
                                                        appStrings.navFavorites,
                                                        fontWeight = if (currentTab == AppTab.FAVORITES) FontWeight.Bold else FontWeight.Normal,
                                                        fontSize = 11.sp
                                                    )
                                                },
                                                colors = NavigationBarItemDefaults.colors(
                                                    selectedIconColor = OnWarmYellow,
                                                    selectedTextColor = WarmYellowDark,
                                                    unselectedIconColor = WarmTextSecondary,
                                                    unselectedTextColor = WarmTextSecondary,
                                                    indicatorColor = WarmYellow
                                                ),
                                                modifier = Modifier.testTag("nav_tab_favorites")
                                            )

                                            // 4. Profile
                                            NavigationBarItem(
                                                selected = (currentTab == AppTab.PROFILE),
                                                alwaysShowLabel = true,
                                                onClick = {
                                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                    viewModel.setTab(AppTab.PROFILE)
                                                },
                                                icon = {
                                                    Icon(
                                                        imageVector = if (currentTab == AppTab.PROFILE) Icons.Filled.Person else Icons.Outlined.Person,
                                                        contentDescription = appStrings.navProfile
                                                    )
                                                },
                                                label = {
                                                    Text(
                                                        appStrings.navProfile,
                                                        fontWeight = if (currentTab == AppTab.PROFILE) FontWeight.Bold else FontWeight.Normal,
                                                        fontSize = 11.sp
                                                    )
                                                },
                                                colors = NavigationBarItemDefaults.colors(
                                                    selectedIconColor = OnWarmYellow,
                                                    selectedTextColor = WarmYellowDark,
                                                    unselectedIconColor = WarmTextSecondary,
                                                    unselectedTextColor = WarmTextSecondary,
                                                    indicatorColor = WarmYellow
                                                ),
                                                modifier = Modifier.testTag("nav_tab_profile")
                                            )
                                        }
                                    }
                                }
                            }
                        ) { innerPadding ->
                        AnimatedContent(
                            targetState = currentTab,
                            transitionSpec = { fadeIn() togetherWith fadeOut() },
                            label = "tabTransition",
                            modifier = Modifier.padding(innerPadding)
                        ) { tab ->
                            when (tab) {
                                AppTab.HOME -> HomeScreen(
                                    viewModel = viewModel
                                )
                                AppTab.EXPLORE -> ExploreScreen(
                                    viewModel = viewModel
                                )
                                AppTab.FAVORITES -> FavoritesScreen(
                                    viewModel = viewModel
                                )
                                AppTab.PROFILE -> ProfileScreen(
                                    viewModel = viewModel
                                )
                                AppTab.PROMPT_DETAIL -> PromptDetailScreen(
                                    viewModel = viewModel,
                                    onBack = { viewModel.navigateBack() }
                                )
                                AppTab.CATEGORIES -> CategoriesScreen(
                                    viewModel = viewModel,
                                    onBack = { viewModel.navigateBack() }
                                )
                                AppTab.SETTINGS -> SettingsScreen(
                                    viewModel = viewModel,
                                    onBack = { viewModel.navigateBack() }
                                )
                                AppTab.EDIT_PROFILE -> EditProfileScreen(
                                    viewModel = viewModel,
                                    onBack = { viewModel.navigateBack() }
                                )
                                AppTab.GENERATOR -> PromptGeneratorScreen(
                                    viewModel = viewModel,
                                    onBack = { viewModel.navigateBack() },
                                    onNavigateToScratchpad = { viewModel.setTab(AppTab.SCRATCHPAD) }
                                )
                                AppTab.SCRATCHPAD -> ClipboardScratchpadScreen(
                                    viewModel = viewModel,
                                    onBack = { viewModel.navigateBack() }
                                )
                                AppTab.API_KEY_SETTINGS -> ApiKeySettingsScreen(
                                    viewModel = viewModel,
                                    onBack = { viewModel.navigateBack() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
}
