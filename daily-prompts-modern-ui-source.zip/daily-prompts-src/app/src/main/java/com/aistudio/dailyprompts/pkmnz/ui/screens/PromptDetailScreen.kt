package com.aistudio.dailyprompts.pkmnz.ui.screens

import android.content.Context
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aistudio.dailyprompts.pkmnz.data.local.PromptEntity
import com.aistudio.dailyprompts.pkmnz.ui.components.CategoryArtThumbnail
import com.aistudio.dailyprompts.pkmnz.ui.components.SunsetHeroIllustration
import com.aistudio.dailyprompts.pkmnz.ui.theme.AccentHeartPink
import com.aistudio.dailyprompts.pkmnz.ui.theme.OnWarmYellow
import com.aistudio.dailyprompts.pkmnz.ui.theme.SoftPeach
import com.aistudio.dailyprompts.pkmnz.ui.theme.SoftPink
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmBackground
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardBorder
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardBorderSubtle
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardSurface
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextSecondary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextTertiary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellow
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellowDark
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellowLight
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.AppTab
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.PromptViewModel
import com.aistudio.dailyprompts.pkmnz.ui.i18n.AppStrings
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppLanguage
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppStrings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PromptDetailScreen(
    viewModel: PromptViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val currentLanguage = LocalAppLanguage.current
    val dailyFeatured by viewModel.dailyFeaturedPrompt.collectAsStateWithLifecycle()
    val selectedDetail by viewModel.selectedPromptForDetail.collectAsStateWithLifecycle()
    val prompt: PromptEntity = selectedDetail ?: dailyFeatured

    val completedIds by viewModel.completedPromptIds.collectAsStateWithLifecycle()
    val isCompleted = prompt.id in completedIds

    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current

    val currentDateStr = remember {
        SimpleDateFormat("d MMM yyyy", Locale.US).format(Date())
    }

    // Contextual "Why This Matters" explanation
    val whyThisMatters = remember(prompt.id) {
        when {
            prompt.category.contains("Motivation", ignoreCase = true) ->
                "Small steps create big changes. By taking action today, you build momentum toward a happier and more fulfilled life."
            prompt.category.contains("Self Care", ignoreCase = true) ->
                "Self-care is not selfish—it is foundational. Pausing to honor your well-being replenishes your energy and peace of mind."
            prompt.category.contains("Productivity", ignoreCase = true) ->
                "True productivity is not about doing more; it is about focusing deeply on what genuinely moves the needle."
            prompt.category.contains("Creativity", ignoreCase = true) ->
                "Creativity thrives in dedicated space. Giving yourself permission to explore ideas unlocks unexpected breakthroughs."
            prompt.category.contains("Relationship", ignoreCase = true) ->
                "Genuine human connections are built on small, authentic gestures of empathy, gratitude, and attentive listening."
            prompt.category.contains("Mindful", ignoreCase = true) ->
                "Being fully present in this current moment eases anxious thoughts and grounds you in calm awareness."
            prompt.category.contains("Health", ignoreCase = true) ->
                "Your body carries you through every moment. Small, mindful health choices compound into lasting vitality."
            else ->
                "Small steps create big changes. By taking action today, you build momentum toward a happier and more fulfilled life."
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WarmBackground)
            .testTag("prompt_detail_screen")
    ) {
        // 1. Top Bar: Back, Tag, Favorite, Share
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onBack()
                },
                modifier = Modifier.testTag("prompt_detail_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = strings.back,
                    tint = WarmTextPrimary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = WarmYellowLight
            ) {
                Text(
                    text = if (prompt.isDaily) strings.todayFeatured else strings.detailTitle,
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = WarmYellowDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    ),
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        viewModel.toggleFavorite(prompt.id, prompt.isFavorite)
                    },
                    modifier = Modifier.testTag("prompt_detail_favorite_button")
                ) {
                    Icon(
                        imageVector = if (prompt.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = strings.navFavorites,
                        tint = if (prompt.isFavorite) AccentHeartPink else WarmTextPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                }

                IconButton(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        viewModel.sharePrompt(context, prompt.promptText, prompt.title)
                    },
                    modifier = Modifier.testTag("prompt_detail_share_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Share,
                        contentDescription = strings.share,
                        tint = WarmTextPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }

        // 2. Scrollable Body
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Large Beautiful Prompt Text
            Text(
                text = "“${prompt.promptText}”",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontFamily = FontFamily.Serif,
                    fontSize = 24.sp,
                    lineHeight = 34.sp,
                    fontWeight = FontWeight.Bold,
                    color = WarmTextPrimary
                ),
                textAlign = TextAlign.Start,
                modifier = Modifier.padding(top = 4.dp)
            )

            // Date Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 2.dp)
            ) {
                Text(
                    text = "📅 $currentDateStr",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 13.sp,
                        color = WarmTextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                )
                Spacer(modifier = Modifier.width(12.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = WarmYellowLight
                ) {
                    Text(
                        text = AppStrings.translate(prompt.category, currentLanguage),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = WarmYellowDark,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp
                        ),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            // Beautiful Full-Width Image
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .shadow(elevation = 4.dp, shape = RoundedCornerShape(22.dp), ambientColor = Color(0x14000000))
                    .clip(RoundedCornerShape(22.dp))
            ) {
                if (prompt.category.contains("Motivation", ignoreCase = true) || prompt.isDaily) {
                    SunsetHeroIllustration()
                } else {
                    CategoryArtThumbnail(category = prompt.category)
                }
            }

            // "Why This Matters?" Explanation Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = WarmYellowLight),
                border = BorderStroke(1.dp, WarmCardBorderSubtle)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = strings.whyThisMattersTitle,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = WarmYellowDark
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = whyThisMatters,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 14.sp,
                            lineHeight = 22.sp,
                            color = WarmTextPrimary
                        )
                    )
                }
            }

            // Yellow "Mark as Completed ✓" Button
            val completedButtonBg by animateColorAsState(
                targetValue = if (isCompleted) Color(0xFFDCFCE7) else WarmYellow,
                label = "completed_btn_bg"
            )
            val completedButtonText by animateColorAsState(
                targetValue = if (isCompleted) Color(0xFF15803D) else OnWarmYellow,
                label = "completed_btn_text"
            )

            Button(
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    viewModel.togglePromptCompleted(prompt.id)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .shadow(elevation = 2.dp, shape = RoundedCornerShape(24.dp), ambientColor = Color(0x1A000000))
                    .testTag("mark_completed_button"),
                shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = completedButtonBg,
                    contentColor = completedButtonText
                )
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    if (isCompleted) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = strings.completed,
                            tint = completedButtonText,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = strings.completed,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    } else {
                        Text(
                            text = strings.markAsCompleted,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
        }

        // 3. Action Row at Bottom: Save, Share, Next Prompt
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding(),
            color = WarmCardSurface,
            shadowElevation = 8.dp,
            border = BorderStroke(1.dp, WarmCardBorderSubtle)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Save
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            viewModel.toggleFavorite(prompt.id, prompt.isFavorite)
                        }
                        .padding(8.dp)
                        .testTag("detail_save_action")
                ) {
                    Icon(
                        imageVector = if (prompt.isFavorite) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                        contentDescription = if (prompt.isFavorite) strings.saved else strings.save,
                        tint = if (prompt.isFavorite) Color(0xFFD97706) else WarmTextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (prompt.isFavorite) strings.saved else strings.save,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = WarmTextSecondary
                        )
                    )
                }

                // Share
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            viewModel.sharePrompt(context, prompt.promptText, prompt.title)
                        }
                        .padding(8.dp)
                        .testTag("detail_share_action")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Share,
                        contentDescription = strings.share,
                        tint = WarmTextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = strings.share,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = WarmTextSecondary
                        )
                    )
                }

                // Next Prompt
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            viewModel.nextPromptDetail()
                        }
                        .padding(8.dp)
                        .testTag("detail_next_action")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = strings.next,
                        tint = WarmTextPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = strings.next,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = WarmTextPrimary
                        )
                    )
                }
            }
        }
    }
}
