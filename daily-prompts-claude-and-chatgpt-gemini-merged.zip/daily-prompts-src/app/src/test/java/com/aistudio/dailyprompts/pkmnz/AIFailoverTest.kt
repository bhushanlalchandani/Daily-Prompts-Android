package com.aistudio.dailyprompts.pkmnz

import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIModels
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIPromptRequest
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIProvider
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIProviderError
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIProviderManager
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIProviderResult
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AIFailoverTest {

    private class MockGeminiProvider(
        var resultToReturn: AIProviderResult
    ) : AIProvider {
        override val name: String = "Gemini"
        var callCount = 0
        var lastReceivedRequest: AIPromptRequest? = null

        override suspend fun generatePrompt(request: AIPromptRequest): AIProviderResult {
            callCount++
            lastReceivedRequest = request
            return resultToReturn
        }
    }

    private val sampleRequest = AIPromptRequest(
        topic = "Portrait of a cyberpunk boy in rain",
        targetAi = "Midjourney",
        category = "Boy",
        style = "Cinematic",
        dislikedTypes = listOf("anime", "sketch"),
        systemPrompt = "Custom System Instruction",
        temperature = 0.8,
        maxTokens = 1200
    )

    @Test
    fun testGeminiGeneratesPromptSuccessfully() = runBlocking {
        val mockGemini = MockGeminiProvider(
            AIProviderResult.Success("Gemini generated prompt", "Gemini")
        )
        val manager = AIProviderManager(geminiProvider = mockGemini)
        val result = manager.generatePrompt(sampleRequest)

        assertTrue(result is AIProviderResult.Success)
        val success = result as AIProviderResult.Success
        assertEquals("Gemini generated prompt", success.text)
        assertEquals("Gemini", success.providerName)
        assertEquals(1, mockGemini.callCount)
    }

    @Test
    fun testGeminiMissingKeyErrorHandling() = runBlocking {
        val mockGemini = MockGeminiProvider(
            AIProviderResult.Failure(AIProviderError.KeyMissing("Gemini", "No key set"))
        )
        val manager = AIProviderManager(geminiProvider = mockGemini)
        val result = manager.generatePrompt(sampleRequest)

        assertTrue(result is AIProviderResult.Failure)
        val failure = result as AIProviderResult.Failure
        assertTrue(failure.error is AIProviderError.KeyMissing)
        assertFalse(failure.error.isQuotaOrRateLimit())
    }

    @Test
    fun testGeminiQuotaExhaustedErrorHandling() = runBlocking {
        val mockGemini = MockGeminiProvider(
            AIProviderResult.Failure(AIProviderError.QuotaExhausted("Gemini", "Quota exceeded"))
        )
        val manager = AIProviderManager(geminiProvider = mockGemini)
        val result = manager.generatePrompt(sampleRequest)

        assertTrue(result is AIProviderResult.Failure)
        val failure = result as AIProviderResult.Failure
        assertTrue(failure.error is AIProviderError.QuotaExhausted)
        assertTrue(failure.error.isQuotaOrRateLimit())
    }

    @Test
    fun testModelConstantsIntegrity() {
        assertEquals("gemini-3.8-flash", AIModels.GEMINI_PRIMARY)
        assertEquals("gemini-3.5-flash-lite", AIModels.GEMINI_FALLBACK)
        assertEquals("gpt-4o-mini", AIModels.OPENAI_DEFAULT)
        assertEquals(listOf("gemini-3.8-flash", "gemini-3.5-flash-lite"), AIModels.GEMINI_MODELS)
        assertFalse(AIModels.GEMINI_MODELS.contains("gemini-1.5-flash"))
    }

    @Test
    fun testGeminiQuotaExhaustedFailsOverToOpenAISuccessfully() = runBlocking {
        val mockGemini = MockGeminiProvider(
            AIProviderResult.Failure(AIProviderError.QuotaExhausted("Gemini", "Gemini 429 quota exhausted"))
        )
        val mockOpenAI = MockGeminiProvider(
            AIProviderResult.Success("OpenAI generated prompt", "OpenAI")
        )

        val manager = AIProviderManager(
            geminiProvider = mockGemini,
            openAIProvider = mockOpenAI
        )

        val result = manager.generatePrompt(sampleRequest)

        assertTrue(result is AIProviderResult.Success)
        val success = result as AIProviderResult.Success
        assertEquals("OpenAI generated prompt", success.text)
        assertEquals("OpenAI", success.providerName)
        assertEquals(1, mockGemini.callCount)
        assertEquals(1, mockOpenAI.callCount)
    }

    @Test
    fun testGeminiInvalidKeyDoesNotFailOverToOpenAI() = runBlocking {
        val mockGemini = MockGeminiProvider(
            AIProviderResult.Failure(AIProviderError.InvalidApiKey("Gemini", "Invalid Gemini key"))
        )
        val mockOpenAI = MockGeminiProvider(
            AIProviderResult.Success("Should not be called", "OpenAI")
        )

        val manager = AIProviderManager(
            geminiProvider = mockGemini,
            openAIProvider = mockOpenAI
        )

        val result = manager.generatePrompt(sampleRequest)

        assertTrue(result is AIProviderResult.Failure)
        val failure = result as AIProviderResult.Failure
        assertTrue(failure.error is AIProviderError.InvalidApiKey)
        assertEquals(1, mockGemini.callCount)
        assertEquals(0, mockOpenAI.callCount) // Must NOT attempt failover for bad key
    }

    @Test
    fun testGeminiPolicyRefusalDoesNotFailOverToOpenAI() = runBlocking {
        val mockGemini = MockGeminiProvider(
            AIProviderResult.Failure(AIProviderError.PolicyRefusal("Gemini", "Content violation"))
        )
        val mockOpenAI = MockGeminiProvider(
            AIProviderResult.Success("Should not be called", "OpenAI")
        )

        val manager = AIProviderManager(
            geminiProvider = mockGemini,
            openAIProvider = mockOpenAI
        )

        val result = manager.generatePrompt(sampleRequest)

        assertTrue(result is AIProviderResult.Failure)
        val failure = result as AIProviderResult.Failure
        assertTrue(failure.error is AIProviderError.PolicyRefusal)
        assertEquals(1, mockGemini.callCount)
        assertEquals(0, mockOpenAI.callCount) // Must NOT attempt failover for policy refusal
    }

    @Test
    fun testBothProvidersFailReturnsCleanFailure() = runBlocking {
        val mockGemini = MockGeminiProvider(
            AIProviderResult.Failure(AIProviderError.QuotaExhausted("Gemini", "Gemini 429"))
        )
        val mockOpenAI = MockGeminiProvider(
            AIProviderResult.Failure(AIProviderError.RateLimited("OpenAI", "OpenAI 429"))
        )

        val manager = AIProviderManager(
            geminiProvider = mockGemini,
            openAIProvider = mockOpenAI
        )

        val result = manager.generatePrompt(sampleRequest)

        assertTrue(result is AIProviderResult.Failure)
        val failure = result as AIProviderResult.Failure
        assertTrue(failure.error.isQuotaOrRateLimit())
        assertEquals(1, mockGemini.callCount)
        assertEquals(1, mockOpenAI.callCount)
    }
}
