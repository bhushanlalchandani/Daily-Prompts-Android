package com.aistudio.dailyprompts.pkmnz.data.repository

import com.aistudio.dailyprompts.pkmnz.data.generator.SmartPromptEngine
import com.aistudio.dailyprompts.pkmnz.data.local.DislikedTypeEntity
import com.aistudio.dailyprompts.pkmnz.data.local.GeneratedPromptEntity
import com.aistudio.dailyprompts.pkmnz.data.local.PromptDao
import com.aistudio.dailyprompts.pkmnz.data.local.PromptEntity
import com.aistudio.dailyprompts.pkmnz.data.model.PromptCategory
import com.aistudio.dailyprompts.pkmnz.data.remote.GeminiPromptService
import com.aistudio.dailyprompts.pkmnz.data.remote.PromptAiService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

data class PromptGenerationResult(
    val promptText: String,
    val isGemini: Boolean,
    val errorNotice: String? = null
)

class PromptRepository(
    private val promptDao: PromptDao,
    private val geminiService: PromptAiService = GeminiPromptService()
) {

    val allPrompts: Flow<List<PromptEntity>> = promptDao.getAllPrompts()
    val favoritePrompts: Flow<List<PromptEntity>> = promptDao.getFavoritePrompts()
    val dislikedTypes: Flow<List<DislikedTypeEntity>> = promptDao.getAllDislikedTypes()
    val recentGeneratedPrompts: Flow<List<GeneratedPromptEntity>> = promptDao.getRecentGeneratedPrompts()

    suspend fun ensureInitialData() = withContext(Dispatchers.IO) {
        val count = promptDao.getPromptCount()
        val disliked = promptDao.getDislikedCategories().map { it.lowercase() }.toSet()
        if (count == 0) {
            val allSeeds = SmartPromptEngine.SEED_PROMPTS
                .filter { it.category.lowercase() !in disliked }
            promptDao.insertPrompts(allSeeds)
            val initialBatch = SmartPromptEngine.generateFreshDailyBatch(0)
                .filter { it.category.lowercase() !in disliked }
            promptDao.insertPrompts(initialBatch)
        } else {
            val existingTitles = promptDao.getAllPromptTitles().toSet()
            val missingSeeds = SmartPromptEngine.SEED_PROMPTS
                .filter { it.title !in existingTitles && it.category.lowercase() !in disliked }
            if (missingSeeds.isNotEmpty()) {
                promptDao.insertPrompts(missingSeeds)
            }
        }
    }

    suspend fun rollFreshPrompts(rollSeed: Int = 0): PromptEntity = withContext(Dispatchers.IO) {
        val disliked = promptDao.getDislikedCategories().map { it.lowercase() }.toSet()
        // 1. Clean up old non-favorite daily prompts so stale prompts do not pile up
        promptDao.clearStaleDailyPrompts()

        // 2. Generate a brand new, diverse batch of creative prompts
        val freshBatch = SmartPromptEngine.generateFreshDailyBatch(rollSeed)
            .filter { it.category.lowercase() !in disliked }

        // 3. Insert fresh batch into database
        if (freshBatch.isNotEmpty()) {
            promptDao.insertPrompts(freshBatch)
        }

        // 4. Return new featured daily prompt
        val candidateFeatured = SmartPromptEngine.getDailyFeaturedPrompt(rollSeed)
        if (candidateFeatured.category.lowercase() !in disliked) {
            candidateFeatured
        } else {
            freshBatch.firstOrNull() ?: candidateFeatured
        }
    }

    suspend fun getDailyPrompts(rollSeed: Int = 0): List<PromptEntity> = withContext(Dispatchers.IO) {
        val disliked = promptDao.getDislikedCategories().map { it.lowercase() }.toSet()
        val candidateFeatured = SmartPromptEngine.getDailyFeaturedPrompt(rollSeed)
        val featured = if (candidateFeatured.category.lowercase() !in disliked) candidateFeatured else getDailyFeatured()
        val dbDaily = promptDao.getDailyPromptsSync().filter { it.category.lowercase() !in disliked }
        val seeds = SmartPromptEngine.SEED_PROMPTS.filter { it.isDaily && it.category.lowercase() !in disliked }
        (listOf(featured) + dbDaily + seeds)
            .distinctBy { it.promptText }
            .take(5)
    }

    suspend fun toggleFavoriteForPrompt(prompt: PromptEntity, currentStatus: Boolean) = withContext(Dispatchers.IO) {
        if (prompt.id != 0L) {
            promptDao.updateFavorite(prompt.id, !currentStatus)
        } else {
            val existing = promptDao.findPromptByText(prompt.promptText)
            if (existing != null) {
                promptDao.updateFavorite(existing.id, !currentStatus)
            } else {
                promptDao.insertPrompt(prompt.copy(isFavorite = !currentStatus))
            }
        }
    }

    suspend fun toggleFavorite(id: Long, currentStatus: Boolean) = withContext(Dispatchers.IO) {
        promptDao.updateFavorite(id, !currentStatus)
    }

    suspend fun dislikePromptAndType(
        promptId: Long,
        category: String,
        tags: String = "",
        title: String = ""
    ) = withContext(Dispatchers.IO) {
        promptDao.markPromptDisliked(promptId)
        promptDao.markCategoryDisliked(category)
        promptDao.insertDislikedType(
            DislikedTypeEntity(
                category = category,
                tagOrKeyword = tags,
                promptTitle = title
            )
        )
    }

    suspend fun unblockCategory(category: String) = withContext(Dispatchers.IO) {
        promptDao.removeDislikedTypeByCategory(category)
        promptDao.unmarkCategoryDisliked(category)
    }

    suspend fun savePrompt(
        title: String,
        promptText: String,
        category: String,
        aiTool: String,
        tags: String = ""
    ): Long = withContext(Dispatchers.IO) {
        val trimmedPromptText = promptText.trim()
        val existing = promptDao.findPromptByText(trimmedPromptText)
        if (existing != null) {
            // Already exists; prevent duplicate record and update bookmark status
            if (!existing.isFavorite || existing.isDisliked) {
                promptDao.updateFavorite(existing.id, true)
                if (existing.isDisliked) {
                    promptDao.updatePrompt(existing.copy(isFavorite = true, isDisliked = false))
                }
            }
            return@withContext existing.id
        }

        val entity = PromptEntity(
            title = title.ifBlank { "Custom Generated Prompt" },
            promptText = trimmedPromptText,
            category = category,
            aiTool = aiTool,
            tags = tags,
            isFavorite = true,
            isDaily = false,
            isDisliked = false
        )
        promptDao.insertPrompt(entity)
    }

    suspend fun deletePrompt(id: Long) = withContext(Dispatchers.IO) {
        promptDao.deletePromptById(id)
    }

    suspend fun generatePrompt(
        topic: String,
        targetAi: String,
        category: String,
        style: String
    ): PromptGenerationResult = withContext(Dispatchers.IO) {
        val cleanTopic = topic.trim()
        val effectiveCategory = if (category == "All Prompts" || category == "ChatGPT & Writing") {
            when {
                cleanTopic.contains("girl", ignoreCase = true) ||
                        cleanTopic.contains("woman", ignoreCase = true) ||
                        cleanTopic.contains("female", ignoreCase = true) ||
                        cleanTopic.contains("ladki", ignoreCase = true) -> PromptCategory.GIRL.displayName
                cleanTopic.contains("boy", ignoreCase = true) ||
                        cleanTopic.contains("man", ignoreCase = true) ||
                        cleanTopic.contains("male", ignoreCase = true) -> PromptCategory.BOY.displayName
                else -> category
            }
        } else {
            category
        }

        val disliked = promptDao.getDislikedCategories().filter { dislikedCat ->
            !cleanTopic.contains(dislikedCat, ignoreCase = true) &&
                    !effectiveCategory.contains(dislikedCat, ignoreCase = true)
        }

        val geminiResult = kotlinx.coroutines.withTimeoutOrNull(4000L) {
            geminiService.generatePrompt(cleanTopic, targetAi, effectiveCategory, style, disliked)
        }
        val geminiText = geminiResult?.getOrNull()?.trim()

        if (geminiResult != null && geminiResult.isSuccess && !geminiText.isNullOrBlank()) {
            PromptGenerationResult(
                promptText = geminiText,
                isGemini = true
            )
        } else {
            val errorNotice = geminiResult?.exceptionOrNull()?.localizedMessage
            // Intelligent procedural generation fallback guaranteed to produce top-tier results
            val procedural = SmartPromptEngine.buildProceduralPrompt(cleanTopic, targetAi, effectiveCategory, style)
            PromptGenerationResult(
                promptText = procedural,
                isGemini = false,
                errorNotice = errorNotice
            )
        }
    }

    suspend fun analyzeImagePrompt(
        imageBase64: String,
        imageMimeType: String = "image/jpeg",
        localFallbackPrompt: String
    ): PromptGenerationResult = withContext(Dispatchers.IO) {
        // Image-to-prompt must describe the uploaded image, not synthesize a generic
        // telemetry-based substitute. If Vision AI fails, surface the failure instead.
        val generatedText = geminiService
            .analyzeImagePrompt(imageBase64, imageMimeType)
            .getOrThrow()
            .trim()

        if (generatedText.isBlank()) {
            throw IllegalStateException("Vision AI returned an empty description. Please try again.")
        }

        PromptGenerationResult(
            promptText = generatedText,
            isGemini = true
        )
    }

    suspend fun getDailyFeatured(): PromptEntity = withContext(Dispatchers.IO) {
        val disliked = promptDao.getDislikedCategories()
        val allSeeds = SmartPromptEngine.SEED_PROMPTS
        val defaultFeatured = SmartPromptEngine.getDailyFeaturedPrompt()
        if (defaultFeatured.category !in disliked) {
            defaultFeatured
        } else {
            allSeeds.firstOrNull { it.category !in disliked } ?: defaultFeatured
        }
    }

    suspend fun cacheGeneratedPrompt(
        topic: String,
        promptText: String,
        targetAi: String,
        category: String,
        style: String,
        isGemini: Boolean,
        mode: String = "TEXT"
    ): Long = withContext(Dispatchers.IO) {
        val cleanPrompt = promptText.trim()
        if (cleanPrompt.isBlank()) return@withContext 0L
        val entity = GeneratedPromptEntity(
            topic = topic.trim().ifBlank { if (mode == "IMAGE") "Image Analysis Prompt" else "Custom Prompt" },
            promptText = cleanPrompt,
            targetAi = targetAi,
            category = category,
            style = style,
            isGeminiPowered = isGemini,
            mode = mode,
            createdAt = System.currentTimeMillis()
        )
        val id = promptDao.insertGeneratedPrompt(entity)
        // Automatically prune so we retain only the last 10 generated prompts locally in Room
        promptDao.trimGeneratedHistory()
        id
    }

    suspend fun deleteGeneratedPrompt(id: Long) = withContext(Dispatchers.IO) {
        promptDao.deleteGeneratedPrompt(id)
    }

    suspend fun clearGeneratedHistory() = withContext(Dispatchers.IO) {
        promptDao.clearGeneratedHistory()
    }
}
