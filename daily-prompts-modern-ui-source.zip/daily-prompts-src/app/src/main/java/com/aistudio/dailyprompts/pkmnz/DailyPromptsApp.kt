package com.aistudio.dailyprompts.pkmnz

import android.app.Application

class DailyPromptsApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}

