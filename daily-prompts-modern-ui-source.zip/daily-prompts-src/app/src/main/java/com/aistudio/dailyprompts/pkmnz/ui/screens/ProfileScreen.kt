package com.aistudio.dailyprompts.pkmnz.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aistudio.dailyprompts.pkmnz.ui.components.DailyPromptsAvatar
import com.aistudio.dailyprompts.pkmnz.ui.components.GoldenLotusLogo
import com.aistudio.dailyprompts.pkmnz.ui.theme.AccentHeartPink
import com.aistudio.dailyprompts.pkmnz.ui.theme.SoftPeach
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmBackground
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardBorderSubtle
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardSurface
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextSecondary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextTertiary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellow
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellowDark
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.AppTab
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.PromptViewModel
import com.aistudio.dailyprompts.pkmnz.ui.i18n.AppStrings
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppLanguage
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppStrings
import com.aistudio.dailyprompts.pkmnz.util.AppConstants

data class ProfileMenuItem(
    val title: String,
    val icon: ImageVector,
    val iconTint: Color,
    val onClick: () -> Unit
)

@Composable
fun ProfileScreen(
    viewModel: PromptViewModel,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current
    val strings = LocalAppStrings.current
    val currentLanguage = LocalAppLanguage.current
    val completedIds by viewModel.completedPromptIds.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()

    var showSupportDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showHistoryDialog by remember { mutableStateOf(false) }

    val primaryDarkColor = WarmYellowDark

    val menuItems = remember(primaryDarkColor, strings) {
        listOf(
            ProfileMenuItem(
                title = strings.menuAccount,
                icon = Icons.Default.AccountCircle,
                iconTint = primaryDarkColor,
                onClick = { viewModel.openEditProfile() }
            ),
            ProfileMenuItem(
                title = strings.menuFavorites,
                icon = Icons.Default.Favorite,
                iconTint = AccentHeartPink,
                onClick = { viewModel.setTab(AppTab.FAVORITES) }
            ),
            ProfileMenuItem(
                title = strings.menuHistory,
                icon = Icons.Default.History,
                iconTint = Color(0xFF3B82F6),
                onClick = { showHistoryDialog = true }
            ),
            ProfileMenuItem(
                title = strings.menuSettings,
                icon = Icons.Default.Settings,
                iconTint = Color(0xFF6B7280),
                onClick = { viewModel.openSettings() }
            ),
            ProfileMenuItem(
                title = "AI Providers & Keys",
                icon = Icons.Default.Key,
                iconTint = Color(0xFFD97706),
                onClick = { viewModel.setTab(AppTab.API_KEY_SETTINGS) }
            ),
            ProfileMenuItem(
                title = strings.menuRate,
                icon = Icons.Default.Star,
                iconTint = Color(0xFFF59E0B),
                onClick = {
                    android.widget.Toast.makeText(
                        context,
                        "Thank you for rating Daily Prompts 5 stars! ⭐⭐⭐⭐⭐",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                }
            ),
            ProfileMenuItem(
                title = strings.menuShare,
                icon = Icons.Default.Share,
                iconTint = Color(0xFF10B981),
                onClick = {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "Daily Prompts App")
                        putExtra(
                            Intent.EXTRA_TEXT,
                            AppConstants.SHARE_APP_MESSAGE
                        )
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Share Daily Prompts via"))
                }
            ),
            ProfileMenuItem(
                title = strings.menuHelp,
                icon = Icons.AutoMirrored.Filled.HelpOutline,
                iconTint = Color(0xFF8B5CF6),
                onClick = { showSupportDialog = true }
            ),
            ProfileMenuItem(
                title = strings.menuAbout,
                icon = Icons.Default.Info,
                iconTint = Color(0xFFEC4899),
                onClick = { showAboutDialog = true }
            )
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmBackground)
            .testTag("profile_screen"),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // 1. Profile Header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 28.dp, start = 20.dp, end = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Circular Profile Image with Edit Badge
                Box(
                    contentAlignment = Alignment.BottomEnd,
                    modifier = Modifier
                        .clip(CircleShape)
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            viewModel.openEditProfile()
                        }
                        .testTag("profile_avatar_edit_container")
                ) {
                    Box(
                        modifier = Modifier
                            .shadow(elevation = 6.dp, shape = CircleShape, ambientColor = Color(0x1A000000))
                    ) {
                        DailyPromptsAvatar(
                            sizeDp = 92.dp,
                            profile = userProfile
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(WarmYellow, shape = CircleShape)
                            .clip(CircleShape)
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                viewModel.openEditProfile()
                            }
                            .testTag("profile_edit_badge"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Profile",
                            tint = WarmTextPrimary,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = userProfile.name,
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp,
                        color = WarmTextPrimary
                    ),
                    modifier = Modifier.testTag("profile_name_text")
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = userProfile.bio,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 15.sp,
                        color = WarmTextSecondary
                    ),
                    modifier = Modifier.testTag("profile_bio_text")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        viewModel.openEditProfile()
                    },
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = WarmYellowDark
                    ),
                    border = BorderStroke(1.dp, WarmYellowDark.copy(alpha = 0.5f)),
                    modifier = Modifier.testTag("profile_edit_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = strings.editProfileTitle,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // 2. Menu Items Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .shadow(elevation = 3.dp, shape = RoundedCornerShape(24.dp), ambientColor = Color(0x14000000)),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = WarmCardSurface),
                border = BorderStroke(1.dp, WarmCardBorderSubtle)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    menuItems.forEachIndexed { index, item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    item.onClick()
                                }
                                .padding(horizontal = 20.dp, vertical = 15.dp)
                                .testTag("profile_menu_${item.title}"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(item.iconTint.copy(alpha = 0.12f), shape = CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.title,
                                    tint = item.iconTint,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 15.sp,
                                    color = WarmTextPrimary
                                ),
                                modifier = Modifier.weight(1f)
                            )

                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                tint = WarmTextTertiary,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        if (index < menuItems.size - 1) {
                            HorizontalDivider(
                                color = Color(0xFFF7EFE6),
                                thickness = 1.dp,
                                modifier = Modifier.padding(horizontal = 20.dp)
                            )
                        }
                    }
                }
            }
        }

        // 3. Bottom Quote Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SoftPeach),
                border = BorderStroke(1.dp, Color(0xFFFFD5C2))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "“Every prompt is a step toward a brighter tomorrow.” ❤️",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                            lineHeight = 22.sp,
                            color = WarmTextPrimary
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }

    // Help & Support Dialog
    if (showSupportDialog) {
        AlertDialog(
            onDismissRequest = { showSupportDialog = false },
            confirmButton = {
                TextButton(onClick = { showSupportDialog = false }) {
                    Text(strings.done, fontWeight = FontWeight.Bold, color = Color(0xFFD97706))
                }
            },
            title = {
                Text(
                    text = strings.menuHelp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    color = WarmTextPrimary
                )
            },
            text = {
                Text(
                    text = "Daily Prompts is crafted to help you cultivate gratitude, clarity, and creativity each day.\n\n" +
                            "• Home: View today's featured prompt and explore by category.\n" +
                            "• Explore: Search and discover prompts across wellness, productivity, and lifestyle.\n" +
                            "• Favorites: Save your favorite reflections to revisit anytime.\n" +
                            "• Detail: Mark prompts as completed to build positive momentum.",
                    color = WarmTextSecondary,
                    lineHeight = 22.sp
                )
            },
            containerColor = WarmCardSurface,
            shape = RoundedCornerShape(20.dp)
        )
    }

    // About Dialog
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) {
                    Text(strings.close, fontWeight = FontWeight.Bold, color = Color(0xFFD97706))
                }
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GoldenLotusLogo(sizeDp = 28.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Daily Prompts",
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        color = WarmTextPrimary
                    )
                }
            },
            text = {
                Text(
                    text = "Version 1.3.0\n\n" +
                            "Small Prompts Big Changes ❤️\n\n" +
                            "Designed to nurture a happier, healthier, and more creative mindset every single day.",
                    color = WarmTextSecondary,
                    lineHeight = 22.sp
                )
            },
            containerColor = WarmCardSurface,
            shape = RoundedCornerShape(20.dp)
        )
    }

    // History Dialog
    if (showHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showHistoryDialog = false },
            confirmButton = {
                TextButton(onClick = { showHistoryDialog = false }) {
                    Text(strings.close, fontWeight = FontWeight.Bold, color = WarmYellowDark)
                }
            },
            title = {
                Text(
                    text = strings.menuHistory,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    color = WarmTextPrimary
                )
            },
            text = {
                Column {
                    Text(
                        text = "Completed Prompts: ${completedIds.size}",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF15803D),
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (completedIds.isEmpty()) {
                            "You haven't marked any prompts as completed yet. Open any prompt in detail view and tap 'Mark as Completed ✓'!"
                        } else {
                            "Keep going! Every completed prompt brings you closer to your wellness and mindfulness goals."
                        },
                        color = WarmTextSecondary,
                        lineHeight = 20.sp
                    )
                }
            },
            containerColor = WarmCardSurface,
            shape = RoundedCornerShape(20.dp)
        )
    }
}
