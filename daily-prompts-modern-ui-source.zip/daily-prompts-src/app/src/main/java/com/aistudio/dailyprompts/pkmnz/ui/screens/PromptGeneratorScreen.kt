package com.aistudio.dailyprompts.pkmnz.ui.screens

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Input
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Input
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.OfflinePin
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.aistudio.dailyprompts.pkmnz.data.local.GeneratedPromptEntity
import com.aistudio.dailyprompts.pkmnz.data.model.AiTool
import com.aistudio.dailyprompts.pkmnz.data.model.PromptCategory
import com.aistudio.dailyprompts.pkmnz.ui.components.AnimatedCopyContent
import com.aistudio.dailyprompts.pkmnz.ui.components.AnimatedCopyIcon
import com.aistudio.dailyprompts.pkmnz.ui.components.AnimatedCopyText
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedBackground
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedBorder
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedButtonSecondary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedCardContainer
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedCardSurface
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedOnPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedTextLabel
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedTextPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedTextSecondary
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.AppTab
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.GeneratorMode
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.PromptViewModel
import com.aistudio.dailyprompts.pkmnz.ui.i18n.AppStrings
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppLanguage
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppStrings

@Composable
fun PromptGeneratorScreen(
    viewModel: PromptViewModel,
    onBack: () -> Unit,
    onNavigateToScratchpad: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val strings = LocalAppStrings.current
    val currentLanguage = LocalAppLanguage.current
    val state by viewModel.generatorState.collectAsStateWithLifecycle()
    val hasApiKey by viewModel.hasApiKey.collectAsStateWithLifecycle()
    val recentlyCopiedId by viewModel.recentlyCopiedId.collectAsStateWithLifecycle()
    val recentPrompts by viewModel.recentGeneratedPrompts.collectAsStateWithLifecycle()
    val favoritePrompts by viewModel.favoritePrompts.collectAsStateWithLifecycle()
    val isResultCopied = (recentlyCopiedId == PromptViewModel.COPIED_ID_GENERATOR)

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.selectImageUri(context, uri)
        }
    }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            viewModel.selectImageUri(context, uri)
        }
    }

    val quickIdeas = listOf(
        "👧 Beautiful girl aesthetic portrait in golden hour light",
        "👧 Royal Banarasi saree beautiful girl with diya glow",
        "👧 Cyberpunk beautiful girl with neon AR reflections",
        "👧 Ethereal fairycore wildflower bloom beautiful girl",
        "👦 Boy in rainy neon street portrait with headphones",
        "🌿 Dramatic Himalayan mountain mist & golden sunrise",
        "👦 Royal velvet sherwani ethnic boy portrait",
        "🌿 Bioluminescent waterfall & enchanted forest",
        "👦 Cozy cafe reader boy in knitted sweater",
        "👧 Candid monsoon rain clear umbrella girl",
        "🌿 Milky Way galaxy arching over Sahara dunes"
    )

    val styles = listOf(
        "Professional",
        "Cinematic",
        "Viral & High-CTR",
        "Step-by-Step",
        "Minimal & Concise",
        "Storyteller"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Transparent)
            .navigationBarsPadding()
            .testTag("prompt_generator_screen"),
        contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 64.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onBack()
                    },
                    modifier = Modifier.testTag("generator_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = strings.back,
                        tint = SophisticatedTextPrimary
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "PROMPT CREATOR",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.6.sp,
                        color = SophisticatedPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = strings.generatorTitle,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = SophisticatedTextPrimary
                    )
                    Text(
                        text = strings.generatorSubtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = SophisticatedTextSecondary
                    )
                }
            }
        }

        // Mode Selector: Text to Prompt vs Analyze Image
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = SophisticatedCardSurface,
                border = BorderStroke(1.dp, SophisticatedBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(5.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            viewModel.setGeneratorMode(GeneratorMode.TEXT)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("mode_text_prompt_button"),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.generatorMode == GeneratorMode.TEXT) SophisticatedPrimary else Color.Transparent,
                            contentColor = if (state.generatorMode == GeneratorMode.TEXT) SophisticatedOnPrimary else SophisticatedTextSecondary
                        ),
                        elevation = null
                    ) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            strings.tabTextToPrompt,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Button(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            viewModel.setGeneratorMode(GeneratorMode.IMAGE)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("mode_analyze_image_button"),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.generatorMode == GeneratorMode.IMAGE) SophisticatedPrimary else Color.Transparent,
                            contentColor = if (state.generatorMode == GeneratorMode.IMAGE) SophisticatedOnPrimary else SophisticatedTextSecondary
                        ),
                        elevation = null
                    ) {
                        Icon(imageVector = Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            strings.tabImageToPrompt,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // 1. Text to Prompt Input Card
        if (state.generatorMode == GeneratorMode.TEXT) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = SophisticatedCardSurface
                    ),
                    border = BorderStroke(1.dp, SophisticatedBorder)
                ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "WHAT WOULD YOU LIKE TO CREATE?",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp,
                            color = SophisticatedTextLabel
                        )

                        if (state.lastOriginalTopic != null) {
                            TextButton(
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    viewModel.undoMagicEnhance()
                                },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Undo Enhance",
                                    tint = SophisticatedPrimary,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    "Undo",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = SophisticatedPrimary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = state.topicInput,
                        onValueChange = { input ->
                            viewModel.updateTopicInput(input)
                            if ((input.contains("girl", ignoreCase = true) || input.contains("ladki", ignoreCase = true)) &&
                                state.selectedCategory == PromptCategory.CHAT_GPT) {
                                viewModel.updateSelectedCategory(PromptCategory.GIRL)
                            }
                        },
                        placeholder = {
                            Text(
                                strings.topicPlaceholder,
                                color = SophisticatedTextSecondary
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .testTag("generator_topic_input"),
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = SophisticatedCardContainer,
                            unfocusedContainerColor = SophisticatedCardContainer,
                            focusedBorderColor = SophisticatedPrimary,
                            unfocusedBorderColor = SophisticatedBorder,
                            focusedTextColor = SophisticatedTextPrimary,
                            unfocusedTextColor = SophisticatedTextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // 🪄 Magic Prompt Enhancer (1-Tap Optimizer) Bar
                    Surface(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            viewModel.magicEnhanceInput()
                        },
                        shape = RoundedCornerShape(14.dp),
                        color = if (state.topicInput.isNotBlank()) SophisticatedPrimary.copy(alpha = 0.12f) else SophisticatedCardContainer,
                        border = BorderStroke(
                            1.dp,
                            if (state.topicInput.isNotBlank()) SophisticatedPrimary.copy(alpha = 0.45f) else SophisticatedBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("magic_enhance_button")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (state.isEnhancing) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = SophisticatedPrimary
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = SophisticatedPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = if (state.isEnhancing) "Optimizing Prompt with AI..." else "🪄 1-Tap Magic Enhancer",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = SophisticatedTextPrimary
                                    )
                                    Text(
                                        text = if (state.lastOriginalTopic != null) "Tap again to cycle styles, or tap Undo above" else "Transforms ideas into 10x Master Prompts for ChatGPT & Claude",
                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                        color = SophisticatedTextSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = SophisticatedPrimary,
                                contentColor = SophisticatedOnPrimary
                            ) {
                                Text(
                                    text = if (state.lastOriginalTopic != null) "CYCLE STYLE 🔄" else "OPTIMIZE ⚡",
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    state.errorMessage?.let { errorMsg ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f),
                                    RoundedCornerShape(12.dp)
                                )
                                .padding(12.dp)
                        ) {
                            Text(
                                text = errorMsg,
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quick suggestion chips
                    Text(
                        text = "SUGGESTIONS",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp,
                        color = SophisticatedTextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        quickIdeas.forEach { idea ->
                            SuggestionChip(
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    viewModel.updateTopicInput(idea)
                                    if (idea.contains("girl", ignoreCase = true) || idea.contains("👧")) {
                                        viewModel.updateSelectedCategory(PromptCategory.GIRL)
                                        viewModel.updateSelectedAi(AiTool.MIDJOURNEY)
                                    } else if (idea.contains("boy", ignoreCase = true) || idea.contains("👦")) {
                                        viewModel.updateSelectedCategory(PromptCategory.BOY)
                                        viewModel.updateSelectedAi(AiTool.MIDJOURNEY)
                                    }
                                },
                                label = { Text(idea, maxLines = 1, color = SophisticatedTextPrimary) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = SophisticatedCardContainer
                                ),
                                border = BorderStroke(1.dp, SophisticatedBorder),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.testTag("suggestion_chip_$idea")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Category Selector
                    Text(
                        text = "CATEGORY",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp,
                        color = SophisticatedTextLabel
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PromptCategory.values().filter { it != PromptCategory.ALL }.forEach { cat ->
                            val isSelected = cat == state.selectedCategory
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    viewModel.updateSelectedCategory(cat)
                                },
                                label = { Text("${cat.icon} ${AppStrings.translate(cat.displayName, currentLanguage)}") },
                                shape = RoundedCornerShape(12.dp),
                                border = if (!isSelected) BorderStroke(1.dp, SophisticatedBorder) else null,
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = SophisticatedPrimary,
                                    selectedLabelColor = SophisticatedOnPrimary,
                                    containerColor = SophisticatedCardContainer,
                                    labelColor = SophisticatedTextLabel
                                ),
                                modifier = Modifier.testTag("generator_category_chip_${cat.name}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Target AI Tool
                    Text(
                        text = "TARGET AI MODEL",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp,
                        color = SophisticatedTextLabel
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AiTool.values().forEach { tool ->
                            val isSelected = tool == state.selectedAi
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    viewModel.updateSelectedAi(tool)
                                },
                                label = { Text(tool.displayName) },
                                shape = RoundedCornerShape(12.dp),
                                border = if (!isSelected) BorderStroke(1.dp, SophisticatedBorder) else null,
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = SophisticatedPrimary,
                                    selectedLabelColor = SophisticatedOnPrimary,
                                    containerColor = SophisticatedCardContainer,
                                    labelColor = SophisticatedTextLabel
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Tone / Style selector
                    Text(
                        text = "TONE & STYLE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp,
                        color = SophisticatedTextLabel
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        styles.forEach { style ->
                            val isSelected = style == state.selectedStyle
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    viewModel.updateSelectedStyle(style)
                                },
                                label = { Text(style) },
                                shape = RoundedCornerShape(12.dp),
                                border = if (!isSelected) BorderStroke(1.dp, SophisticatedBorder) else null,
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = SophisticatedPrimary,
                                    selectedLabelColor = SophisticatedOnPrimary,
                                    containerColor = SophisticatedCardContainer,
                                    labelColor = SophisticatedTextLabel
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Generation Speed Selector: Turbo Fast ⏩ vs Live AI
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "GENERATION SPEED",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp,
                            color = SophisticatedTextLabel
                        )

                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (state.isTurboFastMode) SophisticatedPrimary.copy(alpha = 0.18f) else SophisticatedCardContainer,
                            border = BorderStroke(1.dp, if (state.isTurboFastMode) SophisticatedPrimary else SophisticatedBorder),
                            modifier = Modifier
                                .clickable {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    viewModel.toggleTurboFastMode()
                                }
                                .testTag("toggle_turbo_fast_mode_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = if (state.isTurboFastMode) "⚡ Turbo Fast ⏩ (Instant)" else "🤖 Live AI (Standard)",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (state.isTurboFastMode) SophisticatedPrimary else SophisticatedTextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Generate Button (#D0BCFF with #381E72 text)
                    Button(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            viewModel.resetRecentlyCopied()
                            viewModel.generateCustomPrompt()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 52.dp)
                            .testTag("generate_prompt_button"),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                        shape = RoundedCornerShape(16.dp),
                        enabled = !state.isGenerating,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SophisticatedPrimary,
                            contentColor = SophisticatedOnPrimary
                        )
                    ) {
                        if (state.isGenerating) {
                            CircularProgressIndicator(
                                color = SophisticatedOnPrimary,
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                if (state.isTurboFastMode) "Fast Synthesizing ⏩..." else "Synthesizing Master Prompt...",
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (state.isTurboFastMode) "Generate Fast ⏩" else strings.generatePromptBtn,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
        }

        // 2. Image to Prompt Input & Analysis Card
        if (state.generatorMode == GeneratorMode.IMAGE) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("analyze_image_input_card"),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = SophisticatedCardSurface
                    ),
                    border = BorderStroke(1.dp, SophisticatedBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Text(
                            text = "IMAGE TO DESCRIPTIVE PROMPT",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp,
                            color = SophisticatedPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Upload any photo to generate a rich, comprehensive descriptive prompt based solely on its visual details.",
                            style = MaterialTheme.typography.bodySmall,
                            color = SophisticatedTextSecondary
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Upload Box or Image Preview
                        if (state.selectedImageUri != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(240.dp)
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(SophisticatedCardContainer)
                            ) {
                                AsyncImage(
                                    model = state.selectedImageUri,
                                    contentDescription = "Uploaded Image Preview",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )

                                // Top bar overlay with Change & Remove
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xCC000000)
                                    ) {
                                        Text(
                                            text = state.imageAspectRatio.ifBlank { "Ready to analyze" },
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color(0xCC000000),
                                            modifier = Modifier.clickable {
                                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                photoPickerLauncher.launch(
                                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                )
                                            }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Refresh,
                                                    contentDescription = "Change",
                                                    tint = Color.White,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = "Change",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = Color.White
                                                )
                                            }
                                        }

                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color(0xCC000000),
                                            modifier = Modifier.clickable {
                                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                viewModel.clearSelectedImage()
                                            }
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Remove",
                                                tint = Color.White,
                                                modifier = Modifier.padding(6.dp).size(16.dp)
                                            )
                                        }
                                    }
                                }

                                if (state.imageColorSummary.isNotBlank()) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xCC000000),
                                        modifier = Modifier
                                            .align(Alignment.BottomStart)
                                            .padding(10.dp)
                                    ) {
                                        Text(
                                            text = state.imageColorSummary,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        } else {
                            // Empty Upload Dropzone Card
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(SophisticatedCardContainer)
                                    .padding(16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .background(SophisticatedPrimary.copy(alpha = 0.15f), shape = RoundedCornerShape(14.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AddPhotoAlternate,
                                            contentDescription = "Upload photo",
                                            tint = SophisticatedPrimary,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }

                                    Text(
                                        text = "Upload Image to Analyze",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = SophisticatedTextPrimary
                                    )
                                    Text(
                                        text = "Supports JPEG, PNG, WEBP photos",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SophisticatedTextSecondary
                                    )

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                photoPickerLauncher.launch(
                                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                )
                                            },
                                            shape = RoundedCornerShape(14.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = SophisticatedPrimary,
                                                contentColor = SophisticatedOnPrimary
                                            ),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .defaultMinSize(minHeight = 48.dp)
                                                .testTag("upload_image_button")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.PhotoCamera,
                                                contentDescription = null,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                "Choose Photo",
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                filePickerLauncher.launch("image/*")
                                            },
                                            shape = RoundedCornerShape(14.dp),
                                            border = BorderStroke(1.dp, SophisticatedBorder),
                                            colors = ButtonDefaults.outlinedButtonColors(
                                                contentColor = SophisticatedTextPrimary
                                            ),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .defaultMinSize(minHeight = 48.dp)
                                        ) {
                                            Text(
                                                "Browse Files",
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Sample Presets (No horizontal clipping, cleanly wraps)
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "OR TRY A SAMPLE PRESET",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp,
                            color = SophisticatedTextLabel
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                SuggestionChip(
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        viewModel.selectSampleImage(context, "golden_hour_portrait")
                                    },
                                    label = {
                                        Text(
                                            "🌅 Golden Hour",
                                            color = SophisticatedTextPrimary,
                                            fontWeight = if (state.imageSampleId == "golden_hour_portrait") FontWeight.Bold else FontWeight.Normal,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    },
                                    colors = SuggestionChipDefaults.suggestionChipColors(
                                        containerColor = if (state.imageSampleId == "golden_hour_portrait") SophisticatedPrimary.copy(alpha = 0.25f) else SophisticatedCardContainer
                                    ),
                                    border = BorderStroke(1.dp, if (state.imageSampleId == "golden_hour_portrait") SophisticatedPrimary else SophisticatedBorder),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .defaultMinSize(minHeight = 44.dp)
                                        .testTag("sample_golden_hour_chip")
                                )
                                SuggestionChip(
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        viewModel.selectSampleImage(context, "wildflower_meadow")
                                    },
                                    label = {
                                        Text(
                                            "🌸 Wildflowers",
                                            color = SophisticatedTextPrimary,
                                            fontWeight = if (state.imageSampleId == "wildflower_meadow") FontWeight.Bold else FontWeight.Normal,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    },
                                    colors = SuggestionChipDefaults.suggestionChipColors(
                                        containerColor = if (state.imageSampleId == "wildflower_meadow") SophisticatedPrimary.copy(alpha = 0.25f) else SophisticatedCardContainer
                                    ),
                                    border = BorderStroke(1.dp, if (state.imageSampleId == "wildflower_meadow") SophisticatedPrimary else SophisticatedBorder),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .defaultMinSize(minHeight = 44.dp)
                                )
                            }

                            SuggestionChip(
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    viewModel.selectSampleImage(context, "cosmic_landscape")
                                },
                                label = {
                                    Text(
                                        "🌌 Cosmic Desert Sky",
                                        color = SophisticatedTextPrimary,
                                        fontWeight = if (state.imageSampleId == "cosmic_landscape") FontWeight.Bold else FontWeight.Normal,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = if (state.imageSampleId == "cosmic_landscape") SophisticatedPrimary.copy(alpha = 0.25f) else SophisticatedCardContainer
                                ),
                                border = BorderStroke(1.dp, if (state.imageSampleId == "cosmic_landscape") SophisticatedPrimary else SophisticatedBorder),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .defaultMinSize(minHeight = 44.dp)
                            )
                        }

                        state.errorMessage?.let { errorMsg ->
                            Spacer(modifier = Modifier.height(10.dp))
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f),
                                        RoundedCornerShape(12.dp)
                                    )
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = errorMsg,
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Analyze & Generate Prompt Button (Optimized for mobile displays & never truncated)
                        Button(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                viewModel.resetRecentlyCopied()
                                if (state.selectedImageBase64 != null) {
                                    viewModel.analyzeUploadedImage(context)
                                } else {
                                    photoPickerLauncher.launch(
                                        androidx.activity.result.PickVisualMediaRequest(
                                            androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly
                                        )
                                    )
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 52.dp)
                                .testTag("analyze_image_prompt_button"),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                            shape = RoundedCornerShape(16.dp),
                            enabled = !state.isGenerating,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SophisticatedPrimary,
                                contentColor = SophisticatedOnPrimary
                            )
                        ) {
                            if (state.isGenerating) {
                                CircularProgressIndicator(
                                    color = SophisticatedOnPrimary,
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    "Analyzing visual details & lighting...",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = strings.analyzeImageBtn,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontSize = 14.sp,
                                    maxLines = 2,
                                    softWrap = true,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }

        // Generated Result Card
        if (state.generatedResult.isNotBlank()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generated_result_card"),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = SophisticatedCardSurface
                    ),
                    border = BorderStroke(1.dp, SophisticatedBorder),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = SophisticatedCardContainer,
                                border = BorderStroke(1.dp, SophisticatedBorder)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = SophisticatedPrimary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    val badgeLabel = if (state.generatorMode == GeneratorMode.IMAGE) {
                                        if (state.isGeminiPowered) "AI VISION (ANALYZED)" else "SMART VISION ENGINE"
                                    } else {
                                        if (state.isGeminiPowered) "GEMINI 3.5 AI" else if (state.isTurboFastMode) "⚡ TURBO FAST ⏩" else "SMART ENGINE"
                                    }
                                    Text(
                                        text = badgeLabel,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = SophisticatedPrimary
                                    )
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = strings.readyToCopy,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF00C853)
                                )

                                IconButton(
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        viewModel.dislikePrompt(
                                            com.aistudio.dailyprompts.pkmnz.data.local.PromptEntity(
                                                title = state.topicInput.take(50).ifBlank { "Generated Prompt" },
                                                promptText = state.generatedResult,
                                                category = state.selectedCategory.displayName,
                                                aiTool = state.selectedAi.displayName
                                            )
                                        )
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .testTag("dislike_generated_result_button")
                                 ) {
                                    Icon(
                                        imageVector = Icons.Outlined.ThumbDown,
                                        contentDescription = "Dislike prompt and block this type",
                                        tint = SophisticatedTextSecondary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                // Close Button: Clears the current prompt and allows generating a new one
                                IconButton(
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        viewModel.clearGeneratedPrompt()
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(
                                            color = SophisticatedCardContainer,
                                            shape = CircleShape
                                        )
                                        .testTag("close_generated_result_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = strings.closePromptBtn,
                                        tint = SophisticatedTextPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(SophisticatedCardContainer)
                                .padding(16.dp)
                        ) {
                            Text(
                                text = state.generatedResult,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    lineHeight = 22.sp
                                ),
                                color = SophisticatedTextPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // Actions
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            val resultCopyBg by animateColorAsState(
                                targetValue = if (isResultCopied) Color(0xFF00C853) else SophisticatedPrimary,
                                animationSpec = tween(durationMillis = 260),
                                label = "resultCopyBg"
                            )

                            // Primary Copy Button ("Copy Prompt" feature)
                            Button(
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    viewModel.copyPrompt(context, state.generatedResult, PromptViewModel.COPIED_ID_GENERATOR)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .defaultMinSize(minHeight = 50.dp)
                                    .testTag("copy_prompt_button")
                                    .testTag("copy_generated_result_button"),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = resultCopyBg,
                                    contentColor = if (isResultCopied) Color.White else SophisticatedOnPrimary
                                ),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                AnimatedCopyContent(
                                    isCopied = isResultCopied,
                                    normalText = "Copy Prompt",
                                    copiedText = "Copied to Clipboard!",
                                    iconSize = 18.dp,
                                    style = MaterialTheme.typography.titleSmall,
                                    contentColor = if (isResultCopied) Color.White else SophisticatedOnPrimary
                                )
                            }

                            // 🪄 Magic Enhancer Level Up
                            OutlinedButton(
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    viewModel.magicEnhanceResult()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .defaultMinSize(minHeight = 44.dp)
                                    .testTag("enhance_result_button"),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, SophisticatedPrimary.copy(alpha = 0.5f)),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = SophisticatedPrimary
                                )
                            ) {
                                if (state.isEnhancing) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = SophisticatedPrimary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(strings.optimizingPrompt, style = MaterialTheme.typography.labelMedium)
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        strings.levelUpMagicBtn,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Secondary actions row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Share
                                Button(
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        viewModel.sharePrompt(context, state.generatedResult, state.topicInput)
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .defaultMinSize(minHeight = 44.dp),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = SophisticatedButtonSecondary,
                                        contentColor = SophisticatedTextPrimary
                                    )
                                ) {
                                    Icon(imageVector = Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        "Share",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                // Save to Favorites
                                Button(
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        viewModel.saveGeneratedPrompt()
                                    },
                                    enabled = !state.isSaved && !state.isSaving,
                                    modifier = Modifier
                                        .weight(1f)
                                        .defaultMinSize(minHeight = 44.dp)
                                        .testTag("save_generated_prompt_button"),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (state.isSaved) SophisticatedPrimary.copy(alpha = 0.2f) else SophisticatedButtonSecondary,
                                        contentColor = if (state.isSaved) SophisticatedPrimary else SophisticatedTextPrimary,
                                        disabledContainerColor = SophisticatedButtonSecondary.copy(alpha = 0.5f),
                                        disabledContentColor = SophisticatedPrimary
                                    )
                                ) {
                                    Icon(
                                        imageVector = if (state.isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                        contentDescription = if (state.isSaved) "Saved" else "Save",
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        if (state.isSaved) "Saved" else "Save",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                // Edit in Scratchpad
                                Button(
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        viewModel.loadIntoScratchpad(state.generatedResult)
                                        onNavigateToScratchpad(state.generatedResult)
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .defaultMinSize(minHeight = 44.dp),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = SophisticatedButtonSecondary,
                                        contentColor = SophisticatedTextPrimary
                                    )
                                ) {
                                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        "Edit",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            // Close & New Prompt Action Button
                            OutlinedButton(
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    viewModel.clearGeneratedPrompt()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .defaultMinSize(minHeight = 44.dp)
                                    .testTag("close_prompt_and_generate_new_button"),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, SophisticatedBorder),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = SophisticatedTextSecondary
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = SophisticatedTextSecondary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    strings.closePromptNewBtn,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = SophisticatedTextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Recent History Section (Automatically cached last 10 generated prompts in Room for offline access)
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("recent_history_header"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = SophisticatedPrimary.copy(alpha = 0.15f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CloudDone,
                                    contentDescription = null,
                                    tint = SophisticatedPrimary,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = "ROOM DB • OFFLINE CACHE",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = SophisticatedPrimary,
                                    fontSize = 10.sp
                                )
                            }
                        }
                        Text(
                            text = "• ${recentPrompts.size}/10 CACHED",
                            style = MaterialTheme.typography.labelSmall,
                            color = SophisticatedTextSecondary,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Recent History",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = SophisticatedTextPrimary
                    )
                    Text(
                        text = "Last 10 generated prompts cached locally for instant offline access",
                        style = MaterialTheme.typography.bodySmall,
                        color = SophisticatedTextSecondary
                    )
                }

                if (recentPrompts.isNotEmpty()) {
                    OutlinedButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            viewModel.clearGeneratedHistory()
                        },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, SophisticatedBorder),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = SophisticatedTextSecondary
                        ),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("clear_history_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Clear History",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            "Clear",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        if (recentPrompts.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("empty_history_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = SophisticatedCardSurface),
                    border = BorderStroke(1.dp, SophisticatedBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(SophisticatedPrimary.copy(alpha = 0.12f), shape = RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = null,
                                tint = SophisticatedPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Text(
                            text = "No History Yet",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = SophisticatedTextPrimary
                        )
                        Text(
                            text = "Every prompt you generate or analyze is automatically cached here in local Room database storage (last 10) for instant offline access and one-tap copying.",
                            style = MaterialTheme.typography.bodySmall,
                            color = SophisticatedTextSecondary,
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        } else {
            items(
                count = recentPrompts.size,
                key = { index -> recentPrompts[index].id }
            ) { index ->
                val historyItem = recentPrompts[index]
                val isItemCopied = (recentlyCopiedId == historyItem.id)
                val isAlreadyFavorite = favoritePrompts.any { it.promptText == historyItem.promptText }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("history_item_${historyItem.id}"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = SophisticatedCardSurface),
                    border = BorderStroke(1.dp, SophisticatedBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        // Top info row: Badges + Timestamp + Delete
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                // Mode chip (Text vs Image)
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (historyItem.mode == "IMAGE") Color(0xFF0284C7).copy(alpha = 0.2f) else SophisticatedCardContainer,
                                    border = BorderStroke(1.dp, SophisticatedBorder)
                                ) {
                                    Text(
                                        text = if (historyItem.mode == "IMAGE") "🖼️ Image" else "✍️ Text",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (historyItem.mode == "IMAGE") Color(0xFF38BDF8) else SophisticatedTextPrimary,
                                        fontSize = 11.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }

                                // Target AI chip
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = SophisticatedCardContainer,
                                    border = BorderStroke(1.dp, SophisticatedBorder)
                                ) {
                                    Text(
                                        text = historyItem.targetAi,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Medium,
                                        color = SophisticatedTextSecondary,
                                        fontSize = 11.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }

                                // Offline badge
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(0xFF00C853).copy(alpha = 0.15f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.OfflinePin,
                                            contentDescription = null,
                                            tint = Color(0xFF00C853),
                                            modifier = Modifier.size(10.dp)
                                        )
                                        Text(
                                            text = "Offline",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF00C853),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = formatRelativeTime(historyItem.createdAt),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SophisticatedTextSecondary,
                                    fontSize = 11.sp
                                )

                                IconButton(
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        viewModel.deleteGeneratedPrompt(historyItem.id)
                                    },
                                    modifier = Modifier
                                        .size(28.dp)
                                        .testTag("history_delete_button_${historyItem.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteOutline,
                                        contentDescription = "Delete from history",
                                        tint = SophisticatedTextSecondary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Topic Title
                        Text(
                            text = historyItem.topic,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = SophisticatedTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Prompt Text Monospace Box
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(SophisticatedCardContainer)
                                .padding(12.dp)
                        ) {
                            Text(
                                text = historyItem.promptText,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    lineHeight = 18.sp
                                ),
                                color = SophisticatedTextPrimary,
                                maxLines = 5,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Action Buttons: 2x2 Grid for clean, fully visible display on any screen width
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Row 1: Copy Prompt (Primary) & Load into Editor
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val itemCopyBg by animateColorAsState(
                                    targetValue = if (isItemCopied) Color(0xFF00C853) else SophisticatedPrimary,
                                    animationSpec = tween(durationMillis = 260),
                                    label = "itemCopyBg_${historyItem.id}"
                                )

                                // Copy button
                                Button(
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        viewModel.copyPrompt(context, historyItem.promptText, historyItem.id)
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .defaultMinSize(minHeight = 42.dp)
                                        .testTag("history_copy_button_${historyItem.id}"),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = itemCopyBg,
                                        contentColor = if (isItemCopied) Color.White else SophisticatedOnPrimary
                                    )
                                ) {
                                    AnimatedCopyIcon(
                                        isCopied = isItemCopied,
                                        iconSize = 15.dp,
                                        normalTint = if (isItemCopied) Color.White else SophisticatedOnPrimary,
                                        copiedTint = Color.White
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    AnimatedCopyText(
                                        isCopied = isItemCopied,
                                        normalText = "Copy",
                                        copiedText = "Copied!",
                                        style = MaterialTheme.typography.labelMedium.copy(fontSize = 12.sp),
                                        color = if (isItemCopied) Color.White else SophisticatedOnPrimary
                                    )
                                }

                                // Load into Generator Editor
                                Button(
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        viewModel.loadHistoricalPrompt(historyItem)
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .defaultMinSize(minHeight = 42.dp)
                                        .testTag("history_load_button_${historyItem.id}"),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = SophisticatedButtonSecondary,
                                        contentColor = SophisticatedTextPrimary
                                    )
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Input,
                                        contentDescription = "Load into Editor",
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        "Load",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            // Row 2: Save to Favorites & Edit in Scratchpad
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Save to Favorites
                                Button(
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        if (!isAlreadyFavorite) {
                                            viewModel.savePrompt(
                                                title = historyItem.topic,
                                                promptText = historyItem.promptText,
                                                category = historyItem.category,
                                                aiTool = historyItem.targetAi
                                            )
                                        }
                                    },
                                    enabled = !isAlreadyFavorite,
                                    modifier = Modifier
                                        .weight(1f)
                                        .defaultMinSize(minHeight = 42.dp)
                                        .testTag("history_save_button_${historyItem.id}"),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isAlreadyFavorite) SophisticatedPrimary.copy(alpha = 0.2f) else SophisticatedButtonSecondary,
                                        contentColor = if (isAlreadyFavorite) SophisticatedPrimary else SophisticatedTextPrimary,
                                        disabledContainerColor = SophisticatedButtonSecondary.copy(alpha = 0.5f),
                                        disabledContentColor = SophisticatedPrimary
                                    )
                                ) {
                                    Icon(
                                        imageVector = if (isAlreadyFavorite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                        contentDescription = "Save",
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isAlreadyFavorite) "Saved" else "Save",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                // Edit in Scratchpad
                                Button(
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        viewModel.loadIntoScratchpad(historyItem.promptText)
                                        onNavigateToScratchpad(historyItem.promptText)
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .defaultMinSize(minHeight = 42.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = SophisticatedButtonSecondary,
                                        contentColor = SophisticatedTextPrimary
                                    )
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit in Scratchpad",
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        "Edit",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatRelativeTime(timestamp: Long): String {
    val diff = System.currentTimeMillis() - timestamp
    return when {
        diff < 60_000L -> "Just now"
        diff < 3600_000L -> "${(diff / 60_000L).coerceAtLeast(1)}m ago"
        diff < 86400_000L -> "${(diff / 3600_000L)}h ago"
        diff < 172800_000L -> "Yesterday"
        else -> java.text.SimpleDateFormat("MMM d", java.util.Locale.getDefault()).format(java.util.Date(timestamp))
    }
}

