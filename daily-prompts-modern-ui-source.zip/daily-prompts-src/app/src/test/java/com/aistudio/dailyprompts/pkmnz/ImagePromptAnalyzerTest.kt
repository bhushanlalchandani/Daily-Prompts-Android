package com.aistudio.dailyprompts.pkmnz

import com.aistudio.dailyprompts.pkmnz.data.analyzer.ImagePromptAnalyzer
import com.aistudio.dailyprompts.pkmnz.data.analyzer.ImageTelemetry
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIProviderManager
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIProviderResult
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIPromptRequest
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIProvider
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIProviderError
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ImagePromptAnalyzerTest {

    @Test
    fun testFactualPromptGeneration_solelyVisualAttributes() {
        val telemetry = ImageTelemetry(
            width = 800,
            height = 1000,
            aspectRatioLabel = "Portrait",
            dominantColorHex = "#FFE0B2",
            colorTone = "Warm Peach & Amber",
            luminanceCategory = "Golden / Warm",
            estimatedSubjects = "Portrait / Scene",
            lightingStyle = "Golden-hour Sunlight"
        )

        val prompt = ImagePromptAnalyzer.buildFactualDescriptivePrompt(
            telemetry = telemetry,
            sampleId = "golden_hour_portrait"
        )

        // Must be non-empty, detailed and describe visual elements only
        assertNotNull(prompt)
        assertTrue(prompt.contains("Warm Peach & Amber", ignoreCase = true))
        assertTrue(prompt.contains("Golden-hour Sunlight", ignoreCase = true))
        assertTrue(prompt.contains("#FFE0B2", ignoreCase = true))
        assertTrue(prompt.contains("--ar 4:5", ignoreCase = true) || prompt.contains("Portrait", ignoreCase = true))
        org.junit.Assert.assertFalse("Must not contain hardcoded woman preset", prompt.contains("young adult woman", ignoreCase = true))
        org.junit.Assert.assertFalse("Must not contain hardcoded camisole", prompt.contains("camisole", ignoreCase = true))
        org.junit.Assert.assertFalse("Must not contain hardcoded window blinds", prompt.contains("window blinds", ignoreCase = true))
    }

    @Test
    fun testMultimodal_preservesImagePayload() = runBlocking {
        var receivedImageBase64: String? = null

        val gemini = object : AIProvider {
            override val name: String = "Gemini"
            override suspend fun generatePrompt(request: AIPromptRequest): AIProviderResult {
                receivedImageBase64 = request.imageBase64
                return AIProviderResult.Success(
                    text = "A detailed editorial portrait in golden sunlight.",
                    providerName = "Gemini"
                )
            }
        }

        val manager = AIProviderManager(geminiProvider = gemini)

        val imageRequest = AIPromptRequest(
            topic = "Analyze the uploaded image in depth and generate a rich, comprehensive, and detailed descriptive prompt.",
            imageBase64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=",
            imageMimeType = "image/png"
        )

        val result = manager.generatePrompt(imageRequest)
        assertTrue(result is AIProviderResult.Success)
        assertEquals("Gemini", (result as AIProviderResult.Success).providerName)
        assertEquals(imageRequest.imageBase64, receivedImageBase64)
    }

    @Test
    fun testSmartPromptEngine_analyzesUploadedImageElementsAndContext() {
        val topic = "Image: Portrait • Warm Peach & Amber • Golden / Warm • A young woman with curly hair wearing glasses smiling in a bookstore"
        val prompt = com.aistudio.dailyprompts.pkmnz.data.generator.SmartPromptEngine.buildProceduralPrompt(
            topic = topic,
            targetAi = "Midjourney / Vision",
            category = "Visual Art",
            style = "Descriptive"
        )

        // Must focus on the actual elements and context of the image
        assertNotNull(prompt)
        assertTrue("Must describe the woman", prompt.contains("woman", ignoreCase = true))
        assertTrue("Must describe curly hair", prompt.contains("curly", ignoreCase = true))
        assertTrue("Must describe the bookstore context", prompt.contains("bookstore", ignoreCase = true))
        assertTrue("Must describe the warm/golden lighting", prompt.contains("golden-hour", ignoreCase = true) || prompt.contains("warm", ignoreCase = true))
        assertTrue("Must incorporate amber/peach palette", prompt.contains("amber", ignoreCase = true) || prompt.contains("peach", ignoreCase = true))
        // Must avoid generic boilerplate prefixes
        org.junit.Assert.assertFalse("Must not contain repetitive boilerplate prefix", prompt.startsWith("A masterwork cinematic visual of"))
    }

    @Test
    fun testSmartPromptEngine_landscapeAndNatureElements() {
        val prompt = com.aistudio.dailyprompts.pkmnz.data.generator.SmartPromptEngine.generateImageDescriptivePrompt(
            aspectRatio = "Landscape",
            colorTone = "Vibrant Natural Green",
            dominantColorHex = "#C8E6C9",
            luminance = "Bright / High-Key",
            contextHint = "A snow-capped mountain ridge reflected in a calm alpine lake surrounded by pine trees"
        )

        assertNotNull(prompt)
        assertTrue(prompt.contains("mountain", ignoreCase = true))
        assertTrue(prompt.contains("lake", ignoreCase = true))
        assertTrue(prompt.contains("pine", ignoreCase = true))
        assertTrue(prompt.contains("wide-angle landscape", ignoreCase = true))
    }

    @Test
    fun testSmartPromptEngine_parseImageTopicAndContext() {
        val parsed = com.aistudio.dailyprompts.pkmnz.data.generator.SmartPromptEngine.parseImageTopicAndContext(
            topic = "Image: Landscape • Cool Cyan & Indigo • Moody / Low-Key • Wet Tokyo street at night with neon reflections"
        )

        assertEquals("Landscape", parsed.aspectRatio)
        assertEquals("Cool Cyan & Indigo", parsed.colorTone)
        assertEquals("Moody / Low-Key", parsed.luminance)
        assertNotNull(parsed.visualElements)
        assertTrue(parsed.visualElements!!.contains("Tokyo street", ignoreCase = true))
    }

    @Test
    fun testDynamicImageAnalysis_uploadedImage_reflectsColorsAndPatternsWithoutPreset() {
        val telemetry = ImageTelemetry(
            width = 1920,
            height = 1080,
            aspectRatioLabel = "Cinematic Widescreen (16:9)",
            dominantColorHex = "#1E3A8A",
            colorTone = "Cool Cobalt & Teal Indigo",
            luminanceCategory = "Moody / Low-Key",
            estimatedSubjects = "Coastal Scenery",
            lightingStyle = "Cool Atmospheric Twilight Ambient Light",
            paletteHexes = listOf("#1E3A8A", "#0D9488", "#111827"),
            colorNames = listOf("Cobalt Blue", "Vibrant Teal", "Slate Charcoal"),
            saturationLevel = "Natural True-to-Life Saturation",
            contrastLevel = "High Dynamic Contrast",
            visualPattern = "Horizontal Layering with Natural Horizon Depth",
            compositionStyle = "Expansive Wide-Angle Landscape Composition",
            detailDensity = "High-Frequency Textural Detail and Defined Edges"
        )

        val prompt = ImagePromptAnalyzer.buildFactualDescriptivePrompt(
            telemetry = telemetry,
            sampleId = null // Uploaded image (no preset)
        )

        assertNotNull(prompt)
        // Must contain the actual inspected attributes
        assertTrue("Must include color hex", prompt.contains("#1E3A8A"))
        assertTrue("Must include color tone", prompt.contains("Cool Cobalt & Teal Indigo", ignoreCase = true))
        assertTrue("Must include lighting style", prompt.contains("Cool Atmospheric Twilight", ignoreCase = true))
        assertTrue("Must include aspect ratio tag", prompt.contains("--ar 16:9"))
        assertTrue("Must include composition", prompt.contains("Wide-Angle", ignoreCase = true))

        // MUST NOT contain the hardcoded young woman preset
        org.junit.Assert.assertFalse("Must not contain hardcoded woman preset", prompt.contains("young adult woman", ignoreCase = true))
        org.junit.Assert.assertFalse("Must not contain hardcoded camisole", prompt.contains("camisole", ignoreCase = true))
        org.junit.Assert.assertFalse("Must not contain hardcoded window blinds", prompt.contains("window blinds", ignoreCase = true))
    }
}
