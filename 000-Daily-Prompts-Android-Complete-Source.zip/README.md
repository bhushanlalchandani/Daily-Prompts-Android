# Daily Prompts Android — fresh starter project

This is a clean Kotlin Android starter project with:
- Daily prompt selection (date-based)
- Gemini image analysis using `gemini-2.5-flash`
- Automatic OpenAI fallback to `gpt-4o-mini` when Gemini reports quota/rate-limit (429) or selected transient server errors
- Separate API-key fields and connection status
- Image picker and image analysis
- Human-readable API errors

## Build
Open this folder in Android Studio, let Gradle sync, then run:
`gradle assembleDebug`
APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## API setup
1. Create a Gemini API key in Google AI Studio.
2. Create an OpenAI API key on the OpenAI API platform and ensure API billing/usage is enabled if required.
3. Enter both keys in the app and tap **Update & Save Keys**.
4. Choose an image and tap **Analyze image (automatic fallback)**.

## Important limitations / security
- This is a starter source project, not a verified release APK. It has not been compiled in this environment.
- Keys are stored in app-local SharedPreferences for personal testing; this is not safe for a public production app. APKs can be reverse engineered. For a public release, route requests through a secure backend and store provider keys only on that backend.
- API calls may cost money. Set provider usage limits.
- Automatic fallback is attempted for Gemini 429, 408, 500 and 503 responses. Authentication/configuration errors are surfaced rather than silently switching providers.
- The app currently analyzes a chosen image; it does not generate an image itself.
