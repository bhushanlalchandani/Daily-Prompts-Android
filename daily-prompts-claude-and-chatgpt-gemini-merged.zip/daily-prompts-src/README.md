<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/e9e5684e-4acc-46d2-8263-737c4902f915

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.


## Maintenance notes

- API key settings now reject blank or obviously invalid keys consistently with the app's key-status state.
- Prompt enhancement no longer uses a Kotlin non-null assertion for the original topic.
- Debug builds use Android Gradle Plugin's default debug signing; release signing is enabled only when release keystore environment variables are supplied.
- Private signing keystores and local `.env` files must not be committed or shared. The keystore present in the uploaded archive was excluded from this revised source package.
- This environment did not include the Gradle wrapper scripts/JAR or an Android SDK, so a compiled APK and device tests could not be produced here. Open the project in Android Studio, sync Gradle, then run unit tests and build a debug APK.


## UI refresh

- New installs now use the existing Purple palette as the modern default; saved theme preferences remain respected.
- The home greeting uses a cleaner, bold sans-serif type treatment and refined spacing.
- Purple is available at the top of the theme picker.

## Patch notes (2026-10-23)
- Updated the primary Gemini model to `gemini-4-argon` (the model ID shown in the supplied Google AI Studio screenshot) and the fallback model to `gemini-2.5-flash`. The actual API connection must still be tested with the user’s own key.
- Disabled automatic OpenAI fallback in `MainActivity` so Image-to-Prompt requests remain on Gemini and do not show unrelated OpenAI quota errors.
- Restricted optional provider failover to Gemini quota/rate-limit failures. Model/endpoint errors such as HTTP 404 remain visible for diagnosis.
- This is a source patch only; it has not been compiled or tested on a device in this environment. Use Android Studio to sync and build, then test repeated image changes and prompt generation.

## Bug-fix pass (2026-10-23, static review)
- **AI replies were being thrown away**: text generation had a 4 s timeout around a blocking HTTP call, so any slower Gemini answer was discarded (and quota still consumed). Timeout is now 30 s and the HTTP call is cancellable (`GeminiProvider.awaitResponse`).
- **Empty / "No valid content" answers**: Gemini 2.5 "thinking" tokens ate the small `maxOutputTokens` budget. Thinking is disabled for these single-shot requests; all text parts are joined.
- **False "quota exceeded" errors**: rate-limit keywords were searched in *successful* response bodies too (Gemini + OpenAI). Now only error responses are judged.
- **API key no longer sent in the URL** (header only), so it cannot leak into logs.
- **Model fallback restored**: `GEMINI_FALLBACK = gemini-flash-latest` so a retired model ID (404) falls back instead of failing; one retry on 5xx. `AIFailoverTest.testModelConstantsIntegrity` passes again. API-key "Test connection" uses the same model list.
- **Seed library missing from Explore** for users who open the app once a day (daily roll skipped seed insertion); duplicate prompts are now filtered.
- **Image-to-Prompt**: picking another image now cancels the previous analysis, clears the old result and resets state (stale results could overwrite the new image). EXIF rotation is applied; transparent PNGs are flattened on white; wallpaper photos also honour EXIF rotation.
- **Favorites toggle** read a stale state flow when its screen was not visible; it now reads the database.
- **"Next prompt" got stuck** on seed prompts (all have id 0); now matches by text too.
- **Wrong category detection** ("manga", "human", "romantic" matched "man"): whole-word matching, with unit tests (`PeopleCategoryTest`).
- Snackbar messages are buffered (not lost during rotation); API-key minimum length aligned between settings and providers.
- Not compiled here (no Android SDK/Gradle). Run `./gradlew testDebugUnitTest assembleDebug` in Android Studio.

## Combined source update (October 2026)
- Combined the original full source project with the 12 files supplied in `changed-files-only.zip`.
- Set the Gemini primary model to `gemini-3.8-flash` and fallback to `gemini-3.5-flash-lite` (check availability for the specific API key/project before release).
- Updated model ID assertions in `AIFailoverTest.kt`.
- This source ZIP has not been built or verified against a live Gemini API key in this environment. Do not treat it as a confirmed working APK until CI build and live API tests pass.
