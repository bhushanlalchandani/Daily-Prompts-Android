package com.aistudio.dailyprompts.pkmnz.ui.components

import android.content.Context
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.dailyprompts.pkmnz.data.local.PromptEntity
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedBorder
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedButtonSecondary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedCardContainer
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedCardSurface
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedOnPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedTextLabel
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedTextPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedTextSecondary
import com.aistudio.dailyprompts.pkmnz.ui.i18n.AppStrings
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppLanguage
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppStrings

@Composable
fun PromptCard(
    prompt: PromptEntity,
    isRecentlyCopied: Boolean,
    onCopy: (Context, String, Long) -> Unit,
    onShare: (Context, String, String) -> Unit,
    onToggleFavorite: (Long, Boolean) -> Unit,
    onDislike: (PromptEntity) -> Unit,
    onEdit: (String) -> Unit,
    onDelete: ((Long) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val strings = LocalAppStrings.current
    val currentLanguage = LocalAppLanguage.current
    var isExpanded by remember { mutableStateOf(false) }

    val wordCount = remember(prompt.promptText) {
        prompt.promptText.trim().split("\\s+".toRegex()).count { it.isNotBlank() }
    }
    val charCount = remember(prompt.promptText) { prompt.promptText.length }

    val copyButtonBg by animateColorAsState(
        targetValue = if (isRecentlyCopied) Color(0xFF00C853) else SophisticatedPrimary,
        animationSpec = tween(durationMillis = 250),
        label = "copyButtonBg"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("prompt_card_${prompt.id}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = SophisticatedCardSurface
        ),
        border = BorderStroke(1.dp, SophisticatedBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header Row: Category Pill, Target AI Badge, Dislike & Favorite & Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // AI Target Badge
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = SophisticatedCardContainer,
                        border = BorderStroke(1.dp, SophisticatedBorder)
                    ) {
                        Text(
                            text = prompt.aiTool,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = SophisticatedPrimary
                        )
                    }

                    // Category
                    Text(
                        text = AppStrings.translate(prompt.category, currentLanguage),
                        style = MaterialTheme.typography.labelSmall,
                        color = SophisticatedTextSecondary
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    // Dislike Button
                    IconButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onDislike(prompt)
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("dislike_button_${prompt.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ThumbDown,
                            contentDescription = "Dislike prompt and block this type",
                            tint = SophisticatedTextSecondary,
                            modifier = Modifier.size(19.dp)
                        )
                    }

                    // Favorite Button
                    IconButton(
                        onClick = {
                            if (!prompt.isFavorite) {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            } else {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            }
                            onToggleFavorite(prompt.id, prompt.isFavorite)
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("favorite_button_${prompt.id}")
                    ) {
                        Icon(
                            imageVector = if (prompt.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Save to favorites",
                            tint = if (prompt.isFavorite) Color(0xFFEFB8C8) else SophisticatedTextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    if (onDelete != null) {
                        IconButton(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                onDelete(prompt.id)
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("delete_button_${prompt.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete prompt",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Title
            Text(
                text = prompt.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = SophisticatedTextPrimary
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Prompt Content Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(SophisticatedCardContainer)
                    .clickable { isExpanded = !isExpanded }
                    .padding(14.dp)
            ) {
                Column {
                    Text(
                        text = prompt.promptText,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 20.sp
                        ),
                        color = SophisticatedTextPrimary,
                        maxLines = if (isExpanded) Int.MAX_VALUE else 4,
                        overflow = TextOverflow.Ellipsis
                    )

                    if (prompt.promptText.length > 140) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isExpanded) "Tap to collapse ▲" else "Tap to see full prompt ▼",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = SophisticatedPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Word and Character stats
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$wordCount words • $charCount characters",
                    style = MaterialTheme.typography.labelSmall,
                    color = SophisticatedTextSecondary
                )

                if (prompt.tags.isNotBlank()) {
                    Text(
                        text = prompt.tags.split(",").take(2).joinToString(" • ") { it.trim() },
                        style = MaterialTheme.typography.labelSmall,
                        color = SophisticatedTextLabel
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Primary Action Bar: Big One-Tap Copy button + Share + Edit
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // One-Tap Copy Button (#D0BCFF with #381E72 text)
                Button(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onCopy(context, prompt.promptText, prompt.id)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 46.dp)
                        .testTag("copy_prompt_button_${prompt.id}"),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = copyButtonBg,
                        contentColor = if (isRecentlyCopied) Color.White else SophisticatedOnPrimary
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    AnimatedCopyContent(
                        isCopied = isRecentlyCopied,
                        normalText = strings.copyToClipboardBtn,
                        copiedText = strings.copiedSuccess,
                        iconSize = 18.dp,
                        spacing = 6.dp,
                        style = MaterialTheme.typography.labelLarge,
                        contentColor = if (isRecentlyCopied) Color.White else SophisticatedOnPrimary
                    )
                }

                // Share to Other Apps (Full 46dp touch area)
                Surface(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onShare(context, prompt.promptText, prompt.title)
                    },
                    shape = RoundedCornerShape(14.dp),
                    color = SophisticatedButtonSecondary,
                    modifier = Modifier
                        .size(46.dp)
                        .testTag("share_prompt_button_${prompt.id}")
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = strings.shareToOtherApps,
                            tint = SophisticatedTextPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Edit in Scratchpad (Full 46dp touch area)
                Surface(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onEdit(prompt.promptText)
                    },
                    shape = RoundedCornerShape(14.dp),
                    color = SophisticatedButtonSecondary,
                    modifier = Modifier
                        .size(46.dp)
                        .testTag("edit_button_${prompt.id}")
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = strings.edit,
                            tint = SophisticatedTextPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
