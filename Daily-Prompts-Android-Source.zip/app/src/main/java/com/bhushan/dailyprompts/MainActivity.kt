package com.bhushan.dailyprompts

import android.app.Activity
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MainActivity : Activity() {
    private val background = Color.rgb(16, 17, 26)
    private val card = Color.rgb(29, 31, 45)
    private val accent = Color.rgb(124, 131, 253)
    private val primaryText = Color.rgb(245, 246, 255)
    private val secondaryText = Color.rgb(177, 181, 202)

    private data class Prompt(val category: String, val title: String, val text: String)

    private val prompts = listOf(
        Prompt("Anime", "Rainy Neon Evening", "Cinematic anime illustration of a quiet Tokyo street at blue hour, a thoughtful young character under a transparent umbrella, glowing neon reflections on wet pavement, atmospheric rain, expressive eyes, detailed background, beautiful composition, high quality, no text, vertical 9:16."),
        Prompt("Fantasy", "Moonlit Forest", "A mysterious moonlit forest with ancient trees, floating fireflies, silver mist and a small stone path leading to a glowing lake, fantasy concept art, rich details, cinematic lighting, balanced composition, no text, vertical 9:16."),
        Prompt("Portrait", "Golden Hour Portrait", "Editorial portrait photograph of a person in soft golden-hour sunlight, natural skin texture, gentle expression, shallow depth of field, 85mm lens look, warm highlights and soft shadows, realistic photography, clean background, no text, vertical 4:5."),
        Prompt("Architecture", "Future City", "Futuristic sustainable city architecture at dusk, elegant glass towers, elevated gardens, subtle teal and amber lighting, realistic materials, wide cinematic perspective, highly detailed architectural visualization, no logos or text, 16:9."),
        Prompt("Nature", "Dreamy Waterfall", "A hidden waterfall flowing into a crystal-clear turquoise pool surrounded by lush moss, wildflowers and soft morning mist, realistic nature photography, gentle sunbeams, intricate natural textures, peaceful mood, no text, 4:5."),
        Prompt("Cyberpunk", "Midnight Balcony", "Cyberpunk city seen from a high-rise balcony at midnight, distant holographic lights, rain on glass, deep cobalt and magenta atmosphere, cinematic anime background, dramatic depth, detailed lighting, no readable text, vertical 9:16."),
        Prompt("Romance", "Under the Stars", "A tender romantic scene of two silhouettes standing on a quiet seaside cliff beneath a brilliant star-filled sky, moonlit ocean, soft wind, dreamy cinematic color grading, emotional atmosphere, beautiful composition, no text, 16:9."),
        Prompt("Minimal", "Floating Shapes", "Minimal 3D abstract composition of smooth floating geometric forms, soft lavender and cobalt palette, subtle ambient shadows, premium studio lighting, clean negative space, refined modern design, no text, square 1:1."),
        Prompt("Food", "Cozy Café", "A freshly brewed cappuccino and a flaky croissant on a wooden café table beside a rainy window, warm natural light, realistic food photography, delicate steam, crisp textures, inviting cozy mood, no text, 4:5."),
        Prompt("Space", "Violet Galaxy", "A breathtaking spiral galaxy in violet, cobalt and teal tones above a distant alien mountain range, luminous nebula clouds, tiny stars, cinematic science-fiction concept art, intricate detail, awe-inspiring scale, no text, vertical 9:16."),
        Prompt("Anime", "Cherry Blossom Train", "A beautiful anime scene of a local train passing cherry blossom trees in spring, petals drifting through the air, soft afternoon light, peaceful countryside, hand-painted background feel, detailed scenery, no text, 16:9."),
        Prompt("Fantasy", "Crystal Castle", "An elegant fantasy castle built from translucent crystals on a mountain above the clouds, sunrise scattering rainbow light through its towers, epic wide-angle view, intricate details, magical atmosphere, no text, 16:9."),
        Prompt("Portrait", "Monochrome Mood", "Black-and-white close-up portrait with expressive eyes, soft directional studio lighting, subtle film grain, rich tonal contrast, natural skin detail, timeless fine-art photography, uncluttered background, no text, 4:5."),
        Prompt("Nature", "Autumn Lane", "A quiet forest lane covered with red, amber and golden autumn leaves, sunlight filtering through tall trees, gentle morning haze, realistic landscape photography, peaceful mood, crisp detail, no people, 16:9."),
        Prompt("Cyberpunk", "Rainy Rooftop", "A lone figure on a futuristic rooftop overlooking a vast neon city after rain, reflective surfaces, deep blue shadows, pink and teal lights, cinematic framing, detailed anime illustration, no text, vertical 9:16.")
    )

    private var promptText: TextView? = null
    private var titleText: TextView? = null
    private var categoryText: TextView? = null
    private var currentIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = background
        window.navigationBarColor = background
        currentIndex = (LocalDate.now().toEpochDay().mod(prompts.size.toLong())).toInt()
        buildUi()
        showPrompt()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(background); isFillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(28))
        }
        scroll.addView(root)

        val brand = text("DAILY PROMPTS", 13f, accent, true).apply { letterSpacing = 0.14f }
        root.addView(brand)
        root.addView(text("Your creative spark, every day.", 27f, primaryText, true).apply {
            setPadding(0, dp(10), 0, dp(8))
        })
        root.addView(text("A fresh ready-to-copy prompt for your AI image generator.", 15f, secondaryText, false))

        val date = LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy"))
        root.addView(text(date, 13f, secondaryText, false).apply {
            setPadding(0, dp(22), 0, dp(14))
        })

        val promptCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(20))
            setBackgroundColor(card)
        }
        root.addView(promptCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })

        categoryText = text("TODAY'S PROMPT", 12f, accent, true).apply { letterSpacing = 0.08f }
        promptCard.addView(categoryText)
        titleText = text("", 23f, primaryText, true).apply { setPadding(0, dp(12), 0, dp(12)) }
        promptCard.addView(titleText)
        promptText = text("", 16f, secondaryText, false).apply { setLineSpacing(dp(4), 1.0f) }
        promptCard.addView(promptText)

        root.addView(actionButton("Copy prompt", accent) { copyPrompt() }, fullWidthButton())
        root.addView(actionButton("Share prompt", Color.rgb(53, 57, 78)) { sharePrompt() }, fullWidthButton().apply { topMargin = dp(10) })
        root.addView(actionButton("Browse next prompt", Color.rgb(53, 57, 78)) {
            currentIndex = (currentIndex + 1) % prompts.size
            showPrompt()
        }, fullWidthButton().apply { topMargin = dp(10) })

        root.addView(text("PROMPT LIBRARY", 12f, accent, true).apply {
            letterSpacing = 0.12f
            setPadding(0, dp(26), 0, dp(12))
        })
        prompts.forEachIndexed { index, prompt ->
            val row = TextView(this).apply {
                text = "${prompt.category}  ·  ${prompt.title}"
                textSize = 15f
                setTextColor(primaryText)
                setPadding(dp(14), dp(15), dp(14), dp(15))
                setBackgroundColor(card)
                setOnClickListener {
                    currentIndex = index
                    showPrompt()
                    scroll.smoothScrollTo(0, 0)
                }
            }
            root.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        }
        setContentView(scroll)
    }

    private fun showPrompt() {
        val prompt = prompts[currentIndex]
        categoryText?.text = "${prompt.category.uppercase()}  •  TODAY'S PROMPT"
        titleText?.text = prompt.title
        promptText?.text = prompt.text
    }

    private fun copyPrompt() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("AI image prompt", prompts[currentIndex].text))
        Toast.makeText(this, "Prompt copied", Toast.LENGTH_SHORT).show()
    }

    private fun sharePrompt() {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, prompts[currentIndex].text)
        }
        startActivity(Intent.createChooser(intent, "Share prompt"))
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun actionButton(label: String, color: Int, action: () -> Unit) =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(color))
            setOnClickListener { action() }
        }

    private fun fullWidthButton() = LinearLayout.LayoutParams(-1, dp(52))
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
