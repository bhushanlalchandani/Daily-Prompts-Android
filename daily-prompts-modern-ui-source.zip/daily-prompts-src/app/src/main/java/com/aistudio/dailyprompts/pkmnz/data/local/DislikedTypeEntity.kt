package com.aistudio.dailyprompts.pkmnz.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "disliked_types")
data class DislikedTypeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val category: String,
    val tagOrKeyword: String = "",
    val promptTitle: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
