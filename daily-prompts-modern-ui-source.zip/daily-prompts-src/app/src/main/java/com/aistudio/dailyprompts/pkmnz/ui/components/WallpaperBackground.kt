package com.aistudio.dailyprompts.pkmnz.ui.components

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import com.aistudio.dailyprompts.pkmnz.data.cover.WallpaperPreset
import com.aistudio.dailyprompts.pkmnz.data.cover.WallpaperPresets
import com.aistudio.dailyprompts.pkmnz.data.cover.WallpaperState
import com.aistudio.dailyprompts.pkmnz.data.cover.WallpaperType
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedBackground
import java.io.File

/**
 * Renders the application background based on the current [WallpaperState].
 *
 * Supports:
 * - Default Minimalist Obsidian
 * - Curated Aesthetic Presets (vector multi-stop brush + ambient lighting)
 * - Custom User Wallpaper (subsampled & safely loaded from local storage)
 * - User-configurable dimming veil for optimal text contrast and readability
 */
@Composable
fun WallpaperBackground(
    wallpaperState: WallpaperState,
    modifier: Modifier = Modifier
) {
    Crossfade(
        targetState = wallpaperState.type,
        animationSpec = tween(durationMillis = 350),
        label = "wallpaper_crossfade",
        modifier = modifier
    ) { type ->
        when (type) {
            WallpaperType.DEFAULT -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(SophisticatedBackground)
                )
            }

            WallpaperType.PRESET -> {
                val preset = WallpaperPresets.getPreset(wallpaperState.presetId)
                    ?: WallpaperPresets.PRESETS.first()
                PresetWallpaperCanvas(
                    preset = preset,
                    dimLevel = wallpaperState.dimLevel
                )
            }

            WallpaperType.CUSTOM -> {
                CustomPhotoWallpaperCanvas(
                    photoPath = wallpaperState.customPhotoPath,
                    dimLevel = wallpaperState.dimLevel,
                    timestamp = wallpaperState.updateTimestamp
                )
            }
        }
    }
}

@Composable
fun PresetWallpaperCanvas(
    preset: WallpaperPreset,
    dimLevel: Float,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        // Base multi-stop gradient
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = preset.gradientColors
                    )
                )
        )

        // Radial ambient highlight in upper quadrant for rich atmospheric depth
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            preset.accentColor.copy(alpha = 0.30f),
                            preset.accentColor.copy(alpha = 0.10f),
                            Color.Transparent
                        ),
                        center = Offset(800f, 200f),
                        radius = 1100f
                    )
                )
        )

        // Secondary bottom corner atmospheric reflection
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            preset.accentColor.copy(alpha = 0.15f),
                            Color.Transparent
                        ),
                        center = Offset(200f, 1800f),
                        radius = 900f
                    )
                )
        )

        // User-controlled contrast dimming veil
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(SophisticatedBackground.copy(alpha = dimLevel))
        )
    }
}

@Composable
fun CustomPhotoWallpaperCanvas(
    photoPath: String?,
    dimLevel: Float,
    timestamp: Long,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        if (photoPath != null && File(photoPath).exists()) {
            key(timestamp) {
                AsyncImage(
                    model = File(photoPath),
                    contentDescription = "Custom Wallpaper",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        } else {
            // Fallback if file missing
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SophisticatedBackground)
            )
        }

        // Contrast dimming veil
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(SophisticatedBackground.copy(alpha = dimLevel))
        )
    }
}
