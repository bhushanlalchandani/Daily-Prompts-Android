package com.aistudio.dailyprompts.pkmnz.data.local

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.aistudio.dailyprompts.pkmnz.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Securely manages user-configured API keys.
 *
 * Uses EncryptedSharedPreferences backed by Android Keystore (AES-256 GCM).
 * Keys are never logged and are read on-demand only when initiating network requests.
 */
class ApiKeyManager(context: Context) {

    private val prefs: SharedPreferences = try {
        val masterKey = MasterKey.Builder(context.applicationContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context.applicationContext,
            "secure_user_keys",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (_: Exception) {
        // Fallback for JVM Robolectric tests or devices where Keystore initialization is restricted
        context.applicationContext.getSharedPreferences("secure_user_keys_fallback", Context.MODE_PRIVATE)
    }

    private val _hasGeminiKey = MutableStateFlow(getGeminiApiKey().isNotBlank())
    val hasGeminiKey: StateFlow<Boolean> = _hasGeminiKey.asStateFlow()

    private val _hasOpenAIKey = MutableStateFlow(getOpenAIApiKey().isNotBlank())
    val hasOpenAIKey: StateFlow<Boolean> = _hasOpenAIKey.asStateFlow()

    private val _preferredProvider = MutableStateFlow(getPreferredProvider())
    val preferredProvider: StateFlow<String> = _preferredProvider.asStateFlow()

    fun getPreferredProvider(): String {
        return prefs.getString(KEY_PREFERRED_PROVIDER, "gemini") ?: "gemini"
    }

    fun setPreferredProvider(provider: String) {
        val clean = provider.trim().lowercase()
        prefs.edit().putString(KEY_PREFERRED_PROVIDER, clean).apply()
        _preferredProvider.value = clean
    }

    /**
     * Reads the stored Gemini API key on-demand without logging.
     * Checks user preferences first, then securely injected BuildConfig / environment.
     */
    fun getGeminiApiKey(): String {
        val userKey = prefs.getString(KEY_GEMINI, "")?.trim().orEmpty()
        if (userKey.isNotBlank() && isKeyFormatValid(userKey)) return userKey
        val buildConfigKey = try { BuildConfig.GEMINI_API_KEY.trim() } catch (_: Throwable) { "" }
        if (buildConfigKey.isNotBlank() && buildConfigKey != "null" && isKeyFormatValid(buildConfigKey)) {
            return buildConfigKey
        }
        val envKey = try { System.getenv("GEMINI_API_KEY")?.trim().orEmpty() } catch (_: Throwable) { "" }
        if (envKey.isNotBlank() && isKeyFormatValid(envKey)) {
            return envKey
        }
        return ""
    }

    /**
     * Reads the stored OpenAI API key on-demand without logging.
     */
    fun getOpenAIApiKey(): String {
        val userKey = prefs.getString(KEY_OPENAI, "")?.trim().orEmpty()
        if (userKey.isNotBlank() && isKeyFormatValid(userKey)) return userKey
        val buildConfigKey = try {
            val field = BuildConfig::class.java.getField("OPENAI_API_KEY")
            (field.get(null) as? String)?.trim().orEmpty()
        } catch (_: Throwable) { "" }
        if (buildConfigKey.isNotBlank() && buildConfigKey != "null" && isKeyFormatValid(buildConfigKey)) {
            return buildConfigKey
        }
        val envKey = try { System.getenv("OPENAI_API_KEY")?.trim().orEmpty() } catch (_: Throwable) { "" }
        if (envKey.isNotBlank() && isKeyFormatValid(envKey)) {
            return envKey
        }
        return ""
    }

    /**
     * Saves the user-supplied Gemini API key securely.
     */
    fun setGeminiApiKey(key: String) {
        val cleanKey = key.trim()
        prefs.edit().putString(KEY_GEMINI, cleanKey).apply()
        _hasGeminiKey.value = cleanKey.isNotBlank()
    }

    /**
     * Removes the stored Gemini API key.
     */
    fun clearGeminiApiKey() {
        prefs.edit().remove(KEY_GEMINI).apply()
        _hasGeminiKey.value = false
    }

    /**
     * Checks if a Gemini key is configured.
     */
    fun isGeminiKeyConfigured(): Boolean {
        return getGeminiApiKey().isNotBlank()
    }

    /**
     * Saves the user-supplied OpenAI API key securely.
     */
    fun setOpenAIApiKey(key: String) {
        val cleanKey = key.trim()
        prefs.edit().putString(KEY_OPENAI, cleanKey).apply()
        _hasOpenAIKey.value = cleanKey.isNotBlank()
    }

    /**
     * Removes the stored OpenAI API key.
     */
    fun clearOpenAIApiKey() {
        prefs.edit().remove(KEY_OPENAI).apply()
        _hasOpenAIKey.value = false
    }

    /**
     * Checks if an OpenAI key is configured.
     */
    fun isOpenAIKeyConfigured(): Boolean {
        return getOpenAIApiKey().isNotBlank()
    }

    companion object {
        private const val KEY_GEMINI = "user_gemini_api_key_secure"
        private const val KEY_OPENAI = "user_openai_api_key_secure"
        private const val KEY_PREFERRED_PROVIDER = "user_preferred_ai_provider"

        /**
         * Validates key format (basic sanity check without logging the key).
         */
        fun isKeyFormatValid(key: String): Boolean {
            val trimmed = key.trim()
            return trimmed.isNotBlank() &&
                    !trimmed.contains("placeholder", ignoreCase = true) &&
                    !trimmed.startsWith("MY_") &&
                    !trimmed.contains("NOT_SET") &&
                    trimmed.length >= 10
        }
    }
}
