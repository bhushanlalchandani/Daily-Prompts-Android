package com.aistudio.dailyprompts.pkmnz.data.remote.ai

/** Central model IDs used by Gemini requests. */
object AIModels {
    // Use a supported Gemini model for text and image-to-prompt requests.
    const val GEMINI_PRIMARY = "gemini-2.5-flash"
    const val GEMINI_FALLBACK = "gemini-2.5-flash"
    const val OPENAI_DEFAULT = "gpt-4o-mini"

    // Avoid retrying the same model twice after a model-not-found response.
    val GEMINI_MODELS = listOf(GEMINI_PRIMARY).distinct()
}
