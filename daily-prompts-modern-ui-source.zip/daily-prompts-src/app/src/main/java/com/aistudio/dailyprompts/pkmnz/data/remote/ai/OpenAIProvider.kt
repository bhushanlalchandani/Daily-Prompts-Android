package com.aistudio.dailyprompts.pkmnz.data.remote.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

class OpenAIProvider(
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(45, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(45, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build(),
    private val apiKeyProvider: () -> String = { "" },
    private val baseUrl: String = "https://api.openai.com/"
) : AIProvider {

    override val name: String = "OpenAI"

    override suspend fun generatePrompt(request: AIPromptRequest): AIProviderResult = withContext(Dispatchers.IO) {
        val apiKey = apiKeyProvider().trim()
        if (!isKeyValid(apiKey)) {
            return@withContext AIProviderResult.Failure(
                AIProviderError.KeyMissing(name, "OpenAI API key is not configured.")
            )
        }

        val relevantDislikes = request.dislikedTypes.filter { disliked ->
            !request.topic.contains(disliked, ignoreCase = true) &&
                    !request.category.contains(disliked, ignoreCase = true)
        }

        val negativeConstraint = if (relevantDislikes.isNotEmpty()) {
            "\nCRITICAL USER PREFERENCE: The user has disliked and blocked the following types/categories: ${relevantDislikes.joinToString(", ")}. NEVER generate a prompt belonging to or resembling these blocked categories or styles."
        } else ""

        val systemPrompt = request.systemPrompt ?: """
            You are an elite Prompt Engineer. Your task is to generate a single, master-crafted, copy-paste ready prompt for ${request.targetAi}.
            The prompt must be exceptionally detailed, effective, and ready for the user to copy directly into ${request.targetAi} to get top-tier results.
            Category: ${request.category}
            Style / Tone: ${request.style}$negativeConstraint
            Do not include conversational filler like 'Here is your prompt' or 'Sure!'.
            Return ONLY the exact prompt text ready to be copied and pasted.
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("model", AIModels.OPENAI_DEFAULT)
            put("temperature", request.temperature)
            put("max_tokens", request.maxTokens)

            val messagesArray = JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "system")
                    put("content", systemPrompt)
                })

                if (request.imageBase64.isNullOrBlank()) {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("content", "Create an advanced, high-performing prompt for: ${request.topic}")
                    })
                } else {
                    val userContentArray = JSONArray().apply {
                        put(JSONObject().apply {
                            put("type", "text")
                            put("text", request.topic)
                        })
                        put(JSONObject().apply {
                            put("type", "image_url")
                            put("image_url", JSONObject().apply {
                                val mime = request.imageMimeType ?: "image/jpeg"
                                put("url", "data:$mime;base64,${request.imageBase64}")
                            })
                        })
                    }
                    put(JSONObject().apply {
                        put("role", "user")
                        put("content", userContentArray)
                    })
                }
            }
            put("messages", messagesArray)
        }

        val mediaType = "application/json; charset=utf-8".toMediaType()
        val requestBody = jsonBody.toString().toRequestBody(mediaType)
        val endpoint = "${baseUrl.trimEnd('/')}/v1/chat/completions"

        val httpRequest = Request.Builder()
            .url(endpoint)
            .addHeader("Authorization", "Bearer $apiKey")
            .post(requestBody)
            .build()

        try {
            httpClient.newCall(httpRequest).execute().use { response ->
                val code = response.code
                val rawBody = response.body?.string().orEmpty()
                val lowerBody = rawBody.lowercase()

                if (code == 429 || lowerBody.contains("insufficient_quota") || lowerBody.contains("rate_limit")) {
                    return@withContext AIProviderResult.Failure(
                        AIProviderError.QuotaExhausted(name, "OpenAI quota or rate limit exceeded: $rawBody")
                    )
                }

                if (!response.isSuccessful) {
                    if (code == 401) {
                        return@withContext AIProviderResult.Failure(
                            AIProviderError.InvalidApiKey(name, "OpenAI API key is invalid or unauthorized.")
                        )
                    }
                    if (code == 400 && (lowerBody.contains("policy") || lowerBody.contains("moderation") || lowerBody.contains("content_policy"))) {
                        return@withContext AIProviderResult.Failure(
                            AIProviderError.PolicyRefusal(name, "OpenAI generation refused due to content safety.")
                        )
                    }
                    if (code in 500..599) {
                        return@withContext AIProviderResult.Failure(
                            AIProviderError.ServerError(name, code, "OpenAI server error ($code)")
                        )
                    }
                    return@withContext AIProviderResult.Failure(
                        AIProviderError.GeneralError(name, "OpenAI API error ($code): $rawBody")
                    )
                }

                if (rawBody.isBlank()) {
                    return@withContext AIProviderResult.Failure(
                        AIProviderError.GeneralError(name, "Empty response body from OpenAI.")
                    )
                }

                val json = JSONObject(rawBody)
                val choices = json.optJSONArray("choices")
                if (choices != null && choices.length() > 0) {
                    val firstChoice = choices.getJSONObject(0)
                    val message = firstChoice.optJSONObject("message")
                    val content = message?.optString("content")
                    if (!content.isNullOrBlank()) {
                        return@withContext AIProviderResult.Success(content.trim(), name)
                    }
                }

                AIProviderResult.Failure(
                    AIProviderError.GeneralError(name, "No valid content candidates returned by OpenAI.")
                )
            }
        } catch (e: UnknownHostException) {
            AIProviderResult.Failure(AIProviderError.NetworkError(name, "No internet connection: ${e.message}"))
        } catch (e: ConnectException) {
            AIProviderResult.Failure(AIProviderError.NetworkError(name, "Could not connect to OpenAI: ${e.message}"))
        } catch (e: SocketTimeoutException) {
            AIProviderResult.Failure(AIProviderError.NetworkError(name, "OpenAI request timed out."))
        } catch (e: IOException) {
            AIProviderResult.Failure(AIProviderError.NetworkError(name, e.message ?: "Network I/O error"))
        } catch (e: Exception) {
            AIProviderResult.Failure(AIProviderError.GeneralError(name, e.message ?: "Unexpected error"))
        }
    }

    private fun isKeyValid(key: String): Boolean {
        return key.isNotBlank() &&
                !key.contains("NOT_SET") &&
                !key.startsWith("MY_") &&
                !key.contains("placeholder", ignoreCase = true) &&
                key.length >= 15
    }
}
