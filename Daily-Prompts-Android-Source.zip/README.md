# Daily Prompts Android

A lightweight native Android app that displays a date-based daily AI image prompt, lets users copy or share it, and includes a built-in prompt library.

## Features
- Daily prompt selected from the current date
- Prompt categories and a browseable prompt library
- Copy and share actions
- Dark, mobile-friendly interface
- No API key, account, or internet permission required

## Build
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- JDK 17
- Compile SDK 35
- Minimum Android SDK 23

Open this folder in Android Studio, or use the included GitHub Actions workflow to build a debug APK.
