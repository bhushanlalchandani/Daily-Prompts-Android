package com.aistudio.dailyprompts.pkmnz.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.aistudio.dailyprompts.pkmnz.data.cover.WallpaperPreset
import com.aistudio.dailyprompts.pkmnz.data.cover.WallpaperPresets
import com.aistudio.dailyprompts.pkmnz.data.cover.WallpaperType
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedBackground
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedBorder
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedButtonSecondary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedCardContainer
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedCardSurface
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedOnPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedTextLabel
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedTextPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.SophisticatedTextSecondary
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.PromptViewModel
import java.io.File
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppearanceBottomSheet(
    viewModel: PromptViewModel,
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val wallpaperState by viewModel.wallpaperState.collectAsStateWithLifecycle()

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri: Uri? ->
            if (uri != null) {
                viewModel.setCoverPhoto(uri) { success ->
                    if (success) {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    }
                }
            }
        }
    )

    // Fallback file picker in case PickVisualMedia is restricted on certain emulator environments
    val fileChooserLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri: Uri? ->
            if (uri != null) {
                viewModel.setCoverPhoto(uri) { success ->
                    if (success) {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    }
                }
            }
        }
    )

    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        sheetState = sheetState,
        containerColor = SophisticatedCardSurface,
        dragHandle = { BottomSheetDefaults.DragHandle(color = SophisticatedBorder) },
        modifier = modifier.testTag("appearance_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = CircleShape,
                    color = SophisticatedCardContainer,
                    border = BorderStroke(1.dp, SophisticatedBorder),
                    modifier = Modifier.size(44.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Outlined.Palette,
                            contentDescription = "Appearance",
                            tint = SophisticatedPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Column {
                    Text(
                        text = "Appearance & Wallpapers",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SophisticatedTextPrimary
                    )
                    Text(
                        text = "Personalize your app background and contrast",
                        style = MaterialTheme.typography.bodySmall,
                        color = SophisticatedTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Live Preview Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .testTag("cover_photo_preview_card"),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, SophisticatedBorder),
                colors = CardDefaults.cardColors(containerColor = SophisticatedCardContainer)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    when (wallpaperState.type) {
                        WallpaperType.PRESET -> {
                            val preset = WallpaperPresets.getPreset(wallpaperState.presetId)
                                ?: WallpaperPresets.PRESETS.first()
                            PresetWallpaperCanvas(
                                preset = preset,
                                dimLevel = wallpaperState.dimLevel
                            )
                        }

                        WallpaperType.CUSTOM -> {
                            CustomPhotoWallpaperCanvas(
                                photoPath = wallpaperState.customPhotoPath,
                                dimLevel = wallpaperState.dimLevel,
                                timestamp = wallpaperState.updateTimestamp
                            )
                        }

                        WallpaperType.DEFAULT -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(
                                                SophisticatedCardContainer,
                                                SophisticatedBackground
                                            )
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DarkMode,
                                        contentDescription = null,
                                        tint = SophisticatedTextSecondary,
                                        modifier = Modifier.size(32.dp)
                                    )
                                    Text(
                                        text = "Minimalist Obsidian Active",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium,
                                        color = SophisticatedTextSecondary
                                    )
                                }
                            }
                        }
                    }

                    // Status Badge in top corner
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (wallpaperState.type != WallpaperType.DEFAULT) SophisticatedPrimary else SophisticatedButtonSecondary,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = if (wallpaperState.type != WallpaperType.DEFAULT) SophisticatedOnPrimary else SophisticatedTextPrimary,
                                modifier = Modifier.size(12.dp)
                            )
                            val label = when (wallpaperState.type) {
                                WallpaperType.PRESET -> {
                                    val name = WallpaperPresets.getPreset(wallpaperState.presetId)?.name ?: "Preset"
                                    "$name Active"
                                }
                                WallpaperType.CUSTOM -> "Custom Photo Active"
                                WallpaperType.DEFAULT -> "Obsidian Dark"
                            }
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (wallpaperState.type != WallpaperType.DEFAULT) SophisticatedOnPrimary else SophisticatedTextPrimary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Curated Preset Wallpapers Section
            Text(
                text = "CURATED AESTHETIC PRESETS",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.1.sp,
                color = SophisticatedTextLabel
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Horizontal Presets Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Default Obsidian Preset Button
                val isDefaultSelected = (wallpaperState.type == WallpaperType.DEFAULT)
                PresetChip(
                    name = "Obsidian",
                    subtitle = "Default Dark",
                    brush = Brush.verticalGradient(listOf(Color(0xFF16181D), Color(0xFF0D0E11))),
                    isSelected = isDefaultSelected,
                    accentColor = SophisticatedPrimary,
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        viewModel.removeCoverPhoto()
                    }
                )

                // Render all 7 curated aesthetic presets
                WallpaperPresets.PRESETS.forEach { preset ->
                    val isSelected = (wallpaperState.type == WallpaperType.PRESET && wallpaperState.presetId == preset.id)
                    PresetChip(
                        name = preset.name,
                        subtitle = preset.subtitle,
                        brush = Brush.verticalGradient(preset.gradientColors),
                        isSelected = isSelected,
                        accentColor = preset.accentColor,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            viewModel.setWallpaperPreset(preset.id)
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Custom Photo Section
            Text(
                text = "CUSTOM PHOTO WALLPAPER",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.1.sp,
                color = SophisticatedTextLabel
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        try {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        } catch (_: Exception) {
                            fileChooserLauncher.launch("image/*")
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("choose_cover_photo_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SophisticatedPrimary,
                        contentColor = SophisticatedOnPrimary
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = if (wallpaperState.type == WallpaperType.CUSTOM) Icons.Default.Edit else Icons.Default.AddPhotoAlternate,
                        contentDescription = "Upload Custom Photo",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (wallpaperState.type == WallpaperType.CUSTOM) "Change Photo" else "Upload Custom Photo",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (wallpaperState.type != WallpaperType.DEFAULT) {
                    OutlinedButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            viewModel.removeCoverPhoto()
                        },
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("remove_cover_photo_button"),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, SophisticatedBorder),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = SophisticatedTextSecondary
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Reset to Default",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Reset",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Wallpaper Dimming Slider (only visible when wallpaper is active)
            AnimatedVisibility(visible = wallpaperState.type != WallpaperType.DEFAULT) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = null,
                                tint = SophisticatedPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "WALLPAPER CONTRAST / DIM LEVEL",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.1.sp,
                                color = SophisticatedTextLabel
                            )
                        }

                        Text(
                            text = "${((1f - wallpaperState.dimLevel) * 100).roundToInt()}% Visibility",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = SophisticatedPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Slider(
                        value = wallpaperState.dimLevel,
                        onValueChange = { viewModel.setWallpaperDimLevel(it) },
                        valueRange = 0.20f..0.85f,
                        colors = SliderDefaults.colors(
                            thumbColor = SophisticatedPrimary,
                            activeTrackColor = SophisticatedPrimary,
                            inactiveTrackColor = SophisticatedBorder
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("wallpaper_dim_slider")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Vivid Wallpaper",
                            style = MaterialTheme.typography.labelSmall,
                            color = SophisticatedTextSecondary,
                            fontSize = 10.sp
                        )
                        Text(
                            text = "Dark / Subtle",
                            style = MaterialTheme.typography.labelSmall,
                            color = SophisticatedTextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Preset wallpapers apply instantly with zero network load. Custom photos are locally downsampled for maximum speed and memory efficiency.",
                style = MaterialTheme.typography.bodySmall,
                color = SophisticatedTextSecondary,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }
    }
}

@Composable
private fun PresetChip(
    name: String,
    subtitle: String,
    brush: Brush,
    isSelected: Boolean,
    accentColor: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(110.dp)
            .height(115.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .then(
                if (isSelected) {
                    Modifier.border(2.dp, accentColor, RoundedCornerShape(14.dp))
                } else {
                    Modifier.border(1.dp, SophisticatedBorder, RoundedCornerShape(14.dp))
                }
            ),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SophisticatedCardContainer)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Preset preview background
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(brush)
            )

            // Subtle dark shade at bottom for label legibility
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))
                        )
                    )
            )

            // Selected checkmark in top-right
            if (isSelected) {
                Surface(
                    shape = CircleShape,
                    color = accentColor,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .size(20.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Selected",
                            tint = Color.Black,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }

            // Name and Subtitle
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
            ) {
                Text(
                    text = name,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.75f),
                    fontSize = 9.sp,
                    maxLines = 1
                )
            }
        }
    }
}
