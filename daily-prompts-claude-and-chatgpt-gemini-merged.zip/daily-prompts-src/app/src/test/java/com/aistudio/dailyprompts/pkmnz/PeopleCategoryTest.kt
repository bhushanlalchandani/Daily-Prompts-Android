package com.aistudio.dailyprompts.pkmnz

import com.aistudio.dailyprompts.pkmnz.data.model.PromptCategory
import com.aistudio.dailyprompts.pkmnz.data.repository.detectPeopleCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PeopleCategoryTest {

    @Test
    fun detectsGirlAndBoyAsWholeWords() {
        assertEquals(PromptCategory.GIRL.displayName, detectPeopleCategory("beautiful girl in rain"))
        assertEquals(PromptCategory.GIRL.displayName, detectPeopleCategory("a young Woman portrait"))
        assertEquals(PromptCategory.BOY.displayName, detectPeopleCategory("cool boy with a car"))
        assertEquals(PromptCategory.BOY.displayName, detectPeopleCategory("a man at night"))
    }

    @Test
    fun doesNotMatchInsideOtherWords() {
        assertNull(detectPeopleCategory("manga style city"))
        assertNull(detectPeopleCategory("human anatomy study"))
        assertNull(detectPeopleCategory("romantic sunset"))
        assertNull(detectPeopleCategory("mango smoothie recipe"))
    }
}
