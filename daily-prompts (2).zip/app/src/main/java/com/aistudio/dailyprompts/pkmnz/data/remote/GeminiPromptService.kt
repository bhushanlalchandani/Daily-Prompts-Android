package com.aistudio.dailyprompts.pkmnz.data.remote

import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIProviderManager
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIProviderResult
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIPromptRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed class GeminiError(message: String) : Exception(message) {
    object NoInternet : GeminiError("No internet connection. Please check your network and try again.")
    object Timeout : GeminiError("The AI request timed out. Please try again.")
    object RateLimited : GeminiError("AI service is busy right now (rate limit). Please wait a moment.")
    class InvalidApiKey(message: String = "Gemini API key is invalid or unauthorized.") : GeminiError(message)
    class ApiError(val code: Int, message: String) : GeminiError("AI Service error ($code): $message")
    class InvalidResponse(message: String) : GeminiError(message)
    object KeyMissing : GeminiError("Gemini API key is not configured.")
}

/**
 * Clean interface abstraction for AI Prompt generation.
 */
interface PromptAiService {
    suspend fun generatePrompt(
        topic: String,
        targetAi: String,
        category: String,
        style: String,
        dislikedTypes: List<String> = emptyList()
    ): Result<String>

    suspend fun generatePromptWithProvider(
        topic: String,
        targetAi: String,
        category: String,
        style: String,
        dislikedTypes: List<String> = emptyList()
    ): Result<Pair<String, String>> = generatePrompt(topic, targetAi, category, style, dislikedTypes).map { it to "AI" }

    suspend fun analyzeImagePrompt(
        imageBase64: String,
        imageMimeType: String = "image/jpeg",
        customInstructions: String? = null
    ): Result<String>

    suspend fun analyzeImagePromptWithProvider(
        imageBase64: String,
        imageMimeType: String = "image/jpeg",
        customInstructions: String? = null
    ): Result<Pair<String, String>> = analyzeImagePrompt(imageBase64, imageMimeType, customInstructions).map { it to "AI" }
}

class GeminiPromptService(
    private val aiProviderManager: AIProviderManager = AIProviderManager()
) : PromptAiService {

    override suspend fun generatePromptWithProvider(
        topic: String,
        targetAi: String,
        category: String,
        style: String,
        dislikedTypes: List<String>
    ): Result<Pair<String, String>> = withContext(Dispatchers.IO) {
        val request = AIPromptRequest(
            topic = topic,
            targetAi = targetAi,
            category = category,
            style = style,
            dislikedTypes = dislikedTypes,
            temperature = 0.65,
            maxTokens = 350
        )

        val result = aiProviderManager.generatePrompt(request)
        when (result) {
            is AIProviderResult.Success -> Result.success(result.text to result.providerName)
            is AIProviderResult.Failure -> Result.failure(result.error)
        }
    }

    override suspend fun generatePrompt(
        topic: String,
        targetAi: String,
        category: String,
        style: String,
        dislikedTypes: List<String>
    ): Result<String> = generatePromptWithProvider(topic, targetAi, category, style, dislikedTypes).map { it.first }

    override suspend fun analyzeImagePromptWithProvider(
        imageBase64: String,
        imageMimeType: String,
        customInstructions: String?
    ): Result<Pair<String, String>> = withContext(Dispatchers.IO) {
        val topic = customInstructions?.ifBlank { null }
            ?: "Analyze the uploaded image in depth and generate a rich, comprehensive, and detailed descriptive prompt. This prompt MUST be based SOLELY on the visual details present in the image. Do NOT add any external information, imaginary elements, or details not visible in the image. Focus only on describing the actual subjects, actions, lighting, colors, background, and other visual elements within the provided image to create a factual description that can be used to recreate the scene."

        val systemPrompt = """
            You are a master Vision AI and reverse-prompt engineer.
            Analyze the provided image in depth and generate a rich, comprehensive, and detailed descriptive prompt.
            This prompt MUST be based SOLELY on the visual details present in the image.
            Do NOT add any external information, imaginary elements, or details not visible in the image.
            Focus only on describing the actual subjects, actions, lighting, colors, background, and other visual elements within the provided image to create a factual description that can be used to recreate the scene.
            Return ONLY the descriptive prompt text ready to be copied and used.
        """.trimIndent()

        val request = AIPromptRequest(
            topic = topic,
            targetAi = "Midjourney / Stable Diffusion / DALL-E",
            category = "AI Art & Image",
            style = "Photorealistic & Detailed",
            systemPrompt = systemPrompt,
            imageBase64 = imageBase64,
            imageMimeType = imageMimeType,
            temperature = 0.4,
            maxTokens = 1200
        )

        val result = aiProviderManager.generatePrompt(request)
        when (result) {
            is AIProviderResult.Success -> Result.success(result.text to result.providerName)
            is AIProviderResult.Failure -> Result.failure(result.error)
        }
    }

    override suspend fun analyzeImagePrompt(
        imageBase64: String,
        imageMimeType: String,
        customInstructions: String?
    ): Result<String> = analyzeImagePromptWithProvider(imageBase64, imageMimeType, customInstructions).map { it.first }
}

