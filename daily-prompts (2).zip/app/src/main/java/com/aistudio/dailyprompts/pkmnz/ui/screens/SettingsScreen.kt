package com.aistudio.dailyprompts.pkmnz.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Brightness4
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import com.aistudio.dailyprompts.pkmnz.data.remote.ai.AIModels
import com.aistudio.dailyprompts.pkmnz.ui.i18n.AppStrings
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppLanguage
import com.aistudio.dailyprompts.pkmnz.ui.i18n.LocalAppStrings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aistudio.dailyprompts.pkmnz.ui.components.DailyPromptsAvatar
import com.aistudio.dailyprompts.pkmnz.ui.components.GoldenLotusLogo
import com.aistudio.dailyprompts.pkmnz.ui.theme.AppTheme
import com.aistudio.dailyprompts.pkmnz.ui.theme.OnWarmYellow
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmBackground
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardBorder
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardBorderSubtle
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmCardSurface
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextPrimary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmTextSecondary
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellow
import com.aistudio.dailyprompts.pkmnz.ui.theme.WarmYellowDark
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.AppTab
import com.aistudio.dailyprompts.pkmnz.ui.viewmodel.PromptViewModel

@Composable
fun SettingsScreen(
    viewModel: PromptViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current
    val strings = LocalAppStrings.current
    val currentLanguage = LocalAppLanguage.current

    val dailyReminder by viewModel.dailyReminder.collectAsStateWithLifecycle()
    val darkMode by viewModel.darkMode.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val selectedTheme by viewModel.selectedTheme.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()

    val isDark = AppTheme.colors.isDark
    val highContrastSwitchColors = SwitchDefaults.colors(
        checkedThumbColor = OnWarmYellow,
        checkedTrackColor = WarmYellow,
        checkedBorderColor = WarmYellowDark,
        checkedIconColor = OnWarmYellow,
        uncheckedThumbColor = if (isDark) Color(0xFFF8FAFC) else Color(0xFF334155),
        uncheckedTrackColor = if (isDark) Color(0xFF1E293B) else Color(0xFFE2E8F0),
        uncheckedBorderColor = if (isDark) Color(0xFF64748B) else Color(0xFF94A3B8),
        uncheckedIconColor = if (isDark) Color(0xFF1E293B) else Color(0xFFE2E8F0)
    )

    var showClearDialog by remember { mutableStateOf(false) }
    var showLogoutDialog by remember { mutableStateOf(false) }

    val themes = remember {
        listOf(
            "Yellow",
            "Peach",
            "Rose",
            "Mint",
            "Blue",
            "Red",
            "Purple",
            "Teal",
            "Lavender",
            "Sky Blue",
            "Emerald Green",
            "Coral"
        )
    }
    val languages = remember { listOf("English", "Spanish", "French", "German") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WarmBackground)
            .navigationBarsPadding()
            .testTag("settings_screen")
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onBack()
                },
                modifier = Modifier.testTag("settings_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = strings.back,
                    tint = WarmTextPrimary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Text(
                text = strings.settingsTitle,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    color = WarmTextPrimary
                ),
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        // Settings Content
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // 0. Profile / Account
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(elevation = 2.dp, shape = RoundedCornerShape(22.dp), ambientColor = Color(0x14000000))
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            viewModel.openEditProfile()
                        }
                        .testTag("settings_account_card"),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = WarmCardSurface),
                    border = BorderStroke(1.dp, WarmCardBorderSubtle)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            DailyPromptsAvatar(sizeDp = 48.dp, profile = userProfile)
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = userProfile.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = WarmTextPrimary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = strings.editProfileAccount,
                                    fontSize = 13.sp,
                                    color = WarmYellowDark,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = strings.editProfileAccount,
                            tint = WarmTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // 1. Preferences Card (Daily Reminder, Dark Mode, Notifications)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(elevation = 2.dp, shape = RoundedCornerShape(22.dp), ambientColor = Color(0x14000000)),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = WarmCardSurface),
                    border = BorderStroke(1.dp, WarmCardBorderSubtle)
                ) {
                    Column(modifier = Modifier.padding(vertical = 8.dp)) {
                        // Daily Reminder
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 18.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(Color(0xFFFEF3C7), shape = CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Schedule,
                                        contentDescription = null,
                                        tint = Color(0xFFD97706),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(14.dp))
                                Column {
                                    Text(
                                        text = strings.dailyReminder,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 15.sp,
                                        color = WarmTextPrimary
                                    )
                                    Text(
                                        text = strings.dailyReminderDesc,
                                        fontSize = 12.sp,
                                        color = WarmTextSecondary
                                    )
                                }
                            }
                            Switch(
                                checked = dailyReminder,
                                onCheckedChange = {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    viewModel.toggleDailyReminder()
                                },
                                modifier = Modifier.testTag("daily_reminder_switch"),
                                thumbContent = if (dailyReminder) {
                                    {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize)
                                        )
                                    }
                                } else null,
                                colors = highContrastSwitchColors
                            )
                        }

                        HorizontalDivider(
                            color = WarmCardBorderSubtle,
                            thickness = 1.dp,
                            modifier = Modifier.padding(horizontal = 18.dp)
                        )

                        // Dark Mode
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 18.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(Color(0xFFEDE9FE), shape = CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Brightness4,
                                        contentDescription = null,
                                        tint = Color(0xFF8B5CF6),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(14.dp))
                                Column {
                                    Text(
                                        text = strings.darkMode,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 15.sp,
                                        color = WarmTextPrimary
                                    )
                                    Text(
                                        text = strings.darkModeDesc,
                                        fontSize = 12.sp,
                                        color = WarmTextSecondary
                                    )
                                }
                            }
                            Switch(
                                checked = darkMode,
                                onCheckedChange = {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    viewModel.toggleDarkMode()
                                },
                                modifier = Modifier.testTag("dark_mode_switch"),
                                thumbContent = if (darkMode) {
                                    {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize)
                                        )
                                    }
                                } else null,
                                colors = highContrastSwitchColors
                            )
                        }

                        HorizontalDivider(
                            color = WarmCardBorderSubtle,
                            thickness = 1.dp,
                            modifier = Modifier.padding(horizontal = 18.dp)
                        )

                        // Notifications
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 18.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(Color(0xFFDCFCE7), shape = CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Notifications,
                                        contentDescription = null,
                                        tint = Color(0xFF15803D),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(14.dp))
                                Column {
                                    Text(
                                        text = strings.notifications,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 15.sp,
                                        color = WarmTextPrimary
                                    )
                                    Text(
                                        text = strings.notificationsDesc,
                                        fontSize = 12.sp,
                                        color = WarmTextSecondary
                                    )
                                }
                            }
                            Switch(
                                checked = notifications,
                                onCheckedChange = {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    viewModel.toggleNotifications()
                                },
                                modifier = Modifier.testTag("notifications_switch"),
                                thumbContent = if (notifications) {
                                    {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize)
                                        )
                                    }
                                } else null,
                                colors = highContrastSwitchColors
                            )
                        }
                    }
                }
            }

            // 1b. AI Cloud Providers & Keys Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(elevation = 2.dp, shape = RoundedCornerShape(22.dp), ambientColor = Color(0x14000000))
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            viewModel.setTab(AppTab.API_KEY_SETTINGS)
                        }
                        .testTag("settings_api_keys_card"),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = WarmCardSurface),
                    border = BorderStroke(1.dp, WarmCardBorderSubtle)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(Color(0xFFFEF3C7), shape = CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Key,
                                    contentDescription = null,
                                    tint = Color(0xFFD97706),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = "AI Providers & API Keys",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 15.sp,
                                    color = WarmTextPrimary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Google Gemini (${AIModels.GEMINI_PRIMARY}) • OpenAI (${AIModels.OPENAI_DEFAULT})",
                                    fontSize = 12.sp,
                                    color = WarmTextSecondary
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Configure API Keys",
                            tint = WarmTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // 2. Customization Card (App Theme & Language)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(elevation = 2.dp, shape = RoundedCornerShape(22.dp), ambientColor = Color(0x14000000)),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = WarmCardSurface),
                    border = BorderStroke(1.dp, WarmCardBorderSubtle)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        // Theme selector
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Palette,
                                contentDescription = null,
                                tint = WarmYellowDark,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = strings.appTheme,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = WarmTextPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            themes.chunked(6).forEach { rowThemes ->
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    rowThemes.forEach { themeName ->
                                        val isSelected = (selectedTheme == themeName)
                                        val dotColor = when (themeName.lowercase()) {
                                            "peach" -> Color(0xFFFF9E80)
                                            "rose" -> Color(0xFFF06292)
                                            "mint" -> Color(0xFF4DB6AC)
                                            "blue" -> Color(0xFF2563EB)
                                            "red" -> Color(0xFFEF4444)
                                            "purple" -> Color(0xFF8B5CF6)
                                            "teal" -> Color(0xFF14B8A6)
                                            "lavender" -> Color(0xFFA855F7)
                                            "sky blue", "skyblue" -> Color(0xFF0EA5E9)
                                            "emerald green", "emerald", "emeraldgreen" -> Color(0xFF10B981)
                                            "coral" -> Color(0xFFFF6F61)
                                            else -> Color(0xFFFFD54F)
                                        }
                                        FilterChip(
                                            selected = isSelected,
                                            onClick = {
                                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                viewModel.setTheme(themeName)
                                            },
                                            modifier = Modifier.testTag("theme_chip_$themeName"),
                                            leadingIcon = {
                                                Box(
                                                    modifier = Modifier
                                                        .size(12.dp)
                                                        .background(dotColor, CircleShape)
                                                )
                                            },
                                            label = {
                                                Text(
                                                    AppStrings.translate(themeName, currentLanguage),
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                                )
                                            },
                                            shape = RoundedCornerShape(16.dp),
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = WarmYellow,
                                                selectedLabelColor = OnWarmYellow,
                                                containerColor = if (AppTheme.colors.isDark) Color(0xFF2E2620) else Color(0xFFF9F5F0),
                                                labelColor = WarmTextSecondary
                                            )
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))
                        HorizontalDivider(color = WarmCardBorderSubtle, thickness = 1.dp)
                        Spacer(modifier = Modifier.height(18.dp))

                        // Language selector
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = null,
                                tint = Color(0xFF3B82F6),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = strings.language,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = WarmTextPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            languages.forEach { lang ->
                                val isSelected = (selectedLanguage == lang)
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        viewModel.setLanguage(lang)
                                    },
                                    label = { Text(AppStrings.translate(lang, currentLanguage), fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium) },
                                    shape = RoundedCornerShape(16.dp),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = WarmYellow,
                                        selectedLabelColor = OnWarmYellow,
                                        containerColor = if (AppTheme.colors.isDark) Color(0xFF2E2620) else Color(0xFFF9F5F0),
                                        labelColor = WarmTextSecondary
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // 3. Clear History Action Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(elevation = 2.dp, shape = RoundedCornerShape(22.dp), ambientColor = Color(0x14000000))
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            showClearDialog = true
                        }
                        .testTag("settings_clear_history_card"),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = WarmCardSurface),
                    border = BorderStroke(1.dp, WarmCardBorderSubtle)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color(0xFFFEE2E2), shape = CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = null,
                                tint = Color(0xFFDC2626),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = strings.clearHistory,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp,
                                color = WarmTextPrimary
                            )
                            Text(
                                text = strings.clearHistoryDesc,
                                fontSize = 12.sp,
                                color = WarmTextSecondary
                            )
                        }
                    }
                }
            }

            // 4. Log Out Button
            item {
                Button(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        showLogoutDialog = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("settings_logout_button"),
                    shape = RoundedCornerShape(22.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFEE2E2),
                        contentColor = Color(0xFFDC2626)
                    )
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                            contentDescription = strings.logOut,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = strings.logOut,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }

            // 5. Footer (Golden lotus icon, "Keep Prompting", "Keep Growing ❤️")
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp, bottom = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    GoldenLotusLogo(sizeDp = 44.dp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Keep Prompting",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = WarmTextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Keep Growing ❤️",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 14.sp,
                            color = WarmTextSecondary
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "v1.3.0",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 12.sp,
                            color = WarmTextSecondary.copy(alpha = 0.7f)
                        )
                    )
                }
            }
        }
    }

    // Clear History Confirmation Dialog
    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        showClearDialog = false
                        viewModel.clearAppHistory()
                    }
                ) {
                    Text(strings.clear, color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text(strings.cancel, color = WarmTextSecondary)
                }
            },
            title = { Text(strings.clearHistoryDialogTitle, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold) },
            text = { Text(strings.clearHistoryDialogDesc) },
            containerColor = WarmCardSurface,
            shape = RoundedCornerShape(20.dp)
        )
    }

    // Logout Confirmation Dialog
    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        showLogoutDialog = false
                        android.widget.Toast.makeText(context, "Logged out safely. See you soon!", android.widget.Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Text(strings.logOut, color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text(strings.cancel, color = WarmTextSecondary)
                }
            },
            title = { Text(strings.logOutDialogTitle, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold) },
            text = { Text(strings.logOutDialogDesc) },
            containerColor = WarmCardSurface,
            shape = RoundedCornerShape(20.dp)
        )
    }
}
