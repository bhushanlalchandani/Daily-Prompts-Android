package com.aistudio.dailyprompts.pkmnz

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.aistudio.dailyprompts.pkmnz.data.generator.SmartPromptEngine
import com.aistudio.dailyprompts.pkmnz.data.local.DislikedTypeEntity
import com.aistudio.dailyprompts.pkmnz.data.local.PromptDatabase
import com.aistudio.dailyprompts.pkmnz.data.local.PromptEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Daily Prompts", appName)
  }

  @Test
  fun `verify smart prompt engine seed prompts exist`() {
    assertTrue(SmartPromptEngine.SEED_PROMPTS.isNotEmpty())
    val prompt = SmartPromptEngine.getDailyFeaturedPrompt()
    assertTrue(prompt.promptText.isNotBlank())
  }

  @Test
  fun `verify dislike blocks and hides prompt type`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val inMemoryDb = Room.inMemoryDatabaseBuilder(context, PromptDatabase::class.java).build()
    val dao = inMemoryDb.promptDao()

    val prompt1 = PromptEntity(id = 1, title = "Tech Prompt", promptText = "Write code", category = "Coding & Tech")
    val prompt2 = PromptEntity(id = 2, title = "Art Prompt", promptText = "Cyberpunk city", category = "AI Art")
    dao.insertPrompts(listOf(prompt1, prompt2))

    // Check both visible
    val initialPrompts = dao.getAllPrompts().first()
    assertEquals(2, initialPrompts.size)

    // Dislike Coding & Tech
    dao.markPromptDisliked(prompt1.id)
    dao.markCategoryDisliked(prompt1.category)
    dao.insertDislikedType(DislikedTypeEntity(category = prompt1.category, promptTitle = prompt1.title))

    val afterDislike = dao.getAllPrompts().first()
    assertEquals(1, afterDislike.size)
    assertEquals("AI Art", afterDislike.first().category)

    val dislikedCategories = dao.getDislikedCategories()
    assertTrue(dislikedCategories.contains("Coding & Tech"))

    inMemoryDb.close()
  }

  @Test
  fun `verify boy girl and nature categories and prompts exist`() {
    val boyPrompts = SmartPromptEngine.SEED_PROMPTS.filter { it.category.contains("Boy") }
    val girlPrompts = SmartPromptEngine.SEED_PROMPTS.filter { it.category.contains("Girl") }
    val naturePrompts = SmartPromptEngine.SEED_PROMPTS.filter { it.category.contains("Nature") }

    assertTrue("Boy prompts should be present", boyPrompts.isNotEmpty())
    assertTrue("Girl prompts should be present", girlPrompts.isNotEmpty())
    assertTrue("Nature prompts should be present", naturePrompts.isNotEmpty())

    // Test procedural generation
    val boyGenerated = SmartPromptEngine.buildProceduralPrompt(
      topic = "rainy street with headphones",
      targetAi = "Midjourney",
      category = "Boy & Male Style",
      style = "Cinematic"
    )
    assertTrue("Procedural boy prompt contains details", boyGenerated.contains("boy", ignoreCase = true))

    val girlGenerated = SmartPromptEngine.buildProceduralPrompt(
      topic = "golden hour bloom meadow",
      targetAi = "Flux",
      category = "Girl & Aesthetics",
      style = "Vibrant"
    )
    assertTrue("Procedural girl prompt contains details", girlGenerated.contains("girl", ignoreCase = true))

    val natureGenerated = SmartPromptEngine.buildProceduralPrompt(
      topic = "Himalayan misty peaks and waterfall",
      targetAi = "Midjourney",
      category = "Nature & Landscapes",
      style = "Cinematic"
    )
    assertTrue("Procedural nature prompt contains details", natureGenerated.contains("landscape", ignoreCase = true) || natureGenerated.contains("mist", ignoreCase = true))
  }

  @Test
  fun `verify duplicate prompt saving is prevented`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val inMemoryDb = Room.inMemoryDatabaseBuilder(context, PromptDatabase::class.java).build()
    val repo = com.aistudio.dailyprompts.pkmnz.data.repository.PromptRepository(inMemoryDb.promptDao())

    val promptText = "Detailed master portrait prompt of an explorer"
    val id1 = repo.savePrompt("Explorer", promptText, "Nature & Landscapes", "ChatGPT")
    val id2 = repo.savePrompt("Explorer Copy", promptText, "Nature & Landscapes", "ChatGPT")

    // The second save should return the existing id and not create a duplicate row
    assertEquals(id1, id2)

    val count = inMemoryDb.promptDao().getPromptCount()
    assertEquals(1, count)

    inMemoryDb.close()
  }

  @Test
  fun `verify application class initializes without throwing`() {
    val app = DailyPromptsApp()
    assertNotNull(app)
  }

  @Test
  fun `verify room migration 1 to 2 upgrades schema correctly`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val dbFile = context.getDatabasePath("test_migration.db")
    dbFile.delete()

    val factory = androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory()
    val config = androidx.sqlite.db.SupportSQLiteOpenHelper.Configuration.builder(context)
      .name("test_migration.db")
      .callback(object : androidx.sqlite.db.SupportSQLiteOpenHelper.Callback(1) {
        override fun onCreate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
          db.execSQL(
            """
            CREATE TABLE prompts (
              id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
              title TEXT NOT NULL,
              promptText TEXT NOT NULL,
              category TEXT NOT NULL,
              aiTool TEXT NOT NULL,
              tags TEXT NOT NULL,
              isFavorite INTEGER NOT NULL,
              copyCount INTEGER NOT NULL,
              createdAt INTEGER NOT NULL
            )
            """.trimIndent()
          )
          db.execSQL("INSERT INTO prompts (id, title, promptText, category, aiTool, tags, isFavorite, copyCount, createdAt) VALUES (1, 'V1 Prompt', 'Old text', 'Art', 'Midjourney', 'art', 0, 0, 1000)")
        }

        override fun onUpgrade(db: androidx.sqlite.db.SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {}
      })
      .build()

    val helper = factory.create(config)
    val v1Db = helper.writableDatabase

    PromptDatabase.MIGRATION_1_2.migrate(v1Db)

    val cursor = v1Db.query("SELECT id, title, isDisliked FROM prompts WHERE id = 1")
    assertTrue(cursor.moveToFirst())
    assertEquals(1L, cursor.getLong(0))
    assertEquals("V1 Prompt", cursor.getString(1))
    assertEquals(0, cursor.getInt(2))
    cursor.close()

    val tableCursor = v1Db.query("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='disliked_types'")
    assertTrue(tableCursor.moveToFirst())
    assertEquals(1, tableCursor.getInt(0))
    tableCursor.close()

    // Test idempotency (migrating again does not crash)
    PromptDatabase.MIGRATION_1_2.migrate(v1Db)

    v1Db.close()
    dbFile.delete()
  }

  @Test
  fun `verify cover photo manager persists and removes photo correctly`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val manager = com.aistudio.dailyprompts.pkmnz.data.cover.CoverPhotoManager(context)

    // Initially clear any cover photo
    manager.removeCoverPhoto()
    assertEquals(null, manager.coverPhotoPath.value)

    // Create a dummy bitmap and save as file
    val testBitmap = android.graphics.Bitmap.createBitmap(100, 100, android.graphics.Bitmap.Config.ARGB_8888)
    val testFile = java.io.File(context.filesDir, "test_source.jpg")
    testFile.outputStream().use { testBitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }

    val uri = android.net.Uri.fromFile(testFile)
    val result = manager.setCoverPhoto(uri)
    assertTrue("Set cover photo should succeed", result.isSuccess)
    val savedPath = result.getOrNull()
    assertNotNull(savedPath)
    assertTrue(java.io.File(savedPath!!).exists())
    assertEquals(savedPath, manager.coverPhotoPath.value)

    // Remove cover photo
    manager.removeCoverPhoto()
    assertEquals(null, manager.coverPhotoPath.value)
    assertFalse(java.io.File(savedPath).exists())
  }

  @Test
  fun `verify wallpaper presets and dimming level in CoverPhotoManager`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val manager = com.aistudio.dailyprompts.pkmnz.data.cover.CoverPhotoManager(context)

    // Set preset
    manager.setPreset("neon_cyberpunk")
    val state = manager.wallpaperState.value
    assertEquals(com.aistudio.dailyprompts.pkmnz.data.cover.WallpaperType.PRESET, state.type)
    assertEquals("neon_cyberpunk", state.presetId)

    // Set dim level
    manager.setDimLevel(0.40f)
    assertEquals(0.40f, manager.wallpaperState.value.dimLevel, 0.01f)

    // Reset to default
    manager.removeCoverPhoto()
    assertEquals(com.aistudio.dailyprompts.pkmnz.data.cover.WallpaperType.DEFAULT, manager.wallpaperState.value.type)
  }

  @Test
  fun `verify rollFreshPrompts purges stale daily prompts but preserves favorites`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val inMemoryDb = Room.inMemoryDatabaseBuilder(context, PromptDatabase::class.java).build()
    val dao = inMemoryDb.promptDao()
    val repo = com.aistudio.dailyprompts.pkmnz.data.repository.PromptRepository(dao)

    // Roll initial batch
    repo.rollFreshPrompts(0)
    val initialBatch = dao.getAllPrompts().first()
    assertTrue(initialBatch.isNotEmpty())

    // Mark the first prompt as favorite
    val favoritePrompt = initialBatch.first()
    dao.updateFavorite(favoritePrompt.id, true)

    // Roll fresh batch with new seed
    repo.rollFreshPrompts(1)
    val afterRollBatch = dao.getAllPrompts().first()

    // The favorite prompt MUST still exist!
    val foundFavorite = afterRollBatch.firstOrNull { it.id == favoritePrompt.id }
    assertNotNull("Favorite prompt must be preserved across daily rolls", foundFavorite)
    assertTrue(foundFavorite!!.isFavorite)

    inMemoryDb.close()
  }

  @Test
  fun `verify user profile defaults and local persistence across manager instances`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val manager = com.aistudio.dailyprompts.pkmnz.data.local.UserProfileManager(context)

    // Initial default profile checks
    val initial = manager.loadProfile()
    assertEquals("Daily Prompts", initial.name)
    assertEquals("A better you, every day ❤️", initial.bio)
    assertEquals(com.aistudio.dailyprompts.pkmnz.data.model.UserProfile.AVATAR_DEFAULT, initial.avatarType)
    assertEquals(null, initial.customAvatarPath)

    // Save modified profile
    val saved = manager.saveProfile(
      name = "Jane Doe",
      bio = "Mindfulness explorer & daily journaler",
      email = "jane@example.com",
      avatarType = com.aistudio.dailyprompts.pkmnz.data.model.UserProfile.AVATAR_LOTUS,
      customAvatarPath = null
    )

    assertEquals("Jane Doe", saved.name)
    assertEquals("Mindfulness explorer & daily journaler", saved.bio)
    assertEquals("jane@example.com", saved.email)
    assertEquals(com.aistudio.dailyprompts.pkmnz.data.model.UserProfile.AVATAR_LOTUS, saved.avatarType)

    // Simulate closing and reopening app by creating a new UserProfileManager instance
    val restartedManager = com.aistudio.dailyprompts.pkmnz.data.local.UserProfileManager(context)
    val restored = restartedManager.loadProfile()
    assertEquals("Jane Doe", restored.name)
    assertEquals("Mindfulness explorer & daily journaler", restored.bio)
    assertEquals("jane@example.com", restored.email)
    assertEquals(com.aistudio.dailyprompts.pkmnz.data.model.UserProfile.AVATAR_LOTUS, restored.avatarType)
    assertEquals(null, restored.customAvatarPath)

    // Reset back to clean state
    val reset = restartedManager.resetProfile()
    assertEquals("Daily Prompts", reset.name)
  }

  @Test
  fun `verify custom avatar photo saving and removal`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val manager = com.aistudio.dailyprompts.pkmnz.data.local.UserProfileManager(context)

    // Create a temporary bitmap image
    val testBitmap = android.graphics.Bitmap.createBitmap(120, 120, android.graphics.Bitmap.Config.ARGB_8888)
    val testFile = java.io.File(context.filesDir, "avatar_test_source.jpg")
    testFile.outputStream().use { testBitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }

    val uri = android.net.Uri.fromFile(testFile)
    val result = manager.saveCustomAvatarPhoto(uri)
    assertTrue("Saving custom avatar should succeed", result.isSuccess)
    val savedPath = result.getOrNull()
    assertNotNull("Saved avatar photo path should not be null", savedPath)
    assertTrue("Avatar file should exist on disk", java.io.File(savedPath!!).exists())

    val loaded = manager.loadProfile()
    assertEquals(savedPath, loaded.customAvatarPath)
    assertEquals(com.aistudio.dailyprompts.pkmnz.data.model.UserProfile.AVATAR_CUSTOM, loaded.avatarType)

    // Simulate reopening app with custom avatar
    val reopenedManager = com.aistudio.dailyprompts.pkmnz.data.local.UserProfileManager(context)
    val reopenedProfile = reopenedManager.loadProfile()
    assertEquals(savedPath, reopenedProfile.customAvatarPath)
    assertEquals(com.aistudio.dailyprompts.pkmnz.data.model.UserProfile.AVATAR_CUSTOM, reopenedProfile.avatarType)

    // Remove photo
    manager.clearCustomAvatarPhoto()
    val afterRemove = manager.loadProfile()
    assertEquals(null, afterRemove.customAvatarPath)
    assertFalse("Deleted file should no longer exist", java.io.File(savedPath).exists())
  }

  @Test
  fun `verify prompt viewmodel edit profile navigation and live updates`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val inMemoryDb = Room.inMemoryDatabaseBuilder(context, PromptDatabase::class.java).build()
    val repo = com.aistudio.dailyprompts.pkmnz.data.repository.PromptRepository(inMemoryDb.promptDao())
    val viewModel = com.aistudio.dailyprompts.pkmnz.ui.viewmodel.PromptViewModel(repo, context)

    // Open Edit Profile
    viewModel.openEditProfile()
    assertEquals(com.aistudio.dailyprompts.pkmnz.ui.viewmodel.AppTab.EDIT_PROFILE, viewModel.currentTab.value)

    // Save profile with validation
    val blankSaveResult = viewModel.saveUserProfile("   ", "Bio", "test@test.com")
    assertFalse("Blank name should fail validation", blankSaveResult)

    val validSaveResult = viewModel.saveUserProfile(
      name = "Alex Creative",
      bio = "Writing one reflection every single day",
      email = "alex@prompt.app",
      avatarType = com.aistudio.dailyprompts.pkmnz.data.model.UserProfile.AVATAR_SUNSET
    )
    assertTrue("Valid profile save should succeed", validSaveResult)

    // Verified immediate live update without restart
    assertEquals("Alex Creative", viewModel.userProfile.value.name)
    assertEquals("Writing one reflection every single day", viewModel.userProfile.value.bio)
    assertEquals("alex@prompt.app", viewModel.userProfile.value.email)
    assertEquals(com.aistudio.dailyprompts.pkmnz.data.model.UserProfile.AVATAR_SUNSET, viewModel.userProfile.value.avatarType)

    // Clean up
    viewModel.resetUserProfile()
    inMemoryDb.close()
  }

  @Test
  fun `verify theme switching and persistence across sessions`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val inMemoryDb = Room.inMemoryDatabaseBuilder(context, PromptDatabase::class.java).build()
    val repo = com.aistudio.dailyprompts.pkmnz.data.repository.PromptRepository(inMemoryDb.promptDao())
    val viewModel = com.aistudio.dailyprompts.pkmnz.ui.viewmodel.PromptViewModel(repo, context)

    // Switch theme to Peach
    viewModel.setTheme("Peach")
    assertEquals("Peach", viewModel.selectedTheme.value)

    // Verify persistence across new ViewModel instance
    val reopenedViewModel = com.aistudio.dailyprompts.pkmnz.ui.viewmodel.PromptViewModel(repo, context)
    assertEquals("Peach", reopenedViewModel.selectedTheme.value)

    // Switch theme to Rose
    reopenedViewModel.setTheme("Rose")
    assertEquals("Rose", reopenedViewModel.selectedTheme.value)

    // Switch theme to Mint
    reopenedViewModel.setTheme("Mint")
    assertEquals("Mint", reopenedViewModel.selectedTheme.value)

    // Clean up back to Yellow
    reopenedViewModel.setTheme("Yellow")
    inMemoryDb.close()
  }

  @Test
  fun `verify carousel multiple prompts and navigation`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val inMemoryDb = Room.inMemoryDatabaseBuilder(context, PromptDatabase::class.java).build()
    val repo = com.aistudio.dailyprompts.pkmnz.data.repository.PromptRepository(inMemoryDb.promptDao())
    val viewModel = com.aistudio.dailyprompts.pkmnz.ui.viewmodel.PromptViewModel(repo, context)

    // Verify multiple prompts exist for carousel
    val prompts = viewModel.dailyPrompts.value
    assertTrue("Carousel must contain multiple prompts", prompts.size >= 3)

    // Verify setting active prompt in carousel updates daily featured
    val secondPrompt = prompts[1]
    viewModel.setDailyFeatured(secondPrompt)
    assertEquals(secondPrompt.promptText, viewModel.dailyFeaturedPrompt.value.promptText)

    // Verify rolling fresh prompts produces a valid non-empty list
    viewModel.rollFreshPrompts()
    val freshPrompts = viewModel.dailyPrompts.value
    assertTrue("Fresh prompts must contain multiple prompts", freshPrompts.size >= 3)

    inMemoryDb.close()
  }

  @Test
  fun `verify generated prompts are cached in Room and capped at last 10 items`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val inMemoryDb = Room.inMemoryDatabaseBuilder(context, PromptDatabase::class.java).build()
    val repo = com.aistudio.dailyprompts.pkmnz.data.repository.PromptRepository(inMemoryDb.promptDao())

    // Cache 12 prompts consecutively
    for (i in 1..12) {
      repo.cacheGeneratedPrompt(
        topic = "Topic $i",
        promptText = "Generated prompt text content number $i",
        targetAi = "ChatGPT",
        category = "Productivity",
        style = "Professional",
        isGemini = (i % 2 == 0),
        mode = "TEXT"
      )
    }

    // Verify exactly 10 are retained (the last 10)
    val history = inMemoryDb.promptDao().getRecentGeneratedPrompts().first()
    assertEquals(10, history.size)

    // The most recent should be Topic 12
    assertEquals("Topic 12", history.first().topic)
    // The oldest in the 10-cap should be Topic 3 (Topics 1 and 2 pruned)
    assertEquals("Topic 3", history.last().topic)

    // Test deleting an individual item
    val idToDelete = history.first().id
    repo.deleteGeneratedPrompt(idToDelete)
    val afterDelete = inMemoryDb.promptDao().getRecentGeneratedPrompts().first()
    assertEquals(9, afterDelete.size)
    assertFalse(afterDelete.any { it.id == idToDelete })

    // Test clearing all history
    repo.clearGeneratedHistory()
    val afterClear = inMemoryDb.promptDao().getRecentGeneratedPrompts().first()
    assertTrue(afterClear.isEmpty())

    inMemoryDb.close()
  }

  @Test
  fun `verify clearGeneratedPrompt clears current prompt and resets state`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val inMemoryDb = Room.inMemoryDatabaseBuilder(context, PromptDatabase::class.java).build()
    val repo = com.aistudio.dailyprompts.pkmnz.data.repository.PromptRepository(inMemoryDb.promptDao())
    val viewModel = com.aistudio.dailyprompts.pkmnz.ui.viewmodel.PromptViewModel(repo, context)

    // Simulate generated prompt
    viewModel.updateTopicInput("Portrait of a young woman")
    viewModel.generateCustomPrompt()

    // Verify prompt is generated
    val generatedState = viewModel.generatorState.value
    assertTrue(generatedState.generatedResult.isNotBlank())

    // Press close button / clearGeneratedPrompt
    viewModel.clearGeneratedPrompt()

    // Verify current prompt is cleared and ready for new generation
    val clearedState = viewModel.generatorState.value
    assertTrue(clearedState.generatedResult.isEmpty())
    assertFalse(clearedState.isGenerating)
    assertFalse(clearedState.isSaved)

    // Verify user can now generate a new prompt
    viewModel.updateTopicInput("A majestic snowy mountain")
    viewModel.generateCustomPrompt()
    val newState = viewModel.generatorState.value
    assertTrue(newState.generatedResult.isNotBlank())
    assertEquals("A majestic snowy mountain", newState.topicInput)

    inMemoryDb.close()
  }
}
